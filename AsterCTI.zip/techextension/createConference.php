<?php
function createConferenceForAgent($DialerAsteriskIP,$DialerAMIPort,$DialerAMIUsername,$DialerAMIPassword,$conference_name,$channel,$dialername)
{
	if(!$DialerAMIPort)
	{
		$DialerAMIPort=5038;
	}
	if(!$DialerAsteriskIP)
	{
		exit;
	}
	 $timeout = 10;
	$socket = fsockopen($DialerAsteriskIP,$DialerAMIPort, $errno, $errstr, $timeout);
	fputs($socket, "Action: Login\r\n");
	fputs($socket, "UserName: $DialerAMIUsername\r\n");
	fputs($socket, "Secret: $DialerAMIPassword\r\n\r\n");
	$wrets=fgets($socket,128);
	fputs($socket, "Action: Originate\r\n" );
	fputs($socket, "ActionID: CreateConf\r\n" );
	fputs($socket, "Channel: $channel\r\n" );
	fputs($socket, "CallerID: TE-DIALER\r\n" );
	fputs($socket, "Application: ConfBridge\r\n" );
	fputs($socket, "Data: $conference_name\r\n" );
	fputs($socket, "Variable: campaign_type=conference\r\n\r\n" );
	$wrets=fgets($socket,128);	
	fputs($socket, "Action: Logoff\r\n\r\n");
	//print_r($wrets);
/* print_r($wrets);
echo "<br>";
print_r($socket); */
//print_r($wrets);
fclose($socket);
}

function kickAgentFromConference($DialerAsteriskIP,$DialerAMIPort,$DialerAMIUsername,$DialerAMIPassword,$conferencename,$conferencechannel)
{
	if(!$DialerAMIPort)
	{
		$DialerAMIPort=5038;
	}
	if(!$DialerAsteriskIP)
	{
		exit;
	}
	$timeout = 10;
	$socket = fsockopen($DialerAsteriskIP,$DialerAMIPort, $errno, $errstr, $timeout);
	fputs($socket, "Action: Login\r\n");
	fputs($socket, "UserName: $DialerAMIUsername\r\n");
	fputs($socket, "Secret: $DialerAMIPassword\r\n\r\n");
	$wrets=fgets($socket,128);
	fputs($socket, "Action: ConfbridgeKick\r\n" );
	fputs($socket, "Channel: $conferencechannel\r\n" );
	fputs($socket, "Conference: $conferencename\r\n\r\n" );
	fputs($socket, "Async: yes\r\n" );
	$wrets=fgets($socket,128);
	fputs($socket, "Action: Logoff\r\n\r\n");
	fclose($socket);
	return "1";
}
?>