<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
include("controller/route.php");


if(isset($_GET['campaign_id'])){

$campagn_id = $_GET['campaign_id'];
$contact_id = $_GET['contact_id'];
$campaignInfo = getDialerCampaignFromId($campagn_id);
$crm_search = $campaignInfo['data'][0]['crm_search'];
if($crm_search != "1"){
	echo "Searching in CRM is not permitted by Admin.";
	exit;
}
$asterCTICRMConfID = $campaignInfo['data'][0]['crm_id'];
$crm_info = getCRMById($asterCTICRMConfID);

$contact_info = getContact($contact_id);
$phone = $contact_info['data'][0]['phone'];
$crm_id = $contact_info['data'][0]['crm_id'];
$ModuleName = $contact_info['data'][0]['modulename'];
$crmurl = trim($crm_info['data'][0]['crm_url']);
$username = $crm_info['data'][0]['admin_username'];
$password = $crm_info['data'][0]['admin_password'];
$security_token = $crm_info['data'][0]['secret'];
if($crm_info['data'][0]['crm_name'] == "VtigerCRM"){
	include "controller/vtigercrm/search.php";
	if(!$crm_id){
	$endpointUrl = $crmurl."/webservice.php";
	$sessionData = call_vtiger($endpointUrl, array("operation" => "getchallenge", "username" => $username));
	$challengeToken = $sessionData['result']['token'];
	$generatedKey = md5($challengeToken.$security_token);
	$dataDetails = call_vtiger($endpointUrl, array("operation" => "login", "username" => $username, "accessKey" => $generatedKey), "POST");
	$sessionid = $dataDetails['result']['sessionName'];

	$response = search($phone,$sessionid,$endpointUrl,"");
	$crm_id = $response['ID'];
	$ModuleName = $response['ModuleName'];
	updateContactWithCRMInfo($contact_id,$crm_id,$ModuleName);
	}

	echo "<script>location.href='$crmurl/index.php?module=$ModuleName&view=Detail&record=$crm_id';</script>";
}
else if($crm_info['data'][0]['crm_name'] == "SugarCRM" || $crm_info['data'][0]['crm_name'] == "SuiteCRM" ){
	include "controller/sugarcrm/search.php";
		if(!$crm_id && !$ModuleName){
		$url = $crmurl."/service/v4_1/rest.php";
		$login_parameters = array(
		"user_auth" => array(
		"user_name" => $username,
		"password" => md5($password),
		"version" => "1"
	),
		"application_name" => "RestTest",
		"name_value_list" => array(),
	);
	$login_result = call("login", $login_parameters, $url);
	$session_id = $login_result->id;
	
	$response = search($phone,$session_id,$url,"");
	$crm_id = $response['ID'];
	$ModuleName = $response['ModuleName'];
	updateContactWithCRMInfo($contact_id,$crm_id,$ModuleName);
	}
	echo "<script>location.href='$crmurl/index.php?module=$ModuleName&view=Detail&record=$crm_id';</script>";
}

}



?>