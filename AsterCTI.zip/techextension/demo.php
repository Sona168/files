<?php include "header.php" ?>
<?php include "left_sidebar.php" ?>

      <div class="content-wrapper">
      
	  </div>
	  <?php
	  include "footer.php";
	  include "control_sidebar.php";
	  include "footer_script.php";
	  ?>
	  
  </body>
</html>
