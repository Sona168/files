<?php
include_once("controller/route.php");
session_start();
if(!empty($_SESSION['tech_user_id']))
{
	logout($_SESSION['tech_user_id']);
	unset($_SESSION["tech_user_id"]);

	//session_destroy();
}
//session_destroy();
header("Location:index.php");

?>
 