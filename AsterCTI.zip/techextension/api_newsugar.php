<?php
//api.php?action=createcall&extension=103&source=7405605907&direction=outbound&unique_id=123123123.123&status=dial&crm=yes&s_channel=SIP/103&d_channel=PJSIP/10002
//api.php?action=createcall&extension=102&source=1234567890&direction=outbound&unique_id=5544554554&status=connected
//api.php?action=createcall&extension=103&source=7405605907&direction=outbound&unique_id=123123123.123&status=disconnected&dispo=ANSWERED&duration=12&lastdata=testingURL&total_seconds=16&account_code=testingURL&clid=testingURL&channel=testingURL&amaflag=testingURL&endtime=&starttime=&application=testingURL&path=testingURL&crm=yes&answertime=
ini_set('display_errors',1);
ini_set('display_startup_errors',1);  
$asterisk_id='';
$recordLnk="";
$crmFlag=true;

if(!isset($_GET['extension']))
{
	echo "Prohibited Area";
}
include("controller/route.php");
$extension=trim($_GET['extension']);

if($_GET['action'] == "queue")
{
	$queue = $_GET['extension'];
	$caller = $_GET['caller'];
	$uniqiuw = $_GET['unique_id'];
	$IP = $_GET['IP'];
	$status = $_GET['status'];
	createQueueCurrentStatus($queue,$status,$uniqiuw);
	
	$channel = $_GET['Channel'];
	createLiveQueueCall($queue,$caller,$status,$uniqiuw,$channel,"","","","",$IP);
	//changeQueueMemberStatusRing($queue,"RINGING");
	exit;
}
if($_GET['crm'] == "no")
{
	$crmFlag = false;
}
$direction =$_GET['direction'];
$source_number=$_GET['source'];
$date_start=$_GET['st'];

if(strtolower($direction)=="internal")
{
	$userInfo = getUserInfoFromExtension($source_number);
	$user_id = trim($userInfo['data'][0]['user_id']);
	if(!$user_id)
	{
		$userInfo = getAdminInfoFromId("1");
		$user_id = trim($userInfo['data'][0]['user_id']);
	}
}else{
	$userInfo = getUserInfoFromExtension($extension);
	
	$user_id = trim($userInfo['data'][0]['user_id']);
	if(!$user_id)
	{
		$account_code1 = $userInfo['data'][0]['account_code'];
		$userInfo = getAdminInfoFromId("1");
		$user_id = trim($userInfo['data'][0]['user_id']);
	}
}


$asteriskIpId = trim($userInfo['data'][0]['asterisk_ip']);
$adminCheck = checkAdminSearchOnOrOff($userInfo['data'][0]['crm_url']);
if($adminCheck['status'] == 'admin_search')
{
	$username = trim($adminCheck['admin_username']);
	$password = trim($adminCheck['admin_password']);
	$security_token = trim($adminCheck['secret']);
}else{
	$username = trim($userInfo['data'][0]['crm_username']);
	$password = trim($userInfo['data'][0]['crm_password']);
	$security_token = trim($userInfo['data'][0]['secret']);
	if(!$username || !$password)
	{
		$username = trim($adminCheck['admin_username']);
		$password = trim($adminCheck['admin_password']);
		$security_token = trim($adminCheck['secret']);
	}
}


if(strtolower($direction)=="inbound")
{
	$subject = "Incoming Call From  ".$source_number." To Extension ".$extension;
	$numberTOSearch = $source_number;
	$destination_number = $extension;
}
else if(strtolower($direction)=="internal")
{
	$subject = "Internal Call From  ".$extension." To Extension ".$source_number;
	$destination_number = $source_number;
	$source_number = $extension;
	$numberTOSearch = $extension;
}else
{
	$subject = "Outgoing Call From  ".$extension." To Phone ".$source_number;
	$numberTOSearch = $source_number;
	$destination_number = $source_number;
	$source_number = $extension;
	
	
}

if(isset($_GET['action']))
{
	if($_GET['action'] == "createcall")
	{

		$asterisk_id=$_GET['unique_id'];
		/* $parent=$data['ModuleName'];
		$parent_id=$data['ID'];
		$parent_name=$data['name']; */
		
		$parent='';
		$parent_id='';
		$parent_name='';
		
		if($parent_name =="" || $parent_name =="No Contact Name")
		{
			//$parent_name = $data['AccountName'];
			$parent_name = '';
		}

		$note='';
		$recording='';
		$status='Ringing';
		if($_GET['status'] == 'dial')
		{
			$account_code1 = $userInfo['data'][0]['account_code'];
			$s_channel = $_GET['s_channel'];
			$d_channel = $_GET['d_channel'];
			$dataToSend = $user_id."**".$asterisk_id."**".$parent."**".$parent_id."**".$parent_name."**".$subject."**".$note."**".$recording."**".$status."**".$source_number."**".$destination_number."**".$call_second."**".$date_start."**".$date_end."**".$direction."**".$s_channel."**".$d_channel."**".$account_code1;
			
			createCall($dataToSend);

		}else if($_GET['status'] == 'connected')
		{
			$asterisk_id=$_GET['unique_id'];
			$dataTOSend = $asterisk_id."*Connected";
			//pass extension too
			updateCurrentCallStatus($dataTOSend);
		}
		else if($_GET['status'] == 'disconnected')
		{
			$asterisk_id=$_GET['unique_id'];
			$duration=$_GET['duration'];
			$dispo=$_GET['dispo'];
			
			$lastdata=$_GET['lastdata'];
			$total_seconds=$_GET['total_seconds'];
			$account_code=$_GET['account_code'];
			$clid=$_GET['clid'];
			$channel=$_GET['channel'];
			$amaflag=$_GET['amaflag'];
			$endtime=$_GET['endtime'];
			$starttime=$_GET['starttime'];
			$answertime=$_GET['answertime'];
			if(!$answertime)
			{
				$answertime = $starttime;
			}
			$application = $_GET['application'];
			$path = $_GET['path'];
			
			$start_date=$_GET['starttime'];
			if($start_date){			
						$start_date = strtotime($start_date);
						$start_date = date('Y/m/d',$start_date);
			}else{
				$start_date = strtotime("now");
				$start_date = date('Y/m/d',$start_date);
			}
			$asterisk_ip = getAsteriskById($asteriskIpId);
			$recordLnk = $asterisk_ip['data'][0]['recording_url']."/".$start_date."/".$path;
			$dataTOSend = $asterisk_id."*Disconnected";
			updateCurrentCallStatus($dataTOSend);
			$dataToSend = $asterisk_id."*".$recordLnk."*".$duration."*".$dispo."*".$lastdata."*".$total_seconds."*".$account_code."*".$clid."*".$channel."*".$amaflag."*".$endtime."*".$starttime."*".$application."*".$answertime."*".$extension;
			//echo $dataToSend;
			$hangupResponse = hangUpCall($dataToSend);
			
			
		}
	}
}

if($_GET['status'] == 'dial' || $_GET['status'] == 'disconnected')
{
	if($_GET['status'] == 'disconnected')
	{
		
		$callInfo = getCallInfoAfterUpdation($asterisk_id);
		$module_name = $callInfo['all']['parent'];
		$portal_call_id = $callInfo['all']['id'];
		$parent_id = $callInfo['all']['parent_id'];
		$parent_name = $callInfo['all']['parent_name'];
		$subject = $callInfo['all']['subject'];
		$note = $callInfo['all']['note'];
		$disposition = $callInfo['all']['desposition'];
		$direction = $callInfo['all']['direction'];
		$source_number = $callInfo['all']['source_number'];
		$destination_number = $callInfo['all']['destination_number'];
		$duration = $callInfo['all']['call_second'];
		$date_start = $callInfo['all']['date_start'];
		$date_end = $callInfo['all']['date_end'];
		$crm_user_id = trim($userInfo['data'][0]['crm_user_id']);
		
		$techextensionModules = getAllLicenseModuleInfo();
		for($i=0;$i<count($techextensionModules['data']);$i++)
		{
			if($techextensionModules['data'][$i]['name'] == "CRM Call Log")
			{
				if($techextensionModules['data'][$i]['status'] != "1")
				{
					$crmFlag=false;
				}
			}
		}
	
	}
	
	if(trim($userInfo['data'][0]['crm_type']) == "SugarCRM" || trim($userInfo['data'][0]['crm_type']) == "SuiteCRM")
	{

		$crmurl = trim($userInfo['data'][0]['crm_url']);
	$url = $crmurl."/rest/v10";
	$auth_url = $url . "/oauth2/token";
	$oauth2_token_arguments = array(
    "grant_type" => "password",
	"client_id" => "sugar", 
    "client_secret" => "",
    "username" => $username,
    "password" => $password,
    "platform" => "astercti_api" 
);
$auth_request = curl_init($auth_url);
curl_setopt($auth_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
curl_setopt($auth_request, CURLOPT_HEADER, false);
curl_setopt($auth_request, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($auth_request, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($auth_request, CURLOPT_FOLLOWLOCATION, 0);
curl_setopt($auth_request, CURLOPT_HTTPHEADER, array(
    "Content-Type: application/json"
));
$json_arguments = json_encode($oauth2_token_arguments);
curl_setopt($auth_request, CURLOPT_POSTFIELDS, $json_arguments);
$oauth2_token_response = curl_exec($auth_request);
$oauth2_token_response_obj = json_decode($oauth2_token_response);
$session_id = $oauth2_token_response_obj->access_token;

if($_GET['status'] == 'dial')
{
include_once('controller/sugarcrm/search.php');
$data = search($numberTOSearch,$session_id,$url,$extension);
}else if($_GET['status'] == 'disconnected'){
	if($crmFlag)
	{
		if($userInfo['data'][0]['call_log_in_crm'] == "1")
		{
			include_once('controller/sugarcrm/call_log.php');
			
			$call_id_crm = create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$session_id,$url,$crm_user_id,$date_start,$date_end,$asterisk_id);
			
			updateCRMCallId($call_id_crm,$portal_call_id);
			echo "call created Successfully.";
			echo "<br>";
			echo "Call ID IN CRM : ".$call_id_crm;
		}else{
			echo "You Dont have Permission to Log Call In CRM";
		}
	}
	}
	
	
	}

	if(trim($userInfo['data'][0]['crm_type']) == "SalesForce Partner" || trim($userInfo['data'][0]['crm_type']) == "SalesForce Enterprise" )
	{
		$type="";
		if(trim($userInfo['data'][0]['crm_type']) == "SalesForce Partner")
		{
			require_once ('controller/salesforce/soapclient/SforcePartnerClient.php');
			$mySforceConnection = new SforcePartnerClient();
			$mySforceConnection->createConnection("controller/salesforce/soapclient/partner.wsdl.xml");
			$type = "partner";
		}else{
			require_once ('controller/salesforce/soapclient/SforceEnterpriseClient.php');
			$mySforceConnection = new SforceEnterpriseClient();
			$mySforceConnection->createConnection("controller/salesforce/soapclient/enterprise.wsdl.xml");
			$type = "enterprise";
		}
	
	$fetcheSesion = getSession($user_id);
	
	if($fetcheSesion['sessionID'])
	{
		
		try {
			$mySforceConnection->setSessionHeader($fetcheSesion['sessionID']);
			$mySforceConnection->setEndPoint($fetcheSesion['sessionUrl']);
		}
		catch (Exception $e) {
			$mySforceConnection->login($username, $password.$security_token);
			$sessionID = $mySforceConnection->getSessionId();
			$serverUrl = $mySforceConnection->getLocation();
			$dataAyyay['user'] = $user_id;
			$dataAyyay['sessionID'] = $sessionID;
			$dataAyyay['serverUrl'] = $serverUrl;
			$res = setSession($dataAyyay);
		}
	}
	else
	{
		
		$mySforceConnection->login($username, $password.$security_token);
		$sessionID = $mySforceConnection->getSessionId();
		$serverUrl = $mySforceConnection->getLocation();
		$dataAyyay['user'] = $user_id;
		$dataAyyay['sessionID'] = $sessionID;
		$dataAyyay['serverUrl'] = $serverUrl;
		
		$res = setSession($dataAyyay);
	}
		if($_GET['status'] == 'dial')
		{
			include_once('controller/salesforce/search.php');
			$data = search($numberTOSearch,$mySforceConnection,$crmurl,$extension);
		}
	else if($_GET['status'] == 'disconnected'){
	if($crmFlag)
	{
		if($userInfo['data'][0]['call_log_in_crm'] == "1")
		{
		
			include_once('controller/salesforce/call_log.php');
			$call_id_crm = create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$mySforceConnection,$crmurl,$Extension,$crm_user_id,$date_start,$date_end,$asterisk_id,$type);
		updateCRMCallId($call_id_crm,$portal_call_id);
		echo "call created Successfully.";
		echo "<br>";
		echo "Call ID IN CRM : ".$call_id_crm;
		Exit;
		}else{
			echo "You Dont have Permission to Log Call In CRM";
			exit;
		}
	}
	}
	}
	if(trim($userInfo['data'][0]['crm_type']) == "VtigerCRM")
	{
		
		$crmurl = trim($userInfo['data'][0]['crm_url']);

		$endpointUrl = $crmurl."/webservice.php";
		$sessionData = call_vtiger($endpointUrl, array("operation" => "getchallenge", "username" => $username));
		$challengeToken = $sessionData['result']['token'];
		$generatedKey = md5($challengeToken.$security_token);
		$dataDetails = call_vtiger($endpointUrl, array("operation" => "login", "username" => $username, "accessKey" => $generatedKey), "POST");
		$sessionid = $dataDetails['result']['sessionName'];
		
		
		
		if($_GET['status'] == 'dial')
		{
			
			include_once('controller/vtigercrm/search.php');
			$data = search($numberTOSearch,$sessionid,$endpointUrl,$extension);
			
		}else if($_GET['status'] == 'disconnected'){
		if($crmFlag)
		{
			if($userInfo['data'][0]['call_log_in_crm'] == "1")
			{
				include_once('controller/vtigercrm/call_log.php');
				$call_id_crm = create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$sessionid,$endpointUrl,$Extension,$crm_user_id,$date_start,$date_end,$asterisk_id,$type);
				
				 updateCRMCallId($call_id_crm,$portal_call_id);
				echo "call created Successfully.";
				echo "<br>";
				echo "Call ID IN CRM : ".$call_id_crm;
				Exit;
			}else{
			echo "You Dont have Permission to Log Call In CRM";
			exit;
			}
		}
		}
	}
	if(trim($userInfo['data'][0]['crm_type']) == "ZOHO CRM")
	{
		$api_token = trim($userInfo['data'][0]['secret']);
		$crmurl = trim($userInfo['data'][0]['crm_url']);
		
		if($api_token)
		{
			if($_GET['status'] == 'dial')
			{
				include_once('controller/zohocrm/search.php');
				$data = search($numberTOSearch,$api_token,$crmurl,$extension);
			}
			else if($_GET['status'] == 'disconnected'){
			if($crmFlag)
			{
				if($userInfo['data'][0]['call_log_in_crm'] == "1")
				{
				
					include_once('controller/zohocrm/call_log.php');
					$call_id_crm = create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$api_token,$crmurl,$Extension,$crm_user_id,$date_start,$date_end,$asterisk_id,$type);
					$xmlparser = xml_parser_create();
					xml_parse_into_struct($xmlparser,$call_id_crm,$values);
					xml_parser_free($xmlparser);
					$call_id_crm= $values[4]['value'];
					updateCRMCallId($call_id_crm,$portal_call_id);
					echo "call created Successfully.";
					echo "<br>";
					echo "Call ID IN CRM : ".$call_id_crm;
					Exit;
				}else{
				echo "You Dont have Permission to Log Call In CRM";
				exit;
				}
			}
			}
		}else{
				echo "No Acees Token Found...Please goto Profile and save Valid Authentication Token";
		}
	}
	if(trim($userInfo['data'][0]['crm_type']) == "Pipedrive CRM")
	{
		$api_token = trim($userInfo['data'][0]['secret']);
		$crmurl = trim($userInfo['data'][0]['crm_url']);
		if($api_token)
		{
			if($_GET['status'] == 'dial')
			{
				include_once('controller/pipedrivecrm/search.php');
				$data = search($numberTOSearch,$api_token,$crmurl,$extension);
			}else if($_GET['status'] == 'disconnected'){
			if($crmFlag)
			{
			if($userInfo['data'][0]['call_log_in_crm'] == "1")
				{
					include_once('controller/pipedrivecrm/call_log.php');
					$call_id_crm = create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$api_token,$crmurl,$Extension,$crm_user_id,$date_start,$date_end,$asterisk_id,$type);
					
					updateCRMCallId($call_id_crm,$portal_call_id);
					echo "call created Successfully.";
					echo "<br>";
					echo "Call ID IN CRM : ".$call_id_crm;
					Exit;
				}else{
				echo "You Dont have Permission to Log Call In CRM";
				exit;
				}
			}
			} 
		}else{
				echo "No Acees Token Found...Please goto Profile and save Valid Access Token";
		}
	}
	if(trim($userInfo['data'][0]['crm_type']) == "Odoo")
	{
		
		$db_name = trim($userInfo['data'][0]['secret']);
		$crmurl = trim($userInfo['data'][0]['crm_url']);
		if($db_name)
		{
			require_once('controller/odoocrm/library/ripcord.php');
			
			if(!$crm_user_id)
			{
				$common = ripcord::client("$crmurl/xmlrpc/2/common");
				$crm_user_id = $common->authenticate($db_name, $username, $password, array());
			}
			if($_GET['status'] == 'dial')
			{
				include_once('controller/odoocrm/search.php');
				$data = search($numberTOSearch,$crm_user_id,$crmurl,$extension,$db_name,$password);
				
			}else if($_GET['status'] == 'disconnected'){
			if($crmFlag)
			{
			if($userInfo['data'][0]['call_log_in_crm'] == "1")
				{
					include_once('controller/odoocrm/call_log.php');
					$call_id_crm = create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$db_name,$crmurl,$crm_user_id,$date_start,$date_end,$asterisk_id,$password);
					updateCRMCallId($call_id_crm,$portal_call_id);
					echo "call created Successfully.";
					echo "<br>";
					echo "Call ID IN CRM : ".$call_id_crm;
					Exit;
				}else{
				echo "You Dont have Permission to Log Call In CRM";
				exit;
				}
			}
			} 
		}else{
				echo "No Acees Token Found...Please goto Profile and save Valid Access Token";
		}
	}
	if(trim($userInfo['data'][0]['crm_type']) == "AgileCRM")
	{
		$api_token = trim($userInfo['data'][0]['secret']);
		//$email = trim($userInfo['data'][0]['email']);
		$crmurl = trim($userInfo['data'][0]['crm_url']);
		if($api_token)
		{
			if($_GET['status'] == 'dial')
			{
				include_once('controller/agilecrm/search.php');
				
				


				$data = search($numberTOSearch,$api_token,$crmurl,$extension,$username);

			}else if($_GET['status'] == 'disconnected'){
			if($crmFlag)
			{
			if($userInfo['data'][0]['call_log_in_crm'] == "1")
				{
					include_once('controller/agilecrm/call_log.php');
					$call_id_crm = create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$api_token,$crmurl,$Extension,$crm_user_id,$date_start,$date_end,$asterisk_id,$type,$username);
			
					updateCRMCallId($call_id_crm,$portal_call_id);
					echo "call created Successfully.";
					echo "<br>";
					echo "Call ID IN CRM : ".$call_id_crm;
					Exit;
				}else{
				echo "You Dont have Permission to Log Call In CRM";
				exit;
				}
			}
			} 
		}else{
				echo "No Acees Token Found...Please goto Profile and save Valid Access Token";
		}
	}
	if(trim($userInfo['data'][0]['crm_type']) == "Microsoft Dynamics CRM")
	{
		$ms_client_id = trim($userInfo['data'][0]['ms_client_id']);
		$crmurl = trim($userInfo['data'][0]['crm_url']);
		if($ms_client_id)
		{
			if($_GET['status'] == 'dial')
			{
				include_once('controller/msdynamicscrm/search.php');
				$data = search($numberTOSearch,$ms_client_id,$crmurl,$extension,$username,$password);
			}else if($_GET['status'] == 'disconnected'){
			if($crmFlag)
			{
			if($userInfo['data'][0]['call_log_in_crm'] == "1")
				{
					include_once('controller/msdynamicscrm/call_log.php');
					$call_id_crm = create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$ms_client_id,$crmurl,$crm_user_id,$date_start,$date_end,$asterisk_id,$type,$username,$password);
					updateCRMCallId($call_id_crm,$portal_call_id);
					echo "call created Successfully.";
					echo "<br>";
					echo "Call ID IN CRM : ".$call_id_crm;
					Exit;
				}else{
				echo "You Dont have Permission to Log Call In CRM";
				exit;
				}
			}
			} 
		}else{
				echo "No Acees ms_client_id Found...Please goto Profile and save Valid ms_client_id";
		}
	
	}
	if($_GET['status'] == 'dial'){
	$parent_name=$data['name'];
		if($parent_name =="" || $parent_name =="No Contact Name")
		{
			$parent_name = $data['AccountName'];
		}
		echo $asterisk_id." ".$parent_name." ".$data['ID']." ".$data['ModuleName'];
		updateCallLogAfterSearch($asterisk_id,$parent_name,$data['ID'],$data['ModuleName']);
	}
}
?>