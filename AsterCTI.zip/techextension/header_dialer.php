<?php
include_once("controller/route.php");
if(!$_SESSION['tech_user_id'])
{
	echo "<script>location.href='login.php'</script>";
}
include_once "createConference.php";
$url=basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);
$responseData = getProfile($_SESSION['tech_user_id']);
$profileDetails = $responseData['data'];


$company_name = getCompanyName();
$three_company_name = substr($company_name, 0, 3);
if($url == "dialer.php"){
	$visibility = 'display:none;';
	$showvisibility = 'display:inline-block;';
}else{
	$visibility = 'display:inline-block;';
	$showvisibility = 'display:none;';
}

if(isset($_GET['campaign_id'])){
$camapign_id = $_GET['campaign_id'];
$_SESSION['DIALER_CAMPAIGNID'] = $camapign_id;

$info = checkAdminAllowDialerLogin($camapign_id,$_SESSION['tech_user_id']);
$loginAllowStatus = $info['login_status'];

$campaignInfo = getDialerCampaignFromId($camapign_id);
$webformurl = $campaignInfo['data'][0]['webform_url'];
$asterisk_id = $campaignInfo['data'][0]['asterisk'];
$campaign_name = $campaignInfo['data'][0]['name'];
$three_company_name = substr($campaign_name, 0, 3);
$campaign_type = $campaignInfo['data'][0]['type'];
$crm_search = $campaignInfo['data'][0]['crm_search'];
$crm_id = $campaignInfo['data'][0]['crm_id'];
$auto_launch = $campaignInfo['data'][0]['auto_launch'];
}else
{
	echo "<script>location.href='home.php'</script>";
}


?>
<html>
  <head>
  <style>
#dialerbodyhide {
    display: none;
    position: fixed;
    width: 100%;
    height: 100%;
    background-color: #000;
    z-index: 999;
	opacity: 0.6;
    top: 0;
    left: 0;
}
  
</style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $campaign_name; ?> | Dialer</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <?php include "header_css.php"; ?>
	 <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
	<link rel="icon" href="image/favicon.ico" type="image/x-icon">
  </head>
  <?php 
  $backgroundcolor = "#fff";
  ?>
  <body class="hold-transition skin-blue sidebar-mini" style="background-color:<?php echo $backgroundcolor; ?>">
    <div class="wrapper" style="background-color:<?php echo $backgroundcolor; ?>">

      <header class="main-header">
        <!-- Logo -->
        <a href="#" class="logo" style="background-color:#000">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b><?php echo $three_company_name; ?></b></span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b><?php echo $campaign_name; ?></b></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
		  
		  
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
        
              <li class="dropdown user user-menu" style='<?php echo $visibility; ?>'>
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="<?php echo $profileDetails['profile_image']; ?>" class="user-image" alt="User Image">
                  <span class="hidden-xs"><?php echo $profileDetails['name']; ?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="<?php echo $profileDetails['profile_image']; ?>" class="img-circle" alt="User Image">
                    <p>
                      <?php echo $profileDetails['name']; ?> - <?php echo $profileDetails['designation']; ?>
                      
                    </p>
                  </li>
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="profile.php" class="btn btn-default btn-flat">Profile</a>
                    </div>
                    <div class="pull-right">
                      <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
			<li>
			<button class="btn btn-danger" style='margin-top:12px;margin-right:5px;<?php echo $showvisibility; ?>' onclick="logoutUserFromDialer(<?php echo $_SESSION['DIALER_CAMPAIGNID'] ?>)">Logout</button>
			</li>
			    <li>
           <!-- <a href="#" data-toggle="control-sidebar" data-open="controller"><i class="fa fa-gears"></i></a>-->
          </li>
            </ul>
			
			
          </div>
		  
		
        </nav>
		
		
		
		<link rel="stylesheet" type="text/css" href="toastr/toastr.css">
		<script type="text/javascript" src="toastr/toastr.min.js"></script>
		<div id="dialerbodyhide"></div>
      </header>
	     <script>


var dialer_campaign_id = <?php echo json_encode($_SESSION['DIALER_CAMPAIGNID']) ?>;
var user_id = <?php echo json_encode($_SESSION['tech_user_id']) ?>;
var webformurl = <?php echo json_encode($webformurl) ?>;
var auto_launch = <?php echo json_encode($auto_launch) ?>;
var crm_id = <?php echo json_encode($crm_id) ?>;
var campaign_name = <?php echo json_encode($campaign_name) ?>;
var campaign_type = <?php echo json_encode($campaign_type) ?>;

var loginAllowStatus = <?php echo json_encode($loginAllowStatus) ?>;
if(loginAllowStatus == "0"){
	compulsoryLogoutUserFromDialer(dialer_campaign_id);
}
</script>
<?php

	$asteriskInfo = getAsteriskById($asterisk_id);
	$DialerAsteriskIP =$asteriskInfo['data'][0]['ip'];
	$DialerAMIPort =$asteriskInfo['data'][0]['port'];
	$DialerAMIUsername =$asteriskInfo['data'][0]['ami_username'];
	$DialerAMIPassword =$asteriskInfo['data'][0]['ami_password'];
	//checkconference for agent
	$conference_name = "conf-".$_SESSION['user_extension'];
	$result = checkConference($conference_name);
	if($result['count'] == "0"){
		//$kickResp = kickAgentFromConference($DialerAsteriskIP,$DialerAMIPort,$DialerAMIUsername,$DialerAMIPassword,$conference_name,$conferencechannel);
		//sleep(1);
		$resppppp = createConferenceForAgent($DialerAsteriskIP,$DialerAMIPort,$DialerAMIUsername,$DialerAMIPassword,$conference_name,$_SESSION['user_channel'],$campaign_name);
		//print_r($resppppp);
		createConferenceInDB($conference_name,$_SESSION['tech_user_id'],$_SESSION['DIALER_CAMPAIGNID']);
	}else{
		$conferencechannel = $result['data'][0]['channel'];
		$kickResp = kickAgentFromConference($DialerAsteriskIP,$DialerAMIPort,$DialerAMIUsername,$DialerAMIPassword,$conference_name,$conferencechannel);
		if($kickResp == "1"){
			sleep(3);
			$resppppp = createConferenceForAgent($DialerAsteriskIP,$DialerAMIPort,$DialerAMIUsername,$DialerAMIPassword,$conference_name,$_SESSION['user_channel'],$campaign_name);
			createConferenceInDB($conference_name,$_SESSION['tech_user_id'],$_SESSION['DIALER_CAMPAIGNID']);
		}
	}
	
	$_SESSION['DialerAsteriskIP'] = $DialerAsteriskIP ;
	  if($_SESSION['user_extension'])
	  {
	  ?>
		<script>
		var user_extension = <?php echo json_encode($_SESSION['user_extension']) ?>;
		var DialerAsteriskIP = <?php echo json_encode($_SESSION['DialerAsteriskIP']) ?>;
		var asteriskip = <?php echo json_encode($_SESSION['DialerAsteriskIP']) ?>;
		
		
		var path = window.location.pathname;
		var page = path.split("/").pop();
		var admin_value = "n";
		
		// Start For Originate Call Dialer //
		var user_context = <?php echo json_encode($profileDetails['context']); ?>;
		var user_channel = <?php echo json_encode($profileDetails['channel']); ?>;
		var user_prefix = <?php echo json_encode($profileDetails['prefix']); ?>;
		var conference = <?php echo json_encode($conference_name) ?>;
		
		// End For Originate Call Dialer //
		
		</script>
			<script type="text/javascript" src="dist/js/jWebSocket.js"></script>
			<script type="text/javascript" src="dist/js/techextension.js"></script>
		
	  <?php 
	  }else
	  {
	  ?>
	  <script>
	  toastr["warning"]("Important : Please Enter your Extension in Profile First")
	  </script>

	  <?php  } ?>






<script>
// ====================================================== Window close or tab close detect : kick user from conference ======================================================
 jQuery(document).ready( 
    function () { 
      jQuery(window).bind('beforeunload',  
        function (e) {
			//console.log(e);
			changeUserStatus("0");
			 $.ajax({url: "kickFromConference.php?action=kick&conference="+conference+"&campaign_id="+dialer_campaign_id, success: function(newresule){
				// window.close();
			 }});
        } 
      );
    } 
  );
// ===================================================== End Of Window close or tab close detect : kick user from conference =================================================

var conference_user_channel;
      $("#dialerbodyhide").show();
	  if(campaign_type == "PREDICTIVE"){
		runPredictiveDialer();
	  }else if(campaign_type == "POWER"){
		runPowerDialer();
	  }
	  
	  
// ********************************************* Start OF Predictive Dialer ***********************************************//
	  
function checkChannelForConference() {
$.ajax({url: "conference_log.php?action=checkChannelForConference&ConferenceName="+conference, success: function(result){
//result="1";
console.log("conference channel : "+result);
if(result == "0"){
 $("#dialerbodyhide").show();
}else{
	 $("#dialerbodyhide").hide();
	 conference_user_channel = result;
	  $.ajax({url: "start_dialer.php?campaign_id="+dialer_campaign_id+"&user_id="+user_id+"&conference_user_channel="+conference_user_channel+"&conference_number="+conference, success: function(result){
		 console.log(result);
		if(result.indexOf("**") != -1){
		idArray = result.split('**');
		contact_id = idArray[1];
		document.getElementById("full-screen-me").src = "update_contact.php?action=Edit&id="+contact_id;
			if(auto_launch == "CRM"){
				if(crm_id){
					showInCRM();
				}
			}else if(auto_launch == "WEBFORM"){
				if(webformurl){
					changeIframe();
				}
			}
		}else if(result == "LIST_FINISHED"){
			stopPredictiveDialer();
			//toastr["warning"]("Calling List From Campaign is Finished...No new number to call");
			document.getElementById("full-screen-me").src = "";
			//$("#dialerbodyhide").show();
			$('#modal-info').modal('hide');
			$('#model_list_finish').modal('show');
		}else if(result.indexOf("||") != -1){
			idArray = result.split('||');
		 $.ajax({url: "conference_log.php?action=checkLiveCallStatus&list_id="+idArray[0], success: function(live_call_result){
			 console.log("Call  Found : "+live_call_result);
				var livecallstatusobj = JSON.parse(live_call_result);
				live_call_result = livecallstatusobj.status;
				unique_id = livecallstatusobj.unique_id;
		if(live_call_result == "1"){
			$(".navbar").css("background-color", "#b33813");
			stopPredictiveDialer();
			$('#modal-info').modal('show');
		}else if(live_call_result == "2"){
			$(".navbar").css("background-color", "#e8e44e");
			$("#hangup_button").attr("disabled", false);
			//connected status
		}else if(live_call_result == "3"){
			$("#manualdialerID").prop('disabled', true);
			$(".navbar").css("background-color", "#27d425");
			$("#hangup_button").attr("disabled", false);
			//dial status
		}else{
			$(".navbar").css("background-color", "#3c8dbc");
		}
			}});
		}
		}});
}
 }});
}

function runPredictiveDialer(){
	 interval = setInterval( checkChannelForConference , 1000);
}
function stopPredictiveDialer()
{
	clearInterval(interval);
}


function restartPredictiveDialerWithDisposition(disposition)
{
	//console.log(unique_id);
		$('#modal-info').modal('hide');
		toastr["success"]("Disposition Set Successfully");
	console.log("conference_log.php?action=addDisposition&list_id="+idArray[0]+"&disposition="+disposition+"&unique_id="+unique_id+"&user_id="+user_id);
	$.ajax({url: "conference_log.php?action=addDisposition&list_id="+idArray[0]+"&disposition="+disposition+"&unique_id="+unique_id+"&user_id="+user_id, success: function(newresule){
		console.log("Agent Disposition result : "+newresule);
		 $.ajax({url: "conference_log.php?action=removeLiveCallFromList&list_id="+idArray[0], success: function(newresule){
			runPredictiveDialer();
			
		}});
	}});
	
}

// ********************************************* END OF Predictive Dialer ***********************************************//


// ************************************************* POWER DIALER **********************************************************//
function runPowerDialer(){
	intervalpowerdialer = setInterval( checkConferenceAvailable , 1000);
}

function stopPowerDialer()
{
	clearInterval(intervalpowerdialer);
}

function StopintervalofPreviousCallChecker()
{
	clearInterval(intervalofPreviousCallChecker);
}

function checkConferenceAvailable(){
	$.ajax({url: "conference_log.php?action=checkChannelForConference&ConferenceName="+conference, success: function(result){
		console.log(result);
		//result="1";
		conference_user_channel = result;
		if(result == "0"){
			$("#dialerbodyhide").show();
		}else{
			$("#dialerbodyhide").hide();
		}
	}});	
}

function nextCall(){
  	 //console.log(conference_user_channel);
	 //console.log(conference);
	 //console.log(user_id);
	 //console.log(dialer_campaign_id);
	  $.ajax({url: "start_dialer.php?campaign_id="+dialer_campaign_id+"&user_id="+user_id+"&conference_user_channel="+conference_user_channel+"&conference_number="+conference, success: function(result){
		 console.log(result);
		if(result.indexOf("**") != -1){
		idArray = result.split('**');
		contact_id = idArray[1];
		document.getElementById("full-screen-me").src = "update_contact.php?action=Edit&id="+contact_id;
		intervalofPreviousCallChecker = setInterval(checkPreviousCallDisconnect, 1000,idArray);
		
		if(auto_launch == "CRM"){
				if(crm_id){
					showInCRM();
				}
			}else if(auto_launch == "WEBFORM"){
				if(webformurl){
					changeIframe();
				}
			}
		
		}else if(result == "LIST_FINISHED"){
			stopPowerDialer();
			//toastr["warning"]("Calling List From Campaign is Finished...No new number to call");
			document.getElementById("full-screen-me").src = "";
			//$("#dialerbodyhide").show();
			$('#modal-info').modal('hide');
			$('#model_list_finish').modal('show');
		}else if(result.indexOf("||") != -1){
			idArray = result.split('||');
			intervalofPreviousCallChecker = setInterval(checkPreviousCallDisconnect, 1000,idArray);
			$('#modal-info').modal('show');
		}else if(result == "PAUSED"){
			toastr["warning"]("Please Resume to Start Calling");
		}
		
function checkPreviousCallDisconnect(idArray){
	 $.ajax({url: "conference_log.php?action=checkLiveCallStatus&list_id="+idArray[0], success: function(live_call_result){
	 console.log("Call Status Found : "+live_call_result);
	var livecallstatusobj = JSON.parse(live_call_result);
	live_call_result = livecallstatusobj.status;
	unique_id = livecallstatusobj.unique_id;
		if(live_call_result == "1"){
			//disconnect
			$(".navbar").css("background-color", "#b33813");
			$('#modal-info').modal('show');
			StopintervalofPreviousCallChecker();
			$("#next_call").attr("disabled", false);
			$("#hangup_button").attr("disabled", true);
		}else if(live_call_result == "2"){
			//connected status
			$(".navbar").css("background-color", "#e8e44e");
			$("#next_call").attr("disabled", true);
			$("#hangup_button").attr("disabled", false);
			
			//$("#mute_button").prop('disabled', false);
			
		}else if(live_call_result == "3"){
			//dial status
			$("#manualdialerID").prop('disabled', true);
			$(".navbar").css("background-color", "#27d425");
			$("#next_call").attr("disabled", true);
			$("#hangup_button").attr("disabled", false);
		}else{
			$(".navbar").css("background-color", "#3c8dbc");
		}
			}});
		}
		}});
}



function saveDispositionForPowerDialer(disposition)
{
	$('#modal-info').modal('hide');
			toastr["success"]("Disposition Set Successfully");
	console.log("conference_log.php?action=addDisposition&list_id="+idArray[0]+"&disposition="+disposition+"&unique_id="+unique_id+"&user_id="+user_id);
	$.ajax({url: "conference_log.php?action=addDisposition&list_id="+idArray[0]+"&disposition="+disposition+"&unique_id="+unique_id+"&user_id="+user_id, success: function(newresule){
		console.log("Agent Disposition result : "+newresule);
		 $.ajax({url: "conference_log.php?action=removeLiveCallFromList&list_id="+idArray[0], success: function(newresule){
			
		}});
	}});
	
}


// ************************************************* END POWER DIALER **********************************************************//



// *********************************** HangupCall Call **********************************************//

function hangupCall(){
	$.ajax({url: "start_dialer.php?action=hangup&list_id="+idArray[0]+"&campaign_id="+dialer_campaign_id, success: function(newresule){
		console.log(newresule);
		}});
}
	

// *********************************** End Of HangupCall Call **********************************************//

function muteCall(status){
	
	console.log(status);
	var whattodo;
	if(status == "1"){
		//$("#mute_button").prop('disabled', true);
		//$("#unmute_button").prop('disabled', false);
		$("#unmute_button").show();
		$("#mute_button").hide();
		whattodo="mute";
	}else{
		//$("#mute_button").prop('disabled', false);
		//$("#unmute_button").prop('disabled', true);
		$("#unmute_button").hide();
		$("#mute_button").show();
		whattodo="unmute";
	}
	
		$.ajax({url: "start_dialer.php?action=muteUnmute&conference="+conference+"&campaign_id="+dialer_campaign_id+"&whattodo="+whattodo, success: function(newresule){
			console.log(newresule);
		}});
	
}
function parkCall(status){
	console.log(status);
	var whattodo;
	if(status == "1"){
		//$("#mute_button").prop('disabled', true);
		//$("#unmute_button").prop('disabled', false);
		$("#unpark_button").show();
		$("#park_button").hide();
		whattodo="park";
	}else{
		//$("#mute_button").prop('disabled', false);
		//$("#unmute_button").prop('disabled', true);
		$("#unpark_button").hide();
		$("#park_button").show();
		whattodo="unpark";
	}
	
		$.ajax({url: "start_dialer.php?action=parkUnpark&conference="+conference+"&campaign_id="+dialer_campaign_id+"&whattodo="+whattodo, success: function(newresule){
			console.log(newresule);
		}});
}



//================================Call Originate Manual Dialer ==========================================================================
function originateCalls()
{
	flag=0;
	var callto = $('#callto').val();
	if(callto.indexOf('+') == 0) {
		flag=1;
	}
	console.log(callto);
	callto = callto.replace(/\D/g,'');
	if(flag == 1){
		callto = "+"+callto;
	}else{
		flag =0;
	}
	console.log(callto);
		//var callto = $('#callto').text()
		if(!callto){
			toastr["warning"]("Please Enter Digits to make call")
		}else{
			console.log("call from GUI Dialer : "+callto)
			//originateCall(callto,user_context,user_channel,user_extension,user_prefix);
			
			  $.ajax({url: "start_dialer.php?campaign_id="+dialer_campaign_id+"&user_id="+user_id+"&conference_user_channel="+conference_user_channel+"&conference_number="+conference+"&manualcall=yes"+"&phone="+callto, success: function(result){
		 console.log(result);
		if(result.indexOf("**") != -1){
		idArray = result.split('**');
		contact_id = idArray[1];
		//document.getElementById("full-screen-me").src = "update_contact.php?action=Edit&id="+contact_id;
		intervalofPreviousCallChecker = setInterval(checkPreviousCallDisconnect, 1000,idArray);
		}else if(result == "LIST_FINISHED"){
			stopPowerDialer();
			//toastr["warning"]("Calling List From Campaign is Finished...No new number to call");
			document.getElementById("full-screen-me").src = "";
			//$("#dialerbodyhide").show();
			$('#modal-info').modal('hide');
			$('#model_list_finish').modal('show');
		}else if(result.indexOf("||") != -1){
			idArray = result.split('||');
			intervalofPreviousCallChecker = setInterval(checkPreviousCallDisconnect, 1000,idArray);
			$('#modal-info').modal('show');
		}else if(result == "PAUSED"){
			toastr["warning"]("Please Resume to Start Calling");
		}
		
function checkPreviousCallDisconnect(idArray){
	 $.ajax({url: "conference_log.php?action=checkLiveCallStatus&list_id="+idArray[0], success: function(live_call_result){
	 console.log("Call Status Found : "+live_call_result);
	var livecallstatusobj = JSON.parse(live_call_result);
	live_call_result = livecallstatusobj.status;
	unique_id = livecallstatusobj.unique_id;
		if(live_call_result == "1"){
			//disconnect
			$("#manualdialerID").attr("disabled", false);
			$("#resumebutton").prop('disabled', false);
			$(".navbar").css("background-color", "#b33813");
			$('#modal-info').modal('show');
			StopintervalofPreviousCallChecker();
			$("#next_call").attr("disabled", false);
			$("#hangup_button").attr("disabled", true);
		}else if(live_call_result == "2"){
			//connected status
			$(".navbar").css("background-color", "#e8e44e");
			$("#next_call").attr("disabled", true);
			$("#hangup_button").attr("disabled", false);
			
			//$("#mute_button").prop('disabled', false);
			
		}else if(live_call_result == "3"){
			//dial status
			$("#manualdialerID").attr("disabled", true);
			$("#resumebutton").prop('disabled', true);
			$(".navbar").css("background-color", "#27d425");
			$("#next_call").attr("disabled", true);
			$("#hangup_button").attr("disabled", false);
		}else{
			$(".navbar").css("background-color", "#3c8dbc");
		}
			}});
		}
		}});
		}
	
}
//================================END of Call Originate Manual Dialer ==========================================================================

// ==============================  On Log Out Campaign  ===============================================
function logoutUserFromDialer(campaign_id)
{
	var r = confirm("Are you Sure? Want to Logout.");
		if (r == true) {
	 $.ajax({url: "getUpdatedCallInformation.php?logoutUserFromDialer=yes&user_id="+user_id+"&campaign_id="+campaign_id, success: function(newresule){
		
			 $.ajax({url: "kickFromConference.php?action=kick&conference="+conference+"&campaign_id="+campaign_id, success: function(newresule){
				 window.close();
			 }});
		
		 }});
		 }
}

// ==============================  On Compulsory whene User Not Allowed in Campaign  ===============================================
function compulsoryLogoutUserFromDialer(campaign_id)
{
	 $.ajax({url: "getUpdatedCallInformation.php?logoutUserFromDialer=yes&user_id="+user_id+"&campaign_id="+campaign_id, success: function(newresule){
		
			 $.ajax({url: "kickFromConference.php?action=kick&conference="+conference+"&campaign_id="+campaign_id, success: function(sss){
				 window.close();
			 }});
		
		 }});
}


// =========================================== Change Status in GUI and logout from campaign ======================================================
function changeUserStatus(status){
if(status == "0")
{
	//pause
	$("#manualdialerID").prop('disabled', false);
	$("#resumebutton").prop('disabled', false);
	$("#pausebutton").prop('disabled', true);
	$('#useronlinestatus').removeClass('fa fa-circle text-success').addClass('fa fa-circle text-warning');
	$("#useronlinestatusvalue").html('Pause');
}else{
	//resume
	$("#manualdialerID").prop('disabled', true);
	$("#resumebutton").prop('disabled', true);
	$("#pausebutton").prop('disabled', false);
	$('#useronlinestatus').removeClass('fa fa-circle text-warning').addClass('fa fa-circle text-success');
	$("#useronlinestatusvalue").html('Online');
}
	
$.ajax({url: "getUpdatedCallInformation.php?changeAgentStatusInCampaign=login&user_id="+user_id+"&campaign_id="+dialer_campaign_id+"&status="+status, success: function(result){
console.log(result);
		}});
}

// =========================================== End of Change Status in GUI and logout from campaign ======================================================

function showInCRM(){
	
	if (typeof contact_id !== 'undefined') {
		console.log("contact_id : "+contact_id);
		crmurl = "dialer_crm.php?campaign_id="+dialer_campaign_id+"&contact_id="+contact_id;
		window.open(crmurl, '_blank');
	}else{
		toastr["warning"]("No Any Contact Found In AsterCTI..")
	}
	
}

function reloadPage()
{
	location.reload();
}

</script>
<?php
$disposition_list = getDialerDisposition($camapign_id);
if($disposition_list['count'] == "0"){
	$disposition_list = getAllDialerDisposition();
}
?>
       <div class="modal modal-default fade" id="modal-info" data-keyboard="false" data-backdrop="static">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header" style="background-color:#5fd2ef6e">
               
                <h4 class="modal-title"> <strong>Select Disposition</strong></h4>
              </div>
              <div class="modal-body mb-0 text-center">
               <?php
			  if($campaign_type == "PREDICTIVE"){
				  $functionToCall = "restartPredictiveDialerWithDisposition";
			  }else if($campaign_type == "POWER"){
				  $functionToCall = "saveDispositionForPowerDialer";
			  }
			  ?>
			   <a href="#"><span onclick="<?php echo $functionToCall;?>('ANSWERING MACHINE')" class="btn-floating btn-tw" style="font-size: 20px;color: fff;padding-right:30px;padding-top:40px;">ANSWERING MACHINE</span></a>
			   
			   
			   <a href="#"><span onclick="<?php echo $functionToCall;?>('DEAD')" class="btn-floating btn-tw" style="font-size: 20px;color: fff;padding-right:30px;padding-top:40px;">DEAD</span></a>
			   
			  <?php
			   for($i=0;$i<$disposition_list['count'];$i++){
			   ?>
					<a href="#"><span onclick="<?php echo $functionToCall;?>('<?php echo $disposition_list['data'][$i]['disposition'] ?>')" class="btn-floating btn-tw" style="font-size: 20px;color: fff;padding-right:30px;padding-top:40px;"><?php echo $disposition_list['data'][$i]['disposition'] ?></span></a>
			   <?php } ?>
              </div>
            
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
		
		
		    <div class="modal modal-default fade" id="model_list_finish" data-keyboard="false" data-backdrop="static">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header" style="background-color:#5fd2ef6e">
               
                <h4 class="modal-title"> <strong>Calling List Finished</strong></h4>
              </div>
              <div class="modal-body mb-0 text-center">
             <p>Please <span onclick="reloadPage()"><b>click here</b></span> to start again</p>
              </div>
            
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
		