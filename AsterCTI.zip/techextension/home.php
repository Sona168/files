<?php include "header.php" ?>
<?php include "left_sidebar.php" ?>
<?php
$callCountData = getUserCallCountWithStatus($_SESSION['tech_user_id']);
$dialerCount = getUserCallCountDialer($_SESSION['tech_user_id'])
?>
 
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper" id="main_body">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Dashboard
            <small>Of the Day</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
		   <div class="box-body">
          <div class="row">
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-aqua">
                <div class="inner">
                  <h3><?php echo $callCountData['allCalls']+$dialerCount['allCalls']; ?></h3>
                  <p>Total Calls</p>
                </div>
                <div class="icon">
                  <i class="ion ion-ios-telephone"></i>
                </div>
                
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3><?php echo $callCountData['inboundCount']; ?></h3>
                  <p>Incoming Calls</p>
                </div>
                <div class="icon">
                  <i class="ion ion-android-arrow-down"></i>
                </div>
               
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                  <h3><?php echo $callCountData['outboundCount']+$dialerCount['outboundCount']; ?></h3>
                  <p>Outgoing Calls</p>
                </div>
                <div class="icon">
                  <i class="ion ion-android-arrow-up"></i>
                </div>
                
              </div>
			  
            </div><!-- ./col -->
			
			<div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box" style="background-color:#9d78b9">
                <div class="inner">
                  <h3 style="color:#fff;"><?php echo $callCountData['internalCount']; ?></h3>
                  <p style="color:#fff;">Internal Calls</p>
                </div>
                <div class="icon">
                  <i class="ion ion-android-arrow-up"></i>
                </div>
                
              </div>
			  
            </div>
			
			
			
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-red">
                <div class="inner">
                  <h3><?php echo $callCountData['duration']+$dialerCount['duration']; ?></h3>
                  <p>Total Duration(Seconds)</p>
                </div>
                <div class="icon">
                  <i class="ion ion ion-stats-bars"></i>
                </div>
              
              </div>
            </div><!-- ./col -->
          </div><!-- /.row -->
		  </div>
          <!-- Main row -->
		  
		  <?php
		  $meetingData = getTodayMeeting($_SESSION['tech_user_id']);
		  ?>
		   
            <div class="box-body">
			<div class="row">
				<div class="col-lg-3 col-xs-6">
				  <!-- small box -->
				  <div class="small-box bg-aqua">
					<div class="inner">
					  <h3 id="call_done"><?php echo $meetingData['count']; ?></h3>

					  <p>Todays Total Meetings</p>
					</div>
					<div class="icon" style="top:4px;right:35px;font-size:50px;color:#0000004d;">
					  <i class="fa fa-users"></i>
					</div>
					
				  </div>
				</div>
				
				<div class="col-lg-3 col-xs-6">
				  <!-- small box -->
				  <div class="small-box bg-green">
					<div class="inner">
					  <h3 id="call_done"><?php echo $meetingData['held_meeting']; ?></h3>

					  <p>Held Meeting</p>
					</div>
					<div class="icon" style="top:4px;right:35px;font-size:50px;color:#0000004d;">
					  <i class="fa fa-handshake-o"></i>
					</div>
					
				  </div>
				</div>
				
				
				<div class="col-lg-3 col-xs-6">
				  <!-- small box -->
				  <div class="small-box bg-yellow">
					<div class="inner">
					  <h3 id="call_done"><?php echo $meetingData['planned_meeting']; ?></h3>

					  <p>Planned Meeting</p>
					</div>
					<div class="icon" style="top:4px;right:35px;font-size:50px;color:#0000004d;">
					  <i class="fa fa-clock-o"></i>
					</div>
					
				  </div>
				</div>
				
				
				<div class="col-lg-3 col-xs-6">
				  <!-- small box -->
				  <div class="small-box bg-red">
					<div class="inner">
					  <h3 id="call_done"><?php echo $meetingData['notheld_meeting']; ?></h3>

					  <p>Not Held Meeting</p>
					</div>
					<div class="icon" style="top:4px;right:35px;font-size:50px;color:#0000004d;">
					  <i class="fa fa-tasks"></i>
					</div>
					
				  </div>
				</div>
				
				
				
				
				</div>
				</div>
			
		  
		  
		  
		  <div class="row">
        <div class="col-md-6">
              <div class="box box-success">
			   <div class="box-header with-border">
              <h3 class="box-title">Recent Calls (Other then Dialer Calls)</h3>
            </div>
             <?php
			 $data =getRecentLogs($_SESSION['tech_user_id']);
			 if($data['count'] > 0){
			 ?>
           
				
				
			   <table class="table table-striped">
                <tr style="font-size:13px;">
                  <th style="width: 10px">#</th>
                  <th>Contact Name</th>
				  <th>Number</th>
                  <th>Direction</th>
                  <th>Disposition</th>
				  <th>Duration</th>
                </tr>
					<?php
				$j=0;
				for($i=0;$i<$data['count'];$i++)
				{
					if($data['data'][$i]['direction'] == 'inbound')
					{
						$number = $data['data'][$i]['source_number'];
					}else
					{
						$number = $data['data'][$i]['destination_number'];
					}
					$j++;
					if($data['data'][$i]['contact_id']){
						$contactInfo = getContact($data['data'][$i]['contact_id']);
						$contact_name = $contactInfo['data'][0]['first_name']." ".$contactInfo['data'][0]['last_name'];
					}else{
						$contact_name="";

					}
				?>
                <tr style="font-size:13px;">
				
				
                  <td><?php echo $j; ?></td>
                  <td><?php echo $contact_name; ?></td>
				  <td><?php echo $number; ?></td>
                   <td><?php echo $data['data'][$i]['direction']; ?></td>
				    <td><?php echo $data['data'][$i]['desposition']; ?></td>
                  <td><span class="badge bg-red"><?php echo $data['data'][$i]['call_second']; ?></span></td>
                </tr>
                <?php }?>
              </table>
			  
			 <?php } else { ?>
			 <div class="callout callout-warning">
                <h4>No Recent Calls for Today</h4>

                <p>Start Calling to get recent 5 calls</p>
              </div>
			 <?php } ?>
          
              </div><!-- /.box -->

            </div>
			
			
            <div class="col-md-6">
              <div class="box box-success">
			   <div class="box-header with-border">
              <h3 class="box-title">Today's Meetings</h3>
            </div>
             <?php
			 if($meetingData['count'] > 0){
			 ?>
           
			   <table class="table table-striped">
                <tr style="font-size:13px;">
                  <th style="width: 10px">#</th>
                  <th>Subject</th>
				  <th>Contact</th>
				  <th>Number</th>
                  <th>Status</th>
                  <th>Start Time</th>
				 
                </tr>
					<?php
				$j=0;
				for($i=0;$i<$meetingData['count'];$i++)
				{
					
					$j++;
					if($meetingData['data'][$i]['contact_id']){
						$contactInfo = getContact($meetingData['data'][$i]['contact_id']);
						$contact_name = $contactInfo['data'][0]['first_name']." ".$contactInfo['data'][0]['last_name'];
						if($contactInfo['data'][0]['phone']){
							$number = $contactInfo['data'][0]['phone'];
						}else{
							$number = $contactInfo['data'][0]['phone2'];
						}
						$prefix = $contactInfo['data'][0]['prefix'];
					}else{
						$contact_name="Contact Deleted";
					}
				?>
                <tr style="font-size:13px;">
				
				
                  <td><?php echo $j; ?></td> 
                  <td><a target="_blank" href="meeting_info.php?action=Edit&id=<?php echo $meetingData['data'][$i]['id']; ?>"><?php echo shortText(urldecode($meetingData['data'][$i]['subject'])); ?></a></td>
				  <td><a target="_blank" href="contact_details.php?action=View&id=<?php echo $meetingData['data'][$i]['contact_id'];  ?>"><?php echo $contact_name; ?></a></td>
				  <td><?php echo $number; ?>
				  <br>&nbsp;
				   <a href="#"><img src="image/caller.png" height="20px" width="20px" title="Click to Call" onclick="originateDirectCall('<?php echo $prefix."".$number; ?>')" /></a>
<?php  if($smsFlag) {?>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><img src="image/send_sms.png"  data-toggle="modal" data-target="#send_sms" height="20px" width="20px" title="Send SMS" onclick="setTosend('<?php echo $number; ?>','<?php echo $meetingData['data'][$i]['contact_id']; ?>','<?php echo $contact_name; ?>')"/></a> </td>
<?php
}
?>
				  
				  <input type="hidden" id="to_send">
				  </td>
                   <td><?php echo $meetingData['data'][$i]['status']; ?></td>
				    <td><?php echo $meetingData['data'][$i]['start_time']; ?></td>
                  
                </tr>
                <?php }?>
              </table>
			  
			 <?php } else { ?>
			 <div class="callout callout-warning">
                <h4>No Meeting Today</h4>

                <p>Create Meeting to view it.</p>
              </div>
			 <?php } ?>
          
              </div><!-- /.box -->

            </div><!-- /.col (RIGHT) -->
			
			 <div class="col-md-12">
              <div class="box box-success">
			  
			   <div class="box-header with-border">
              <h3 class="box-title">Recent Dialer Calls</h3>
            </div>
             <?php
			 $dialerRecentCalls =getRecentDialerLogs($_SESSION['tech_user_id']);
			 if($dialerRecentCalls['count'] > 0){
			 ?>
           
				<table class="table table-striped">
                <tbody>
				<tr style="font-size:13px;">
                  <th style="width: 10px">#</th>
                  <th>Contact Name</th>
				  <th>Contact Number</th>
				  <th>Campaign Name</th>
                  <th>Disposition</th>
				  <th>Agent Dispo</th>
                  <th>Duration</th>
                </tr>
				<?php $k=0;
				for($j=0;$j<$dialerRecentCalls['count'];$j++){
					$k++;
					if($dialerRecentCalls['data'][$j]['contact_id']){
					$contactDetails = getContact($dialerRecentCalls['data'][$j]['contact_id']);
					$contact_name= $contactDetails['data'][0]['first_name']." ".$contactDetails['data'][0]['last_name'];
					}else{
						$contact_name = "Manual Call";
					}
					$campaignDetails = getDialerFromCampaignId($dialerRecentCalls['data'][$j]['campaign_id']);
					$campaign_name= $campaignDetails['data'][0]['name'];
					?>
                <tr style="font-size:13px;">
				
                  <td><?php echo $k; ?>.</td>
                  <td><?php echo $contact_name; ?></td>
				  <td><?php echo $dialerRecentCalls['data'][$j]['destination']; ?></td>
				  <td><?php echo $campaign_name; ?></td>
				  <td><?php echo $dialerRecentCalls['data'][$j]['disposition']; ?></td>
				  <td><?php echo $dialerRecentCalls['data'][$j]['agent_disposition']; ?></td>
				  <td><?php echo $dialerRecentCalls['data'][$j]['duration']; ?></td>
                </tr>
				<?php } ?>
              </tbody>
			  </table>
			 <?php }else { ?>
			 
			 <div class="callout callout-warning">
                <h4>No Recent Calls from Dialer for Today</h4>
                <p>login to Dialer to Start Calling</p>
              </div>
			 <?php } ?>
              </div>

            </div>
			
			
			
          </div>
		  
		  
		      <div class="row" id='pieChartDiv' >
              <div class="col-md-6">

              <!-- DONUT CHART -->
              <div class="box box-danger">
                <div class="box-header with-border">
                  <h3 class="box-title">Total Calls (Desposition) : <?php echo $callCountData['allCalls']+$dialerCount['allCalls']; ?></h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div>
					<div class="col-md-6">
                  <ul class="chart-legend clearfix" id="information">
                    <li><span style="width:15px; height:15px; background-color:#f2322b; margin-right:10px;display:block; float:left;"></span> Not Answered</li>
                    <li><span style="width:15px; height:15px; background-color:#00a65a; margin-right:10px;display:block; float:left;"></span>Answered</li>
                    <li><span style="width:15px; height:15px; background-color:#f19b2a; margin-right:10px;display:block; float:left;"></span>Failed</li>
                    <li><span style="width:15px; height:15px; background-color:#f4f442; margin-right:10px;display:block; float:left;"></span>Busy</li>
                   
                  </ul>
                </div>
				  <div class="col-md-12">
                <div class="box-body">
                    <canvas id="pieChart" style="height:250px"></canvas>
                </div><!-- /.box-body -->
				</div>
			
              </div><!-- /.box -->
			   </div>

            </div><!-- /.col (LEFT) -->
		  
		  
		  
		    <div class="row">
		     <div class="box box-info" id='pieChartLine'>
            <div class="box-header with-border">
              <h3 class="box-title">Hourly Calls Chart</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <canvas id="lineChart" style="height:250px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
		  </div>
		  
		  
	
          
        </section>
      </div>
	     
    <!-- Bootstrap 3.3.5 -->

    <?php
	  include "footer.php";
	  //include "control_sidebar.php";
	  include "footer_script.php";
	  ?>
    <script>
	
/* 		function generatePopup(id)
	{
	$(".windowOpenn"+id).fadeToggle(); 
	}
 */
 
 
 function setTosend(number,id,name){
			contact_id = id;
			contact_name = name;
		$('#phone_tosend').html("Send SMS To : "+number)
		$('#to_send').val(number)
	}
 
	  $(function () {
		  
		  
var dataRecievedForPie='';
     	$.ajax({url: "te-admin/getBarChartData.php?pieHome&user", success: function(resultPie){
		//console.log(resultPie);
		dataRecievedForPie= resultPie;
		}});
		
		
var dataRecievedForLine='';
     	$.ajax({url: "te-admin/getBarChartData.php?lineChart&user", success: function(resultPie){
		//console.log(resultPie);
		dataRecievedForLine= resultPie;
		}});
		
		setTimeout(function (){	
		//console.log(dataRecievedForPie);
		
	  //console.log(dataRecievedForPie);
	  var obj = JSON.parse(dataRecievedForPie);
        //-------------
        //- PIE CHART -
        //-------------
        // Get context with jQuery - using jQuery's .get() method.
        var pieChartCanvas = $("#pieChart").get(0).getContext("2d");
        var pieChart = new Chart(pieChartCanvas);
		/* var recieve = document.getElementById('recieve').value;
		var missed = document.getElementById('missed').value;
		var failed = document.getElementById('failed').value; */

		if(obj.noanswer == "0" && obj.failed == "0" && obj.busy == "0" && obj.answered == "0"){
			$( '#information' ).text( "No Any Calls For today to show in Chart" );
		}else{
        var PieData = [
          {
            value: obj.noanswer,
            color: "#f2322b",
            highlight: "#f2322b",
            label: "Not Answered"
          },
          {
            value: obj.failed,
            color: "#f19b2a",
            highlight: "#f19b2a",
            label: "Failed"
          },
          {
            value: obj.busy,
            color: "#f4f442",
            highlight: "#f4f442",
            label: "Busy"
          },
		   {
            value: obj.answered,
            color: "#00a65a",
            highlight: "#00a65a",
            label: "Answered"
          },
         
         
        ];
        var pieOptions = {
          //Boolean - Whether we should show a stroke on each segment
          segmentShowStroke: true,
          //String - The colour of each segment stroke
          segmentStrokeColor: "#fff",
          //Number - The width of each segment stroke
          segmentStrokeWidth: 2,
          //Number - The percentage of the chart that we cut out of the middle
          percentageInnerCutout: 50, // This is 0 for Pie charts
          //Number - Amount of animation steps
          animationSteps: 100,
          //String - Animation easing effect
          animationEasing: "easeOutBounce",
          //Boolean - Whether we animate the rotation of the Doughnut
          animateRotate: true,
          //Boolean - Whether we animate scaling the Doughnut from the centre
          animateScale: false,
          //Boolean - whether to make the chart responsive to window resizing
          responsive: true,
          // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
          maintainAspectRatio: true,
          //String - A legend template
          legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>"
        };
        //Create pie or douhnut chart
        // You can switch between pie and douhnut using the method below.
        pieChart.Doughnut(PieData, pieOptions);
		}
}, 2000);
      
    

	
	  setTimeout(function (){	
	  
	 if(dataRecievedForLine)
	{
	  var objLine = JSON.parse(dataRecievedForLine);
	  
	  console.log(objLine);
	 // var abbb = '65, 59, 80, 81, 56, 55, 40,65, 59, 80, 81, 56, 55, 40,65, 59, 80, 81, 56, 55, 40, 56, 55, 40';
	  //var cars = ['65, 59, 80, 81, 56, 55, 40,65, 59, 80, 81, 56, 55, 40,65, 59, 80, 81, 56, 55, 40, 56, 55, 40'];
	  var areaChartData = {
      labels  : ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'],
      datasets: [

        {
          label               : 'Digital Goods',
          fillColor           : 'rgba(60,141,188,0.9)',
          strokeColor         : 'rgba(60,141,188,0.8)',
          pointColor          : '#3b8bba',
          pointStrokeColor    : 'rgba(60,141,188,1)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(60,141,188,1)',
          data                : objLine
        }
      ]
    }
	  
	  
	   var areaChartOptions = {
      //Boolean - If we should show the scale at all
      showScale               : true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines      : false,
      //String - Colour of the grid lines
      scaleGridLineColor      : 'rgba(0,0,0,.05)',
      //Number - Width of the grid lines
      scaleGridLineWidth      : 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines  : true,
      //Boolean - Whether the line is curved between points
      bezierCurve             : true,
      //Number - Tension of the bezier curve between points
      bezierCurveTension      : 0.3,
      //Boolean - Whether to show a dot for each point
      pointDot                : false,
      //Number - Radius of each point dot in pixels
      pointDotRadius          : 4,
      //Number - Pixel width of point dot stroke
      pointDotStrokeWidth     : 1,
      //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
      pointHitDetectionRadius : 20,
      //Boolean - Whether to show a stroke for datasets
      datasetStroke           : true,
      //Number - Pixel width of dataset stroke
      datasetStrokeWidth      : 2,
      //Boolean - Whether to fill the dataset with a color
      datasetFill             : true,
      //String - A legend template
      legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].lineColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
      //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio     : true,
      //Boolean - whether to make the chart responsive to window resizing
      responsive              : true
    }
	  
	   var lineChartCanvas          = $('#lineChart').get(0).getContext('2d')
    var lineChart                = new Chart(lineChartCanvas)
    var lineChartOptions         = areaChartOptions
    lineChartOptions.datasetFill = false
    lineChart.Line(areaChartData, lineChartOptions)
	  }else
	  {
		  $( '#pieChartLine' ).text( "No Data Found" );
	  }
	  }, 2000);
			
	  });
	  
	</script>

	 
	  
  </body>
</html>
