<?php
include "controller/route.php";
if(isset($_GET['action'])){
	if($_GET['action'] == "bridgeConf")
	{
		$conferencename = $_GET['ConferenceName'];
		$conferencechannel = $_GET['ConferenceChannel'];
		updateChannelInConference($conferencename,$conferencechannel);
		agentLoginLogoutDialer($conferencename,$conferencechannel,"1");
	}
	
	if($_GET['action'] == "leaveConf")
	{
		$conferencename = $_GET['ConferenceName'];
		agentLoginLogoutDialer($conferencename,"","0");
		removeConferenceInDB($conferencename);
	}
	if($_GET['action'] == "checkChannelForConference")
	{
		$conferencename = $_GET['ConferenceName'];
		$result = checkChannelForConference($conferencename);
		if($result['count'] > 0){
			if($result['channel'] ==""){
				echo "0";
			}else{
				echo $result['channel'];
			}
		}else{
			echo "0";
		}
		//createConference($conferencename,$conferencechannel);
	}
	if($_GET['action'] == "updateLiveCallStatusForDialer")
	{
		$status = $_GET['status'];
		$list_id = $_GET['list_id'];
		$channel = $_GET['channel'];
		$unique_id="";
		$mamama = updateLiveCallStatusForDialer($status,$list_id,$channel,$unique_id);
		
	}
	
	if($_GET['action'] == "updateContactChannel")
	{
		
		$list_id = $_GET['list_id'];
		$channel = $_GET['channel'];
		$mamama = updateContactChannel($list_id,$channel);
		
	}
	
	if($_GET['action'] == "removeLiveCallFromList")
	{
		$list_id = $_GET['list_id'];
		removeLiveCallFromListDialer($list_id);
	}
	if($_GET['action'] == "updatecalllog"){
		$unique_id = $_GET['unique_id'];
		$start_time =$_GET['start_time'];
		$answer_time =$_GET['answer_time'];
		$end_time =$_GET['end_time'];
		if(!$start_time)
		{
			$current_time = strtotime("now");
			$current_time = date('Y/m/d h:i:s');
			$start_time=$current_time;
			$answer_time=$current_time;
			$end_time=$current_time;
		}
		
		$recording =$_GET['recording'];
		$src =$_GET['src'];
		$callerid =$_GET['callerid'];
		$billableseconds =$_GET['billableseconds'];
		$duration =$_GET['duration'];
		$disposition =$_GET['disposition'];
		$PBX =$_GET['PBX'];
		$list_id =$_GET['list_id'];
		//removeLiveCallFromListDialer($list_id);
		
		$channel =$_GET['channel'];
		updateLiveCallStatusForDialer("disconnected",$list_id,$channel,$unique_id);
		//update unique id in live call table
		$destination =$_GET['destination'];
		$lastdata =$_GET['lastdata'];
		$lastapplication =$_GET['lastapplication'];
		$amaflag =$_GET['amaflag'];
		
		if(!$list_id){
			$liveCallInfo = getDilaerliveCallUniqueId($unique_id);
			$campaign_id = $liveCallInfo['data'][0]['campaign_id'];
		}else{
			$data = getContactCampaignIdForDialerList($list_id);
			$contact_id = $data['contact_id'];
			if(!$destination)
			{
			$conatctsDetails= getContact($contact_id);
			$destination = $conatctsDetails['data'][0]['phone'];
			}
			$campaign_id = $data['campaign_id'];
		}
		
		$campaignInfo = getDialerCampaignFromId($campaign_id);
		$asteriskID = $campaignInfo['data'][0]['asterisk'];
		$asterisk_ip = getAsteriskById($asteriskID);
		if($start_time){			
				$start_date = strtotime($start_time);
				$start_date = date('Y/m/d',$start_date);
			}else{
				$start_date = strtotime("now");
				$start_date = date('Y/m/d',$start_date);
			}
		
		
		$recording = $asterisk_ip['data'][0]['recording_url']."/".$start_date."/".$recording;
		
		$failcause = $_GET['failcause'];
		
		$result = createUpdateDialerCall($unique_id,$start_time,$answer_time,$end_time,$recording,$src,$callerid,$billableseconds,$duration,$disposition,$PBX,$contact_id,$campaign_id,$destination,$lastdata,$lastapplication,$amaflag,$channel,$failcause,$list_id);
		print_r(json_encode($res));
	}
	if($_GET['action'] == "checkLiveCallStatus")
	{
		$list_id = $_GET['list_id'];
		$status = checkDialerLiveCallStatus($list_id);
		//echo $status['status'];
		print_r(json_encode($status));
	}
	if($_GET['action'] == "addDisposition")
	{
		$list_id = $_GET['list_id'];
		$agent_disposition = $_GET['disposition'];
		$unique_id = $_GET['unique_id'];
		$user_id = $_GET['user_id'];
		$status = addDispositionToDialerList($list_id,$agent_disposition);
		updateAgentDispositionInDialerCallLog($unique_id,$agent_disposition,$user_id);
		$info = fetchDialerCallLogListUniqueId($list_id,$unique_id);
		if($info['count'] > 0){
			$call_id = $info['data'][0]['id'];
			$contact_id = $info['data'][0]['contact_id'];
			$contactInfo = getContact($contact_id);
			$contact_name = trim($contactInfo['data'][0]['first_name']." ".$contactInfo['data'][0]['last_name']);
			
			
			$user_id = $info['data'][0]['user_id'];
			$userInfo = getUserInfoFromId($user_id);
			$user_name = trim($userInfo['data'][0]['name']);
			$extension = trim($userInfo['data'][0]['extension']);
			
			
			$recording = $info['data'][0]['recording'];
			$campaign_id = $info['data'][0]['campaign_id'];
			$campaignInfo = getDialerCampaignFromId($campaign_id);
			$source_number = $info['data'][0]['source_number'];
			$callerid = $info['data'][0]['callerid'];
			$cdr_start_time = $info['data'][0]['cdr_start_time'];
			$cdr_answer_time = $info['data'][0]['cdr_answer_time'];
			$cdr_end_time = $info['data'][0]['cdr_end_time'];
			$billableseconds = $info['data'][0]['billableseconds'];
			$duration = $info['data'][0]['duration'];
			$disposition = $info['data'][0]['disposition'];
			$destination = $info['data'][0]['destination'];
			$channel = $info['data'][0]['channel'];
			$lastdata = $info['data'][0]['lastdata'];
			$amaflag = $info['data'][0]['amaflag'];
			$lastapplication = $info['data'][0]['lastapplication'];
			$AsterCTIInfo = getPortalURL();
			$PortalURL = $AsterCTIInfo['url'];
			if (!preg_match("~^(?:f|ht)tps?://~i", $PortalURL)) {
					$PortalURL = "http://" . $PortalURL;
				}
				$PortalURL = rtrim($PortalURL, '/');
				$urlForCRMCallLog = $PortalURL."/pushCallToCRM.php?action=createcall&extension=$extension&source=$destination&direction=outbound&unique_id=$unique_id&status=disconnected&dispo=$disposition&duration=$billableseconds&lastdata=$lastdata&total_seconds=$duration&account_code=&clid=$callerid&channel=$channel&amaflag=$amaflag&endtime=$cdr_end_time&starttime=$cdr_start_time&application=$lastapplication&path=$recording&crm=yes&answertime=$cdr_answer_time";
				$urlForCRMCallLog = str_replace(' ', '%20', $urlForCRMCallLog);
				
				
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $urlForCRMCallLog);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
				curl_setopt($ch, CURLOPT_TIMEOUT, 30);
				$apiresult = curl_exec($ch);
				if (curl_errno($ch)) {
					echo 'Error:' . curl_error($ch);
					echo "<br><br>";
					echo "CRM API URL : ".$urlForCRMCallLog;
					echo "<br><br>";
				}else{
					echo "CRM API URL : ".$urlForCRMCallLog;
					echo "<br><br>";
				}
				echo "API CRM RESULT : ".$apiresult;
				echo "<br><br>";
				curl_close($ch);
			
			if($campaignInfo['data'][0]['dispo_url']){
				$campaign_name = $campaignInfo['data'][0]['name'];
				$CURL_URL = $campaignInfo['data'][0]['dispo_url'];
				if (!preg_match("~^(?:f|ht)tps?://~i", $CURL_URL)) {
					$CURL_URL = "http://" . $CURL_URL;
				}
			

				$CURL_URL = rtrim($CURL_URL, '/');
				$urltoappend = "/contact_id=$contact_id?contact_name=$contact_name&agent_id=$user_id&agent_name=$user_name&dialer_name=$campaign_name&dialer_id=$campaign_id&unique_id=$unique_id&destination=$destination&agent_dispo=$agent_disposition&disposition=$disposition&recordlink=$recording&source=$source_number&channel=$channel&cdr_start_time=$cdr_start_time&cdr_answer_time=$cdr_answer_time&cdr_end_time=$cdr_end_time&billableseconds=$billableseconds&duration=$duration";
				$CURL_URL = $CURL_URL."".$urltoappend;
				$CURL_URL = str_replace(' ', '%20', $CURL_URL);
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $CURL_URL);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
				curl_setopt($ch, CURLOPT_TIMEOUT, 30);
				$result = curl_exec($ch);
				//echo $CURL_URL;
				if (curl_errno($ch)) {
					echo 'Error:' . curl_error($ch);
					echo "<br><br>";
					echo $CURL_URL;
					echo "<br><br>";
				}else{
					echo "<br><br>";
					echo $CURL_URL;
					echo "<br><br>";
				}
				$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
				curl_close($ch);
				if($code != "200"){
					$result = $code." ERROR";
				}
				echo "DISPO URL RESULT : ".$result;
				createDialerDispoURLResult($call_id,$result,$CURL_URL,$user_id,$campaign_id,$agent_disposition);
			}else{
				echo "NO DISPO URL SET IN CAMPAIGN";
			}
		}else{
			echo "NO CALL LOG FOUND FOR LIST ID: ".$list_id." and Unique ID : ".$unique_id;
		}
	}
}
?>