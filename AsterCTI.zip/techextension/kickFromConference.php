<?php
include "controller/route.php";
include "createConference.php";
if(isset($_GET['action'])){
	if($_GET['action'] == "kick")
	{
		$conferencename = $_GET['conference'];
		$campaign_id = $_GET['campaign_id'];
		$campaignInfo = getDialerCampaignFromId($campaign_id);
		
		$asterisk_id = $campaignInfo['data'][0]['asterisk'];
		$asteriskInfo = getAsteriskById($asterisk_id);
		$DialerAsteriskIP =$asteriskInfo['data'][0]['ip'];
		$DialerAMIPort =$asteriskInfo['data'][0]['port'];
		$DialerAMIUsername =$asteriskInfo['data'][0]['ami_username'];
		$DialerAMIPassword =$asteriskInfo['data'][0]['ami_password'];
		
		
		
		$result = checkChannelForConference($conferencename);
		if($result['count'] > 0){
			if($result['channel'] ==""){
				
			}else{
				$conferencechannel =  $result['channel'];
				
				kickAgentFromConference($DialerAsteriskIP,$DialerAMIPort,$DialerAMIUsername,$DialerAMIPassword,$conferencename,$conferencechannel);
				removeLiveCallForAgent($conferencename);
			}
		}
	}
}
?>