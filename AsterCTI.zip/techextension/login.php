<!DOCTYPE html>
<?php
include_once("controller/route.php");
if($_SESSION['tech_user_id'])
{
	echo "<script>location.href='home.php';</script>";
}
$user_id=checkAnyAdminPresent();
if(!$user_id)
{
	echo "<script>location.href='te-admin/registration.php'</script>";
}
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>TechExtension | Log in</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="stylesheet" href="dist/login/bootstrap.min.css">
	<link rel="stylesheet" href="dist/login/fontawesome-all.min.css">
	<link rel="stylesheet" href="dist/login/style.css">
	<link rel="stylesheet" href="dist/login/user_theme.css">
	<link rel="stylesheet" type="text/css" href="toastr/toastr.css">
	<link rel="icon" href="image/favicon.ico" type="image/x-icon">
  </head>
  <body>
    <div class="form-body">
        <div class="row">
            <div class="form-holder">
                <div class="form-content">
                    <div class="form-items">
                        <div class="website-logo-inside">
                            <a href="home.php">
                                <div class="logo">
                                    <img class="logo-size" src="dist/images/techextension-logo.png" alt="">
                                </div>
                            </a>
                        </div>
                        <h3>A Partner You Can Rely On.</h3>
                        <p>Access to the most powerfull tool in the entire design and web industry.</p>
                        <div class="page-links">
                            <a href="login.php" class="active">Login</a>
                        </div>
                        <form action="login.php" method="POST">
                            <input class="form-control" type="text" name="email" placeholder="E-mail Address" required>
                            <input class="form-control" type="password" name="password" placeholder="Password" required>
                            <div class="form-button">
                                <button id="login" type="submit" name="login" class="ibtn">Login</button> <a href="forget.php">Forget password?</a>
                            </div>
                        </form>
                       <!-- <div class="other-links">
                            <span>Or login with</span><a href="#"><i class="fab fa-facebook-f"></i></a><a href="#"><i class="fab fa-google"></i></a><a href="#"><i class="fab fa-linkedin-in"></i></a>
                        </div>
						-->
                    </div>
                </div>
            </div>
        </div>
    </div>

   <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="dist/login/popper.min.js"></script>
	<script src="dist/login/main.js"></script>
	<script type="text/javascript" src="toastr/toastr.min.js"></script>
  </body>
  <?php
  if(isset($_POST['login']))
	{
		$email = $_POST['email'];
		$password = $_POST['password'];
		
		$dataToSend = $email."*".$password;
		$result = CheckLogin($dataToSend);
	
		if($result['status'] == "1")
			{
				echo "<script>$('#email_error').hide();</script>";
				$_SESSION['tech_user_id'] = trim($result['data']['user_id']);
				$_SESSION['user_channel'] = trim($result['data']['channel']);
				$_SESSION['user_extension'] = trim($result['data']['extension']);
				$_SESSION['asteriskip'] = trim($result['data']['asterisk_ip']);
				echo "<script>location.href='home.php';</script>";
			}else if($result['status'] == "0")
			{
				echo "<script>toastr['warning']('Login Credentials Wrongly Entered')</script>";
			}else if($result['status'] == "2"){
				echo "<script>toastr['warning']('You have Disabled to Login By Administartor, Please Contact Admin')</script>";
			}
		}
  ?>
  
</html>
