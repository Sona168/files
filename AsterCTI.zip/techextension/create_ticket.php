<!DOCTYPE html>
  <?php include "header.php" ?>
  <?php include "left_sidebar.php";
	if(isset($_GET['record'])){
		$contactDetails = getContact($_GET['record']);
		$name = $contactDetails['data'][0]['first_name']." ".$contactDetails['data'][0]['last_name'];
		$http_contact_id = $contactDetails['data'][0]['id'];
		if(!$http_contact_id){
			echo "<script>
			console.log('Invalid');
					toastr['warning']('Invalid Contacts');
					</script>";
		}
	}
	if(isset($_GET['title'])){
		$title = $_GET['title'];
	}else{
		$title="";
	}
  ?>
      <div class="content-wrapper">
	  <?php  
	//$getemailconf=getEmailConfiguration($current_user);
	if($getemailconf['count'] == "0"){
  ?>
	  <div class="callout callout-warning">
        <h4>Reminder!</h4>
        Email updates will not sent to Contacts as you have not configured your SMTP setting.
        <a href="profile.php#email_confoguration">Click to visit Email Configuration</a> Page
      </div>
	  <?php }else if($getemailconf['data']['result'] != "1" ){ ?>
	  <div class="callout callout-warning">
        <h4>Alert!</h4>
		You have to click on <b>Test Mail button </b> after Configuration of Email Settings OR 
        Your Email Configuration is wrongly Entered, Please recheck Configuration
        <a href="profile.php#email_confoguration">Click to visit Email Configuration</a> Page
      </div>
	  <?php } ?>
	  <script>
	  var isEmailConfiguration = <?php echo json_encode($getemailconf['count']) ?>;
	  var isEmailTested = <?php echo json_encode($getemailconf['data']['result']) ?>;
	  </script>
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Create Ticket
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Contacts</a></li>
            <li class="active">Create Ticket</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
		<form class="form-horizontal" id="ticket_form" method='post' >
          <div class="row">
            <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">
                <tbody>
				<tr>
                    <td>Title</td>
                    <td>  
						<input type="text" class="form-control" id="title" value="<?php echo $title; ?>" name ='title' placeholder="Title" required>
					</td>
                </tr>
				<tr>
                    <td>Ticket Description</td>
                    <td> <textarea  id="description" name="description" class="md-textarea form-control" placeholder="Description" rows="3" required></textarea></td>
                </tr>
				<tr>
                    <td>Ticket Resolution</td>
                    <td> <textarea  id="solution" name="solution" class="md-textarea form-control" placeholder="Resolution" rows="3"></textarea></td>
                </tr>
				</tbody>
				</table>
				</div>
				</div>
<div class="col-md-6">
	<div class="col-xs-12 table-responsive">
		<table class="table table-striped">
<?php
$ticketStatus = getTicketStatus();
?>
                <tbody>
				<tr>
                    <td>Status</td>
                    <td>
						<select class="form-control select2" id="status" name="status" required>
						<option selected="selected" value="">Select Status</option>
						<?php
						for($i=0;$i<$ticketStatus['count'];$i++){
						?>
						<option value="<?php echo $ticketStatus['data'][$i]['status']; ?>" ><?php echo $ticketStatus['data'][$i]['status']; ?></option>
						<?php } ?>
						</select>
					</td>
                </tr>
				<tr>
                    <td>Priority</td>
                    <td>
						<select class="form-control select2" id="priority" name="priority" required>
						<option selected="selected" value="">Select Priority</option>
						<?php
						for($i=0;$i<count($ticketPriority);$i++){
						?>
						<option value="<?php echo $ticketPriority[$i]; ?>" ><?php echo $ticketPriority[$i]; ?></option>
						<?php } ?>
						</select>
					</td>
                </tr>
				<tr>
                    <td>Contact Name</td>
                    <td>
					<select class="form-control select2" id="contact_id" name="contact_id" onchange="setTextField(this)" required>
						<?php if(isset($http_contact_id)){ ?>
						<option selected="selected" value="<?php echo $http_contact_id; ?>"><?php echo $name; ?></option>
						<?php }else{ ?>
						<option selected="selected" value="">Select Contact</option>
						<?php } ?>
					</select>
						<input id="contact_name" type = "hidden" name = "contact_name" value = "" />
						<script type="text/javascript">
							function setTextField(ddl) {
							document.getElementById('contact_name').value = ddl.options[ddl.selectedIndex].text;
							}
						</script>
					</td>
                </tr>
				</tbody>
			</table>
		</div>
	</div>
          </div><!-- /.row -->
		  <div class="box-footer">
                    <button type="submit" id="create_ticket" name='submit' class="btn btn-primary center-block">Create Ticket</button>
                  </div>
				  </form>
        </section>
      </div>
	  <?php
		if(isset($_POST['submit']))
		{
		echo "<script> $('#create_ticket').prop('disabled', true);</script>";
			$title = $_POST['title'];
			$solution = $_POST['solution'];
			$description = $_POST['description'];
			$status = $_POST['status'];
			$contact_id = $_POST['contact_id'];
			$priority = $_POST['priority'];
			
			$type="agent";
			//echo $subject." ".$start_date." ".$start_time." ".$end_date." ".$end_time." ".$description." ".$status." ".$contact_id." ".$user_id;
				$res = createTicket($current_user,$title,$solution,$priority,$description,$status,$contact_id,$current_user,$type);
				if($res['status']=="1")
				{
					$ticket_id = $res['ticket_id'];
					$urltocall = "ticket_id=".$ticket_id."&type=agent&user_id=".$current_user."&ticket=yes";
					echo "<script>
						toastr['success']('Ticket Created Successfully');
						if(isEmailConfiguration ==1 && isEmailTested ==1){
						$.ajax({url: mailURL+'/ticket_email_management.php?$urltocall', success: function(result){
						console.log(result);
						toastr['success']('Ticket Mail Sent');	
						}});
						}else{
							toastr['warning']('Email not Configured Properly, Email Will Not Sent');	
						}
					</script>";
						echo "<script> $('#create_ticket').prop('disabled', false);</script>";
				}
				else if($res['status']=="0")
				{
					echo "<script>toastr['error']('Contact with Primary Phone Number Already Exist. Contact not created')</script>";
				}else{
					echo "<script>toastr['warning']('Something Went Wrong')</script>";
				}
		}
	  include "footer.php";
	  include "footer_script.php";
	  ?>
		<style>
		.select2 {
			width: 300px !important;
		}
		</style>
    <script>
	 $(".select2").select2();
	  $("#contact_id").select2({
                ajax: {
                    url: "te-admin/getContactSelect.php",
                    type: "post",
                    dataType: 'json',
                    delay: 250,
                     data: function (params) {
						var query = {
							q: params.term,
							agent_id: user_id,
							searchAgentsContact: 'yes'
						}
						return query;
                    },
                    processResults: function (response) {
                        return {
                            results: response
                        };
                    },
                    cache: true
                }
            });
	
    </script>
  </body>
</html>