<!DOCTYPE html>

  <?php include "header.php" ?>
  <?php include "left_sidebar.php" ?>


  <?php
	$userDetails = getAllUnreadSMSDetails();

  ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Unread SMS
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">SMS</a></li>
            
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
         <div class="row">
		  <div class="col-xs-12">
			<div class="col-xs-3">
			<label>Date Between:</label>
			<div class="input-group">
			  <div class="input-group-addon">
				<i class="fa fa-calendar"></i>
			  </div>
			  <input type="text" class="form-control" id="reservationtime" onchange="abc()">
			</div>
			</div>
					
<?php 
$userDetailsAgent = getAlluserInfo();

?>
			 
				
				
				<div class="col-xs-3">
               <div class="form-group">
                    <label>Agent Name</label>
                    <select class="form-control select2" id="agent" onchange="abc()">
					<option selected="selected" value="">Select Agent Name</option>
					
						<?php 
						for($i=0;$i<count($userDetailsAgent['data']);$i++)
						{
						?>
                      <option value="<?php echo $userDetailsAgent['data'][$i]['user_id']; ?>" ><?php echo $userDetailsAgent['data'][$i]['name']; ?></option>
						<?php } ?>
                    </select>
                  </div>
				</div>
					</div>
					
				</div>
					<div class='max'></div>
				 <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">SMS List</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped" title="">
                    <thead title="">
                      <tr>
 <th>Sr No</th>                       
					   <th>Number</th>
                        <th>SMS Text</th>
                        
                        <th>Assigned Agent</th>
						<th>date Time</th>
						
						 <th>Action</th>
                      </tr>
                    </thead>
                    <tbody id="tableRow">
					<?php 
					$j=0;
				
					if($userDetails['count'] >= 1)
					{
						for($i=0;$i<count($userDetails['data']);$i++)
						{
							$j++;
							$userDetailssss = getUserInfoFromId($userDetails['data'][$i]['user_id']);
							if($userDetailssss['count']=='0')
							{
								$AssignedUser = 'Admin';
							}else
							{
								$AssignedUser = $userDetailssss['data'][0]['name'];
							}
						?>
						  <tr>
							<td><?php echo $j; ?></td>
							<td><?php echo $userDetails['data'][$i]['number']; ?></td>
							<td><?php echo shortText(urldecode($userDetails['data'][$i]['sms'])); ?></td>
					
							<td><?php echo $AssignedUser; ?></td>
							<td><?php echo $userDetails['data'][$i]['date_time']; ?></td>
							
							  <td class="btn-group">
									<a href="sms_details.php?action=Read&id=<?php echo $userDetails['data'][$i]['id'];?>"><button class="btn btn-success btn-xs" style="float:left;margin-right:5px;" title='Read SMS'>READ SMS</button></a>
								</td>
						  </tr>
						<?php
						}
					}
					?>
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

     <?php
	include "printDataTableJS.php";
	  include "footer.php";
	  include "footer_script.php";
	  ?>
	
	
	<script>
	
	function abc()
	{
		var dateString="from=";
		var agentString="";
		var directionString="";
		var statusString="";
		var dateFrom="";
		var dateTo="";
		/* Date Between */
			var Date = document.getElementById("reservationtime").value;
			var Date = Date.split("-");

			if(Date[0].length > 0)
			{
				dateFrom = Date[0].trim();
				dateTo = Date[1].trim();
				
				//console.log(dateString);
			}
			dateString ="from="+dateFrom+"&to="+dateTo;
		/* End Date Between */
		
		/* Agent */
			var agent = document.getElementById("agent").value;
			if(agent)
			{
				agent = agent.trim();
				
			}
			agentString ="&agent="+agent;
		/* End Agent */
		
		
		
		
		console.log("smsData.php?"+dateString+agentString);
		    $.ajax({url: "smsData.php?"+dateString+agentString, success: function(result){
           //console.log(result);
		   document.getElementById('tableRow').innerHTML = result;
        }});   
	}
	
	</script>
	
	
<script>
$(function () {
		var table = $('#example1').DataTable( {
		"order": [[ 5, "desc" ]],
		"autoWidth": true,
		"dom": '<"top"Blf>rt<"bottom"p><"clear">',
		buttons: [
		 {
                extend: 'print',
                exportOptions: {
                    columns: ':visible'
                }
				 },
				{
				extend: 'pdf',
				download:'open',
				title: '',
					orientation:'landscape',
					pageSize:'LEGAL',
				exportOptions: {
					columns: ':visible'
				}
				},
				{
				extend: 'excel',
				title: '',
				exportOptions: {
					columns: ':visible'
				}
				},
				{
				extend: 'csv',
				title: '',
				exportOptions: {
					columns: ':visible'
				}
				},
			'copy',
			{
				extend: 'colvis',
				title: '',
				collectionLayout:'fixed two-column'
			}
		]
	});	
      });
</script>
	
	 <script>
	
	
      $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

     
 $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
        
      });
    </script>
  </body>
</html>
