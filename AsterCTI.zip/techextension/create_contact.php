<!DOCTYPE html>

  <?php include "header.php" ?>
  <?php include "left_sidebar.php" ?>
  <?php $contactStatusInfo = getAllContactStatus(); ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Create Contacts
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Contacts</a></li>
            <li class="active">Create Contact</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
		<form class="form-horizontal" method='post' >
          <div class="row">
            <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
			
              <table class="table table-striped">
			
                <tbody>
				
			
				<tr>
                    <td>First Name</td>
                    <td>  <input type="text" class="form-control" id="fname" name ='fname' placeholder="First Name" required></td>
                </tr>
				
				<tr>
                    <td>Last Name</td>
                    <td><input type="text" class="form-control" id="lname" name ='lname' placeholder="Last Name" required></td>
                </tr>
				<tr>
                    <td>Email</td>
                    <td><input type="email" class="form-control" id="email" name ='email' placeholder="Email Address" required></td>
                </tr>

				<tr>
					<td>Prefix <i class="fa fa-info-circle" onclick="showPrefixInfo()"></i>
					</td>
					<td><input type="text" class="form-control" id="prefix" name ='prefix' placeholder="Prefix"></td>
					
				</tr>
				
				
				<tr>
                    <td>Primary Phone Number</td>
					<?php 
					if(isset($_GET['phone'])){
						$phone = $_GET['phone'];
					}else{
						$phone = "";
					}
					?>
					
                    <td><input type="text" class="form-control" id="phone" name ='phone' value="<?php echo $phone; ?>" placeholder="Phone Number" required></td>
                </tr>
				
				<tr>
                    <td>Status</td>
                    <td>
                   
                    <select class="form-control select2" id="status" name="status" required>
					<option selected="selected" value="">Select Contact Status</option>
					<?php for($i=0;$i<$contactStatusInfo['count'];$i++){
						
						?>
					<option value="<?php echo $contactStatusInfo['data'][$i]['status'] ?>" ><?php echo $contactStatusInfo['data'][$i]['status'] ?></option>
					<?php } ?>
                    
                    </select>
                </td>
                </tr>
				

				
				</tbody>
				</table>
				</div>
				</div>
			
			 <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">

                <tbody>
				<tr>
                    <td>Secondary Phone Number</td>
                    <td> <input type="text" class="form-control" id="phone2" name ='phone2' placeholder="Phone Number"></td>
                </tr>
			
			<tr>
                    <td>City</td>
                    <td> <input type="text" class="form-control" id="city" name ='city' placeholder="City"></td>
                </tr>
				
				<tr>
                    <td>Postal Code</td>
                    <td> <input type="text" class="form-control" id="postal_code" name ='postal_code' placeholder="Postal Code"></td>
                </tr>
				
				<tr>
                    <td>Country</td>
                    <td> <input type="text" class="form-control" id="country" name ='country' placeholder="Country"></td>
                </tr>
			
				<tr>
                    <td>Address</td>
                    <td> <textarea  id="address" name="address" class="md-textarea form-control" placeholder="Address (Optional)" rows="3"></textarea></td>
                </tr>
				
				<tr>
                    <td>Notes</td>
                    <td><textarea  id="notes" name="notes" class="md-textarea form-control" placeholder="Notes If Any" rows="3"></textarea></td>
                </tr>
			
				
				</tbody>
				
				</table>
				 
				
				</div>
			
				</div>
				
			
          </div><!-- /.row -->
		  
		  <div class="box-footer">
                    <button type="submit" name='submit' class="btn btn-primary center-block">Create Contact</button>
                  </div>
				  
				  </form>
        </section>
      </div><!-- /.content-wrapper -->

	  
	  
	  <?php
		if(isset($_POST['submit']))
		{
			$first_name = $_POST['fname'];
			$last_name = $_POST['lname'];
			$email = $_POST['email'];
			$prefix = $_POST['prefix'];
			$phone = $_POST['phone'];
			$phone2 = $_POST['phone2'];
			$address = $_POST['address'];
			$note = $_POST['notes'];
			$status = $_POST['status'];
			
			$city = $_POST['city'];
			$postal_code = $_POST['postal_code'];
			$country = $_POST['country'];
			//echo $first_name." ".$last_name." ".$email." ".$phone." ".$address." ".$phone2." ".$status." ".$note." ".$prefix;
			
				$res = createContact($_SESSION['tech_user_id'],$first_name,$last_name,$email,$phone,$address,$phone2,$note,$status,$prefix,$city,$postal_code,$country);
				if($res['status']=="1")
				{
					$id = $res['id'];
					echo "<script>toastr['success']('Contact Created Successfully')
					setTimeout(function(){ location.href='contact_details.php?action=View&id=$id'; }, 1500);					
					</script>";
					
				}
				else if($res['status']=="0")
				{
					echo "<script>toastr['error']('Contact with Primary Phone Number OR Email Already Exist. Contact not created')</script>";
				}else{
					echo "<script>toastr['warning']('Something Went Wrong')</script>";
				}
			
		}
		
	  ?>
     <?php
	
	  include "footer.php";
	  include "footer_script.php";
	  ?>
    <script>
	 $(".select2").select2();
	 function showPrefixInfo(){
		 $('#heading1').html("Prefix For Phone Number");
		 $('#heading2').html("");
		 $('#modal_body').html("Prefix will be added automatically before calling phone number everytime to respective contact while using TE Dialer");
		 $('#dispo_information').modal('show');
	 }
    </script>
  </body>
</html>
