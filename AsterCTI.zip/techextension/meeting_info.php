<!DOCTYPE html>

  <?php include "header.php" ?>
  <?php include "left_sidebar.php" ?>
  <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.min.css">
<?php

 if(isset($_GET['id']))
  {
	$meeting_id = $_GET['id'];
	
	$meetingDetails = getMeetingInfo($meeting_id);
	if($_GET['action'] == "View")
	{
		$titleName = "Meeting Details";
		$propertyforfields= "disabled";
		$propertyforfieldsoptional= "disabled";
	}else{
		$titleName = "Update Meeting";
		$propertyforfields= "required";
		$propertyforfieldsoptional= "";
		$allMeetingStatus = getAllMeetingStatus();
		$contactInfo = getAgentAllContacts("admin");
		$userInfo = getAlluserInfo();
		?>
		<script>
		var contact_id = <?php echo json_encode($meetingDetails['data'][0]['contact_id']) ?>;
		</script>
<?php
	}
	if($_GET['action'] == "Delete")
	{
		deleteMeeting($meeting_id);
		echo "<script>location.href='view_meeting.php?action=remove'</script>";  
	}
	
  }else{
	echo "<script>location.href='view_meeting.php'</script>";  
  }
?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <?php echo $titleName; ?>
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Contacts</a></li>
            <li class="active"><?php echo $titleName; ?></li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
		<form class="form-horizontal" method='post' >
          <div class="row">
            <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
			
              <table class="table table-striped">
			
                <tbody>
				
			
				<tr>
                    <td>Subject</td>
                    <td>  <input type="text" class="form-control" id="subject" name ='subject' value="<?php echo $meetingDetails['data'][0]['subject']; ?>" placeholder="Subject Of Meeting" <?php echo $propertyforfields; ?>></td>
                </tr>
				
				<tr>
                    <td>Start Date Time</td>
                    <td>
					<div class="input-group date input-group bootstrap-timepicker">
						<div class="input-group-addon">
							<i class="fa fa-calendar"></i>
						</div>
						<?php
							$meetingDetails['data'][0]['start_date']=date("d-m-Y",strtotime($meetingDetails['data'][0]['start_date']));
							$meetingDetails['data'][0]['end_date']=date("d-m-Y",strtotime($meetingDetails['data'][0]['end_date']));
						?>
						
						<input type="text" class="form-control" id="start_date" name="start_date" value="<?php echo $meetingDetails['data'][0]['start_date']; ?>" <?php echo $propertyforfields; ?>>
						
						<div class="input-group-addon">
							<i class="fa fa-clock-o"></i>
						</div>
						<input id="start_time" name="start_time" type="text" value="<?php echo $meetingDetails['data'][0]['start_time']; ?>" class="form-control" <?php echo $propertyforfields; ?>>
					</div>
				  </td>
                </tr>
				
				<tr>
                   <td>End Date Time</td>
                    <td>
					<div class="input-group date input-group bootstrap-timepicker">
						<div class="input-group-addon">
							<i class="fa fa-calendar"></i>
						</div>
						<input type="text" class="form-control" id="end_date" value="<?php echo $meetingDetails['data'][0]['end_date']; ?>" name="end_date" <?php echo $propertyforfields; ?>>
						
						<div class="input-group-addon">
							<i class="fa fa-clock-o"></i>
						</div>
						<input id="end_time" name="end_time" type="text" value="<?php echo $meetingDetails['data'][0]['end_time']; ?>" class="form-control" <?php echo $propertyforfields; ?>>
					</div>
				  </td>
                </tr>

				
				
				
				<tr>
				<input type="hidden" name="meeting_id" value="<?php echo $meeting_id; ?>">
                    <td>Description</td>
                    <td> <textarea  id="description" name="description" class="md-textarea form-control" placeholder="Description (Optional)" rows="3" <?php echo $propertyforfieldsoptional; ?>><?php echo $meetingDetails['data'][0]['description']; ?></textarea></td>
                </tr>
				
			
				</tbody>
				</table>
				</div>
				</div>
			
			<div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">


                <tbody>
				<tr>
                    <td>Status</td>
                    <td>
					<?php if($_GET['action'] == "Edit"){ ?>
						<select class="form-control select2" id="status" name="status" <?php echo $propertyforfields; ?>>
						<option selected="selected" value="">Select Status</option>
						<?php
						for($i=0;$i<$allMeetingStatus['count'];$i++){
							 if($allMeetingStatus['data'][$i]['status'] == $meetingDetails['data'][0]['status'])
							  {
								$selected="selected=selected";
							  }
							  else
							  {
								$selected="";
							  }
						?>
						<option <?php echo $selected; ?> value="<?php echo $allMeetingStatus['data'][$i]['status']; ?>" ><?php echo $allMeetingStatus['data'][$i]['status']; ?></option>
						<?php } ?>
						</select>
					<?php }else if($_GET['action'] == "View"){ ?>
						<input  type="text" value="<?php echo $meetingDetails['data'][0]['status']; ?>" class="form-control" <?php echo $propertyforfields; ?>>
					<?php }	?>
						
					</td>
                </tr>
			
				<tr>
                    <td>Contact Name</td>
                    <td>
					<?php if($_GET['action'] == "Edit"){ ?>
					<select class="form-control select2" id="contact_id" name="contact_id" onchange="setTextField(this)" <?php echo $propertyforfields; ?>>
						<option selected="selected" value="">Select Contact</option>
					</select>
					<input id="contact_name" type = "hidden" name = "contact_name" value = "" />
						<script type="text/javascript">
							function setTextField(ddl) {
							document.getElementById('contact_name').value = ddl.options[ddl.selectedIndex].text;
							}
						</script>
					<?php }else if($_GET['action'] == "View"){
							$contactInfo = getContact($meetingDetails['data'][0]['contact_id']);
						?>
					<input  type="text" value="<?php echo $contactInfo['data'][0]['first_name']." ".$contactInfo['data'][0]['last_name']; ?>" class="form-control" <?php echo $propertyforfields; ?>>
					<?php }	?>
					</td>
                </tr>
				
				
				<tr>
                    <td>Assigned User</td>
                    <td>
					<?php 
						$userInfo = getUserInfoFromId($meetingDetails['data'][0]['assigned_user']);
						?>
					<input  type="text" value="<?php echo $userInfo['data'][0]['name']; ?>" class="form-control" disabled>
					
					</td>
                </tr>
				
				
				<tr>
				
				<?php 
					if($meetingDetails['data'][0]['modified_user'] == "1"){
						$meetingDetails['data'][0]['modified_user'] = "Administrator";
					}else{
						$userInfo = getUserInfoFromId($meetingDetails['data'][0]['modified_user']);
						$meetingDetails['data'][0]['modified_user'] = $userInfo['data'][0]['name'];
					}
					?>
				
				
                    <td>Last Modified By</td>
                    <td>
					<input  type="text" value="<?php echo $meetingDetails['data'][0]['modified_user']; ?>" class="form-control" disabled>
					</td>
                </tr>
				
				<tr>
                    <td>Created By</td>
                    <td>
					<?php 
					if($meetingDetails['data'][0]['created_by'] == "1"){
						$meetingDetails['data'][0]['created_by'] = "Administrator";
					}else{
						$userInfo = getUserInfoFromId($meetingDetails['data'][0]['created_by']);
						$meetingDetails['data'][0]['created_by'] = $userInfo['data'][0]['name'];
					}
					?>
					<input  type="text" value="<?php echo $meetingDetails['data'][0]['created_by']; ?>" class="form-control" disabled>
					</td>
                </tr>
				
				
				<tr>
                    <td>Date Created</td>
                    <td>
					<input  type="text" value="<?php echo $meetingDetails['data'][0]['created_date']; ?>" class="form-control" disabled>
					</td>
                </tr>
				
				
			
				
				</tbody>
				
				</table>
				 
				
				</div>
			
				</div>
				
			
          </div><!-- /.row -->
		  <?php if($_GET['action'] == "Edit"){ ?>
		  <div class="box-footer">
                    <button type="submit" name='submit' class="btn btn-primary center-block">Update Meeting</button>
          </div>
		  <?php }else if($_GET['action'] == "View"){ ?>
		  		  <div class="box-footer">
                   <a href="meeting_info.php?action=Edit&id=<?php echo $meeting_id; ?>"> <button type="button" class="btn btn-primary center-block">Edit Meeting</button></a>
          </div>
		  <?php } ?>
				  </form>
        </section>
      </div><!-- /.content-wrapper -->

	  
	  
	  <?php
		if(isset($_POST['submit']))
		{
			$subject = $_POST['subject'];
			$start_date = $_POST['start_date'];
			$start_time = $_POST['start_time'];
			$end_date = $_POST['end_date'];
			$end_time = $_POST['end_time'];
			$description = $_POST['description'];
			$status = $_POST['status'];
			$contact_id = $_POST['contact_id'];
			$contact_name = $_POST['contact_name'];
			$user_id = $_SESSION['tech_user_id'];
			$meeting_id = $_POST['meeting_id'];
			
			//echo $subject." ".$start_date." ".$start_time." ".$end_date." ".$end_time." ".$description." ".$status." ".$contact_id." ".$user_id." ".$meeting_id;
			
				$res = updateMeeting($meeting_id,$subject,$start_date,$start_time,$end_date,$end_time,$description,$status,$contact_id,$user_id,$user_id,$contact_name);
				if($res['status']=="1")
				{
					$id = $res['id'];
					echo "<script>toastr['success']('Meeting Updated Successfully')
					setTimeout(function(){ location.href='meeting_info.php?action=View&id=$id'; }, 1500);					
					</script>";
					
				}
				else if($res['status']=="0")
				{
					echo "<script>toastr['error']('Contact with Primary Phone Number Already Exist. Contact not created')</script>";
				}else{
					echo "<script>toastr['warning']('Something Went Wrong')</script>";
				}
			
		}
		
	  ?>
     <?php
	
	  include "footer.php";
	  include "footer_script.php";
	  ?>
	  
		<style>
		.select2 {
			width: 300px !important;
		}
		</style>
	  
	  <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
	  <script src="plugins/timepicker/bootstrap-timepicker.min.js"></script>
	  
	  
    <script>
	 $(".select2").select2();
	  $('#start_date').datepicker({
      autoclose: true,
	   format: 'dd-mm-yyyy'
    })
	 $('#end_date').datepicker({
      autoclose: true,
	   format: 'dd-mm-yyyy'
    })
	
	
	 $('#start_time').timepicker({
			timeFormat: 'HH:mm:ss',
			interval: 5,
			showMeridian: false,
			showInputs: false
	});
	$('#end_time').timepicker({
			timeFormat: 'HH:mm:ss',
			interval: 5,
			showMeridian: false,
			showInputs: false
	});
	
$("#contact_id").select2({
          language: {
				noResults: function() {
				return 'No Contact Found';
				},
				},
				escapeMarkup: function(markup) {
				return markup;
				},
                ajax: {
                    url: "te-admin/getContactSelect.php",
                    type: "post",
                    dataType: 'json',
                    delay: 0,
                    data: function (params) {
						var query = {
							q: params.term,
							agent_id: user_id,
							searchAgentsContact: 'yes'
						}
						return query;
                    },
                    processResults: function (response) {
                        return {
                            results: response
                        };
                    },
                    cache: true
                }
            });
			
			$.ajax({url: "getUpdatedCallInformation.php?findContact&contact_id="+contact_id, success: function(result){
				console.log(contact_id);
				var contactInfo = JSON.parse(result);
				contact_name = contactInfo.first_name+" "+contactInfo.last_name;
				$("#contact_id").data('select2').trigger('select', {
				data: {"id": contact_id, "text": contact_name }
				});
			}});

	
    </script>
  </body>
</html>
