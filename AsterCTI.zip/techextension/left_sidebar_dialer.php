 <!-- Left side column. contains the logo and sidebar -->
 <?php

$userStatus = $info['status'];
if($userStatus == "1"){
	$pasuseButtonCss = "enabled";
	$resumeButtonCss = "disabled";
	$cssUserStatus = "success";
	$statusValue = "Online";
}else{
	$pasuseButtonCss = "disabled";
	$resumeButtonCss = "enabled";
	$cssUserStatus = "warning";
	$statusValue = "Pause";
}
 ?>
 
      <aside class="main-sidebar" style="background-color:<?php echo $backgroundcolor; ?>">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo $profileDetails['profile_image']; ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info" style="color:#000">
              <p><?php echo $profileDetails['name']; ?></p>
              <a style="color:#000"><i id="useronlinestatus" class="fa fa-circle text-<?php echo $cssUserStatus; ?>"></i> <span id="useronlinestatusvalue"><?php echo $statusValue; ?></span></a>
            </div>
          </div>
          <!-- search form -->
  
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header" style="color:white;"><?php echo $company_name; ?> Menu</li>
           
             <li>
			   <span>&emsp;&emsp;<button type="button" class="btn btn-danger btn-ms" <?php echo $pasuseButtonCss; ?> style="margin-top:10px" id="pausebutton" onclick="changeUserStatus('0')"  title='Pause'><span class="glyphicon glyphicon-pause"></span> PAUSE</button></span>
			   <span>&emsp;<button type="button" class="btn btn-warning btn-ms" <?php echo $resumeButtonCss; ?> style="margin-top:10px" id="resumebutton" onclick="changeUserStatus('1')" title='Resume'><span class="glyphicon glyphicon-play"></span> RESUME</button></span>
			   </li>
		
			   	
			   <li>&emsp;&emsp;
				<button type="button" class="btn btn-secondary btn-block"  data-toggle="modal" id="manualdialerID" data-target="#manualdialer" title='Manual Dialer'><span class="glyphicon glyphicon-earphone"></span> MANUAL DIAL</button>
			   </li>
			   <?php 
			   if($webformurl){
			   ?>
			   <li>&emsp;&emsp;
				<button type="button" class="btn btn-secondary btn-block" onclick="changeIframe()" title='Web Form'><span class="glyphicon glyphicon-stats"></span> WEB FORM</button>
			   </li>
			   <?php } ?>
			   
			   <?php 
			   if($crm_id){
			   ?>
			    <li>&emsp;&emsp;
				<button type="button" class="btn btn-secondary btn-block" onclick="showInCRM()" title='CRM'><span class="glyphicon glyphicon-eye-open"></span> See Record In CRM</button>
			   </li>
			   <?php } ?>
			   
             
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>
	  
	  



<div class="modal fade left" id="autodialer" tabindex="-1" role="dialog" aria-labelledby="exampleModalPreviewLabel" aria-hidden="true">
<form method="GET" action="dialer.php" id="campaign_list">
  <div class="modal-dialog modal-full-height modal-left" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalPreviewLabel">Select Campaign</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="campaign_body">
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
		<button type="submit" onclick="return checkSelectedCampaign();" class="btn btn-success">Select Campaign</button>
      </div>
    </div>
  </div>
  </form>
</div>

<script>
function checkSelectedCampaign(){
	if($("#campaign_id").val() ==""){
		toastr["warning"]("Please Select Campaign to Start Dialer")
		return false;
	}
	else
	{
		var campaign_id = $("#campaign_id").val();
		console.log(campaign_id);
		console.log(user_id);
		$.ajax({url: "getUpdatedCallInformation.php?checkAdminAllowDialerLogin=login&user_id="+user_id+"&campaign_id="+campaign_id, success: function(statusAgent){
if(statusAgent == "1"){
	console.log(statusAgent);
			$('#autodialer').modal('hide');
			$("form").attr('target', '_blank');
			$("#campaign_list").submit(); 
}else{
	toastr["warning"]("Admin have Pause you to login inside this campaign")
		return false;
}
		}}); 
		return false;
	}
}

</script>

<div class="modal fade" id="manualdialer" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
 <div class="container">
 <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>

  <input type="text" id="callto">
  <div class="row">
    <div class="digit" id="one">1</div>
    <div class="digit" id="two">2
      
    </div>
    <div class="digit" id="three">3
      
    </div>
  </div>
  <div class="row">
    <div class="digit" id="four">4
      
    </div>
    <div class="digit" id="five">5
      
    </div>
    <div class="digit">6
     
    </div>
  </div>
  <div class="row">
    <div class="digit">7
     
    </div>
    <div class="digit">8
      
    </div>
    <div class="digit">9
     
    </div>
  </div>
  <div class="row">
    <div class="digit">+
    </div>
    <div class="digit">0
    </div>
    <div class="digit">#
    </div>
  </div>
  <div class="botrow">
  
    <div id="call" onclick='originateCalls()' data-dismiss="modal"><i class="fa fa-phone" aria-hidden="true"></i></div>
    <i class="fa fa-long-arrow-left dig" aria-hidden="true"></i>
  </div>
</div>
  </div>
</div>



<style>
body {
  background-color: #42a5f5;
}

.row {
  margin: 0 auto;
  width: 280px;
  clear: both;
  text-align: center;
  font-family: 'Exo';
}

.digit,
.dig {
  float: left;
  padding: 10px 30px;
  width: 60px;
  font-size: 2rem;
  cursor: pointer;
}

.sub {
  font-size: 0.8rem;
  color: grey;
}

.container {
  background-color: white;
  width: 245px;
  padding: 20px;
  margin: 30px auto;
  height: 420px;
  text-align: center;
  box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
}

#callto {
	border: 0px none;
	margin-top:5px;
	width : 200px;
	font-family: "Exo";
	font-size: 3rem;
	height: 60px;
	font-weight: bold;
	color: #000;
}

#call {
  display: inline-block;
  background-color: #66bb6a;
  padding: 4px 30px;
  margin: 10px;
  color: white;
  border-radius: 4px;
  float: left;
  cursor: pointer;
}

.botrow {
  margin: 0 auto;
  width: 280px;
  clear: both;
  text-align: center;
  font-family: 'Exo';
}

.digit:active,
.dig:active {
  background-color: #e6e6e6;
}

#call:hover {
  background-color: #81c784;
}

.dig {
  float: left;
  padding: 10px 20px;
  margin: 10px;
  width: 30px;
  cursor: pointer;
}

</style>
<script>

$(".digit").on('click', function() {
  var num = ($(this).clone().children().remove().end().text());
  num = num.trim();
 $('#callto').val($('#callto').val().trim()+num);
});

$('.fa-long-arrow-left').on('click', function() {
	console.log($('#callto').val().trim());
  $('#callto').val( $('#callto').val().trim().slice(0,-1));
  console.log($('#callto').val().trim());
});</script>
 