<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
if(isset($_GET['customer_id'])){
include('../controller/route.php');
$action = $_GET['action'];
$portalInfo=getPortalURL();
$portal_url = $portalInfo['url'];
$customer_portal_url = $portal_url."/customer/login.php?action=checkpassword";
$contact_id = $_GET['customer_id'];

$contact_info = getContact($contact_id);
$contact_name = $contact_info['data'][0]['first_name']." ".$contact_info['data'][0]['last_name'];
$contact_email = $contact_info['data'][0]['email'];
$new_password = $contact_info['data'][0]['secret'];
$company_name = getCompanyName();

$email = file_get_contents("template_new_password_customer.php");
$body='';
$emmailconf = getEmailConfiguration('1');
if($action == "New Password"){
	$title = "Your New Password";
	$description = "Your new Password is generated and please find it below and login in Ticket module to make maximum of it.";
}else{
	$title = "Password Retrieved";
	$description = "Your Password is retrieved successfully, Please find below to login in your Account";
}
	$variables = array(
	"{{company_name}}" => $company_name,
	"{{password}}" => $new_password,
	"{{login_url}}" => $customer_portal_url,
	"{{admin_name}}" => $admin_name,
	"{{customer_name}}" => $contact_name,
	"{{title}}" => $title,
	"{{description}}" => $description,
	"{{action}}" => $action
	);
	foreach ($variables as $key => $value)
	$email = str_replace($key, $value, $email);
	
require_once('class.phpmailer.php');
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 2;
$mail->SMTPAuth = true;
$mail->SMTPSecure = $emmailconf['data']['security_type']; 
$mail->Host = $emmailconf['data']['host']; 
$mail->Port =$emmailconf['data']['port'];
$mail->Username = $emmailconf['data']['email'];
$mail->Password = $emmailconf['data']['password'];
$mail->Subject = "Your $action Request Generated to Login in Ticket Management";
$mail->MsgHTML($email);
$mail->AltBody = "To view the message, please use an HTML compatible email viewer!";
$mail->SetFrom($emmailconf['data']['email'],$company_name);
$mail->AddAddress($contact_email);
//$mail->AddCC($emmailconf['data']['email']);
 if (!$mail->Send()) {
       $result='0';
    } else {
	  $result='1';
    }
echo $result;
}else{
	echo "UnAuthorize Access!!!";
}
?>