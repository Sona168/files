<?php
	ini_set('display_errors',1);
	ini_set('display_startup_errors',1);
	include('../controller/route.php');
	$user_id = $_GET['user_id'];
	$company_name = getCompanyName();
	$emmailconf = getEmailConfiguration($user_id);
    date_default_timezone_set('Asia/Kolkata');
    require_once('class.phpmailer.php');
	$to_send=$emmailconf['data']['email'];
	$mail = new PHPMailer();
    $body='';
	$body.="Hi, <br>This is Test Mail From TechExtension's AsterCTI.<br><br><img src='https://www.servethehome.com/wp-content/uploads/2011/05/Test-Connection-Successful-6.png'>";
    $mail->IsSMTP();
    $mail->SMTPDebug = 2;
    $mail->SMTPAuth = true;
   	$mail->SMTPSecure = $emmailconf['data']['security_type']; 
    $mail->Host = $emmailconf['data']['host']; 
    $mail->Port =$emmailconf['data']['port'];
	$mail->Username = $emmailconf['data']['email'];
	$mail->Password = $emmailconf['data']['password'];
    $mail->Subject = "Test Mail From TechExtension's AsterCTI";
	//$mail->AddCC('support@techextension.com');
    $mail->AltBody = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
    $mail->SetFrom($emmailconf['data']['email'],$company_name);
    $mail->MsgHTML($body);
    $mail->AddAddress($emmailconf['data']['email']);
    if (!$mail->Send()) {
       $result='0';
	   updateEmailTestResult($user_id,$result);
    } else {
	  $result='1';
	  updateEmailTestResult($user_id,$result);
    }
	
	
/* $email = $emmailconf['data']['email'];
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: $email" . "\r\n" ."CC: astercti@techextension.com";

$result1 = mail($email,"Test Mail From AsterCTI","Testing Email from Techextension's AsterCTI",$headers,"");
 */

echo $result;
?>
