<?php
if(isset($_GET['forgot_mail_for']))
{
	ini_set('display_errors',1);
	ini_set('display_startup_errors',1);
	include('../controller/route.php');
	date_default_timezone_set('Asia/Kolkata');
    require_once('class.phpmailer.php');
	$toSend = $_GET['forgot_mail_for'];
	$adminDetails = getUserInfoFromEmail($toSend);
	$password = $adminDetails['data'][0]['original_password'];
	if($adminDetails['count'] == "0")
	{
		 $result1='-1';
	}else
	{
	$emmailconf = getEmailConfiguration();
	$to_send=$emmailconf['data']['email'];
	$mail = new PHPMailer();
    $body='';
	$body.='Hi, <br>Your Password is :'.$password; 
    $mail->IsSMTP();
    $mail->SMTPDebug = 2;
    $mail->SMTPAuth = true;
   	$mail->SMTPSecure = $emmailconf['data']['security_type']; 
    $mail->Host = $emmailconf['data']['host']; 
    $mail->Port =$emmailconf['data']['port'];
	$mail->Username = $emmailconf['data']['email'];
	$mail->Password = $emmailconf['data']['password'];
    $mail->Subject = "Password Reset Request";
    $mail->AltBody = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
    $mail->SetFrom($emmailconf['data']['email'],'TechExtension');
    $mail->MsgHTML($body);
    $mail->AddAddress($toSend);
    if (!$mail->Send()) {
       $result1='0';
    } else {
	  $result1='1';
    }
}
echo $result1;
}else{
	echo "Access Deny";
}

?>
