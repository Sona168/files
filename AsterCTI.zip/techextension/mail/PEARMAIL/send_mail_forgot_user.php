<?php
if(isset($_GET['forgot_mail_for']))
{
	ini_set('display_errors',1);
	ini_set('display_startup_errors',1);
include('../../controller/route.php');
require_once "Mail.php";
include 'Mail/mime.php' ;
	date_default_timezone_set('Asia/Kolkata');
    require_once('class.phpmailer.php');
	$toSend = $_GET['forgot_mail_for'];
	$adminDetails = getUserInfoFromEmail($toSend);
	$password = $adminDetails['data'][0]['original_password'];
	if($adminDetails['count'] == "0")
	{
		 $result1='-1';
	}else
	{
	$emmailconf = getEmailConfiguration();
	$to_send=$emmailconf['data']['email'];
	//
    $body='';
	$body.='Hi, <br>Your Password is :'.$password; 
   
	
	$smtpType = $emmailconf['data']['security_type'];
$host = $emmailconf['data']['host'];
$port = $emmailconf['data']['port'];
$password = $emmailconf['data']['password'];

$headers = array(
    'From' => $emmailconf['data']['email'],
    'To' => $toSend,
    'Subject' => 'Password Reset Request'
);


$crlf = "\n";
$mime = new Mail_mime(['eol' => $crlf]);
$mime->setHTMLBody($body);
$body = $mime->get();
$headers = $mime->headers($headers);

$smtp = Mail::factory('smtp', array(
        'host' => "$smtpType://$host",
		//'debug' => true,
        'port' => $port,
        'auth' => 'PLAIN',
		'socket_options' => array('ssl' => array('verify_peer' => false,'verify_peer_name' => false)),
        'username' => $emmailconf['data']['email'],
        'password' => $emmailconf['data']['password']
    ));
	
	
$mail = $smtp->send($toSend, $headers, $body);
if (PEAR::isError($mail)) {
	$result='0';
	//updateEmailTestResult($user_id,$result);
} else {
	$result='1';
	//updateEmailTestResult($user_id,$result);
}
}
echo $result1;
}else{
	echo "Access Deny";
}

?>
