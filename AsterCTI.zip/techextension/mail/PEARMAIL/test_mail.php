<?php
// Pear Mail Library
require_once "Mail.php";
include 'Mail/mime.php' ;
	ini_set('display_errors',1);
	ini_set('display_startup_errors',1);
	include('../../controller/route.php');
	$user_id = $_GET['user_id'];
	$company_name = getCompanyName();
	$emmailconf = getEmailConfiguration($user_id);
    date_default_timezone_set('Asia/Kolkata');
    $body='';
	$body.="Hi, <br>This is Test Mail From TechExtension's AsterCTI.<br><br><img src='https://www.servethehome.com/wp-content/uploads/2011/05/Test-Connection-Successful-6.png'>";
	$from  = $emmailconf['data']['email'];
	$headers = array(
    'From' => $from,
    'To' => $from,
    'Subject' => "Test Mail From TechExtension's AsterCTI"
);
$smtpType = $emmailconf['data']['security_type'];
$host = $emmailconf['data']['host'];
$port = $emmailconf['data']['port'];
$password = $emmailconf['data']['password'];


$crlf = "\n";
$mime = new Mail_mime(['eol' => $crlf]);
$mime->setHTMLBody($body);
$body = $mime->get();
$headers = $mime->headers($headers);



$smtp = Mail::factory('smtp', array(
        'host' => "$smtpType://$host",
		//'debug' => true,
        'port' => $port,
        'auth' => 'PLAIN',
		'socket_options' => array('ssl' => array('verify_peer' => false,'verify_peer_name' => false)),
        'username' => $from, //your gmail account
        'password' => $password // your password
    ));
//var_dump($smtp);
// Send the mail
$mail = $smtp->send($from, $headers, $body);

//check mail sent or not
if (PEAR::isError($mail)) {
	$result='0';
	updateEmailTestResult($user_id,$result);
} else {
	$result='1';
	updateEmailTestResult($user_id,$result);
}
echo $result;
?>
