<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
if(isset($_GET['customer_id'])){
require_once "Mail.php";
include 'Mail/mime.php' ;
include('../../controller/route.php');
$action = $_GET['action'];
$portalInfo=getPortalURL();
$portal_url = $portalInfo['url'];
$customer_portal_url = $portal_url."/customer/login.php?action=checkpassword";
$contact_id = $_GET['customer_id'];

$contact_info = getContact($contact_id);
$contact_name = $contact_info['data'][0]['first_name']." ".$contact_info['data'][0]['last_name'];
$contact_email = $contact_info['data'][0]['email'];
$new_password = $contact_info['data'][0]['secret'];
$company_name = getCompanyName();

$email = file_get_contents("template_new_password_customer.php");
$body='';
$emmailconf = getEmailConfiguration('1');
if($action == "New Password"){
	$title = "Your New Password";
	$description = "Your new Password is generated and please find it below and login in Ticket module to make maximum of it.";
}else{
	$title = "Password Retrieved";
	$description = "Your Password is retrieved successfully, Please find below to login in your Account";
}
	$variables = array(
	"{{company_name}}" => $company_name,
	"{{password}}" => $new_password,
	"{{login_url}}" => $customer_portal_url,
	"{{admin_name}}" => $admin_name,
	"{{customer_name}}" => $contact_name,
	"{{title}}" => $title,
	"{{description}}" => $description,
	"{{action}}" => $action
	);
	foreach ($variables as $key => $value)
	$email = str_replace($key, $value, $email);
	
$smtpType = $emmailconf['data']['security_type'];
$host = $emmailconf['data']['host'];
$port = $emmailconf['data']['port'];
$password = $emmailconf['data']['password'];


	$headers = array(
    'From' => $emmailconf['data']['email'],
    'To' => $contact_email,
    'Subject' => $title
);

$crlf = "\n";
$mime = new Mail_mime(['eol' => $crlf]);
$mime->setHTMLBody($email);
$body = $mime->get();
$headers = $mime->headers($headers);

$smtp = Mail::factory('smtp', array(
        'host' => "$smtpType://$host",
		//'debug' => true,
        'port' => $port,
        'auth' => 'PLAIN',
		'socket_options' => array('ssl' => array('verify_peer' => false,'verify_peer_name' => false)),
        'username' => $emmailconf['data']['email'],
        'password' => $emmailconf['data']['password']
    ));
	
	
$mail = $smtp->send($contact_email, $headers, $body);
if (PEAR::isError($mail)) {
	$result='0';
	//updateEmailTestResult($user_id,$result);
} else {
	$result='1';
	//updateEmailTestResult($user_id,$result);
}
echo $result;
}else{
	echo "UnAuthorize Access!!!";
}
?>