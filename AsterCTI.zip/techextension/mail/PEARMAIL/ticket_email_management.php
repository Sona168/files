<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
if(isset($_GET['ticket_id'])){
include('../../controller/route.php');
require_once "Mail.php";
include 'Mail/mime.php' ;
$portalInfo=getPortalURL();
$portal_url = $portalInfo['url'];
$customer_portal_url = $portal_url."/customer";
$ticket_id = $_GET['ticket_id'];
$ticket_info = getTicket($ticket_id);
$contact_info = getContact($ticket_info['data'][0]['contact_id']);
$contact_name = $contact_info['data'][0]['first_name']." ".$contact_info['data'][0]['last_name'];
$contact_email = $contact_info['data'][0]['email'];


if(!$contact_email){
echo "Contact ".$contact_name." dont have Email address to send.";
exit;
}
if($ticket_info['data'][0]['assigned_to'] == "1"){
	$agent_info = getAdminProfile($ticket_info['data'][0]['assigned_to']);
}else{
	$agent_info = getProfile($ticket_info['data'][0]['assigned_to']);
}
$agent_info = $agent_info['data'];
$agent_email = $agent_info['email'];
$agent_name = $agent_info['name'];

$company_name = getCompanyName();
$type = $_GET['type'];
if($type == "customer"){
	$name_of_type = $contact_name;
	$name_on_mail = $agent_name;
	$emmailconf = getEmailConfiguration('1');
}else{
	$name_of_type = $agent_name;
	$name_on_mail = $contact_name;
	$emmailconf = getEmailConfiguration($_GET['user_id']);
}
   // echo $email;
   $email = file_get_contents("template_process.php");
  
$body='';
if(isset($_GET['comment'])){
$comment_info = getLatestTicketComment($ticket_id,$type);
$comment = "<b>NEW COMMENT :</b> <font color='green'>".$comment_info['data'][0]['comment']."</font>";
$ticket_info['data'][0]['description'] = $ticket_info['data'][0]['description']."<br><br>".$comment;
	$subject = "New Comment Added On Ticket #".$ticket_id." ".$ticket_info['data'][0]['title'];
	$body.="Hi, <br>New Comments Added on Ticket : ".$ticket_id." from $type : $name_of_type";
}else if(isset($_GET['status'])){
	$subject = "Status of Ticket #".$ticket_id." is Updated ".$ticket_info['data'][0]['title'];
	$body.="Hi, <br>Status Was Changed for Ticket : ".$ticket_id." from $type : $name_of_type";
}else if(isset($_GET['ticket'])){
	$subject = "New Ticket Created, #".$ticket_id." ".$ticket_info['data'][0]['title'];
	$body.="Hi, <br>New Ticket Created. Ticket No : ".$ticket_id." from $type : $name_of_type";
}

if($ticket_info['data'][0]['status'] == "Open"){
	$status_color = "green";
}else if($ticket_info['data'][0]['status'] == "In Progress"){
		$status_color = "orange";
}else if($ticket_info['data'][0]['status'] == "Wait For Response"){
		$status_color = "blue";
}else if($ticket_info['data'][0]['status'] == "Closed"){
		$status_color = "red";
}
	
	$variables = array(
	"{{company_name}}" => $company_name,
	"{{status_color}}" => $status_color,
	"{{name}}" => $name_on_mail,
	"{{date}}" => $ticket_info['data'][0]['date_created'],
	"{{ticket_id}}" => $ticket_id,
	"{{status}}" => $ticket_info['data'][0]['status'],
	"{{priority}}" => $ticket_info['data'][0]['priority'],
	"{{contact_name}}" => $contact_name,
	"{{assign_agent}}" => $agent_name,
	"{{resolution}}" => $ticket_info['data'][0]['solution'],
	"{{title}}" => $ticket_info['data'][0]['title'],
	"{{description}}" => $ticket_info['data'][0]['description'],
	"{{customer_portal_url}}" => $customer_portal_url
	);

	foreach ($variables as $key => $value)
	$email = str_replace($key, $value, $email);
	
$email = str_replace("{{subject}}", $subject, $email);
$email = str_replace("{{description}}", $body, $email);


if($agent_email){
if($emmailconf['data']['email'] != $agent_email)
	$headers = array(
    'From' => $emmailconf['data']['email'],
    'To' => $agent_email,
    'Subject' => $subject
);
}


if($type == "customer"){
	$headers = array(
    'From' => $emmailconf['data']['email'],
    'To' => $emmailconf['data']['email'],
	'Cc' => $contact_email,
    'Subject' => $subject
	);
}else{
	$headers = array(
	'From' => $emmailconf['data']['email'],
	'To' => $contact_email,
	'Cc' => $emmailconf['data']['email'],
    'Subject' => $subject
	);
}
/* print_r($headers);
exit; */
$smtpType = $emmailconf['data']['security_type'];
$host = $emmailconf['data']['host'];
$port = $emmailconf['data']['port'];
$password = $emmailconf['data']['password'];


$crlf = "\n";
$mime = new Mail_mime(['eol' => $crlf]);
$mime->setHTMLBody($email);
$body = $mime->get();
$headers = $mime->headers($headers);

$smtp = Mail::factory('smtp', array(
        'host' => "$smtpType://$host",
		//'debug' => true,
        'port' => $port,
        'auth' => 'PLAIN',
		'socket_options' => array('ssl' => array('verify_peer' => false,'verify_peer_name' => false)),
        'username' => $emmailconf['data']['email'],
        'password' => $emmailconf['data']['password']
    ));
	
	
$mail = $smtp->send($emmailconf['data']['email'], $headers, $body);
if (PEAR::isError($mail)) {
	$result='0';
	//updateEmailTestResult($user_id,$result);
} else {
	$result='1';
	//updateEmailTestResult($user_id,$result);
}
echo $result;
}else{
	echo "UnAuthorize Access!!!";
}
?>