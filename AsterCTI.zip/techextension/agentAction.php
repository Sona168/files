<?php
include "controller/route.php";
if(isset($_GET['pauseResume'])){
	$user_id = $_GET['user_id'];
	$status = $_GET['status'];
	$user_info = getUserInfoFromId($user_id);
	$channel = $user_info['data'][0]['channel'];
	$extension = $user_info['data'][0]['extension'];
	$asterisk_ip_id = $user_info['data'][0]['asterisk_ip'];
	$asteriskDetails = getAsteriskById($asterisk_ip_id);
	$asteriskDetailsData =$asteriskDetails['data'][0];
	$DialerAsteriskIP = trim($asteriskDetailsData['ip']);
	$DialerAMIUsername = trim($asteriskDetailsData['ami_username']);
	$DialerAMIPassword = trim($asteriskDetailsData['ami_password']);
	$DialerAMIPort = $asteriskDetailsData['port'];
	if(!$DialerAMIPort)
	{
		$DialerAMIPort = "5038";
	}
	
	
	
	$timeout = 10;
	$socket = fsockopen($DialerAsteriskIP,$DialerAMIPort, $errno, $errstr, $timeout);
	fputs($socket, "Action: Login\r\n");
	fputs($socket, "UserName: $DialerAMIUsername\r\n");
	fputs($socket, "Secret: $DialerAMIPassword\r\n\r\n");
	$wrets=fgets($socket,128);
	fputs($socket, "Action: QueuePause\r\n" );
	fputs($socket, "ActionID: TEQueuePause\r\n" );
	fputs($socket, "Interface: Local/$extension@from-queue/n\r\n" );
	fputs($socket, "Paused: $status\r\n" );
	fputs($socket, "Reason: Break From AsterCTI\r\n\r\n" );
	$wrets=fgets($socket,128);
	$response = trim($wrets);
	if($response == "Response: Success")
	{
		print_r($wrets);
	}
	fputs($socket, "Action: Logoff\r\n\r\n");

$res = updateAgentStatusToPickCall($status,"",$user_id);
//print_r($res);
fclose($socket);
}
if(isset($_GET['checkExtensionQueueStatus'])){
	$extension = $_GET['extension'];
	$extensionStatusData = getExtensionQueueStatus($extension);
	print_r(json_encode($extensionStatusData['data']));
}
if(isset($_GET['checkLeftTime'])){
	$user_id = $_GET['user_id'];
	$breakTakenSec = getTotalBreakTaken($user_id);
	print_r($breakTakenSec);
}
?>