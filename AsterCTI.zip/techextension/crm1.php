<!DOCTYPE html>
  <?php include "header.php"; ?>
  <?php include "left_sidebar.php" ?>
<div class="content-wrapper">
	
<style type="text/css">
body {
    overflow:hidden;
}
</style>
<?php
$appendURL='';
if(isset($_GET['action']))
{
	if($_GET['action'] == "create")
	{
		$moduleName = $_GET['module'];
		$number = $_GET['number'];
		
		$appendURL = getUserCreateCRMURL($_SESSION['tech_user_id'],$moduleName,'user',$number);
		$crmURL = $profileDetails['crm_url'].$appendURL;
		echo "<script>location.href='$crmURL';</script>";
	}
	
	if($_GET['action'] == "view")
	{
		$moduleName = $_GET['module'];
		if(isset($_GET['id']))
		{
			$id = $_GET['id'];
		}else
		{
			$id="";
		}
		$appendURL = getUserCRMViewURL($_SESSION['tech_user_id'],$id,$moduleName,'user');
	}
}else{
	if(strpos($profileDetails['crm_url'], 'zoho') !== false) {
		$appendURL = "/ShowHomePage.do";
	}else
	{
		//$appendURL = "home/home.jsp?sdtd=1";
	}
}
?>
<script>

window.open('<?php echo $profileDetails['crm_url'].$appendURL; ?>', '_blank'); 
</script>
<strong>
CRM Opened on New TAB
</strong>
	
	
	</div>
<style>
.holds-the-iframe {
  background:url(image/loader.gif) center center no-repeat;
 }
</style>
	</div>
     <?php
	  include "footer.php";
	  include "footer_script.php";
	  ?>
	  <script language="javascript">
	  $(window).load(function() {
			//autoResizeDiv();
		});
        function autoResizeDiv()
        {
			document.getElementById('full-screen-me').height =($(document).height()-100);
        }
        window.onresize = autoResizeDiv;
    </script>
  </body>
</html>
