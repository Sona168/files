<!DOCTYPE html>

  <?php include "header.php" ?>
  <?php include "left_sidebar.php" ?>
  <?php 
  if(isset($_GET['id']))
  {
	$contactStatusInfo = getAllContactStatus();
	$contact_id = $_GET['id'];

	$userDetails = getContact($contact_id);
	if($_GET['action'] == "View")
	{
		$normalCalls = getAllContactCalls($contact_id);
		$dialerCalls = getAllContactDialerCalls($contact_id);
		$directSMS = getAllContactDirectSMS($contact_id);
		$campaignSMS = getAllContactCampaignSMS($contact_id);
		$meetingInfo = getMeeting("","",$contact_id,"","");
		$propertyforfields= "disabled";
		$propertyforfieldsoptional= "disabled";
	}else{
		$propertyforfields= "required";
		$propertyforfieldsoptional= "";
	}
	if($_GET['action'] == "Delete")
	{
		removeContact($contact_id);
		echo "<script>location.href='view_contact.php?action=remove'</script>";  
	}
	
  }else{
	echo "<script>location.href='view_contact.php'</script>";  
  }
  ?>
  
  <script>
  var contact_id = <?php echo json_encode($contact_id); ?>;
  var contact_name = <?php echo json_encode($userDetails['data'][0]['first_name']." ".$userDetails['data'][0]['last_name']); ?>;
  
  </script>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Contacts Information
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Contacts</a></li>
            <li class="active">Contact Details</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
		<form class="form-horizontal" method='post' >
          <div class="row">
		   <div class="box-footer">
                   <?php if($_GET['action'] == "View"){ ?>
				   <a href='contact_details.php?action=Edit&id=<?php echo $contact_id; ?>' class="btn btn-info "> <span class="glyphicon glyphicon-edit"></span> Edit</a>
				   <?php }else {?>
                    <button type="submit" name='submit' class="btn btn-primary"><span class="glyphicon glyphicon-refresh"></span> Update</button>
				   <?php } ?>
                  </div>
		  
		  
            <div class="col-md-6">
			
			 
			
			
            <div class="col-xs-12 table-responsive">
			
              <table class="table table-striped">
			
                <tbody>
				
				
				<tr>
                    <td>First Name</td>
                    <td>  <input type="text" class="form-control" id="fname" name ='fname' placeholder="First Name" value="<?php echo $userDetails['data'][0]['first_name']; ?>" <?php echo $propertyforfields; ?>></td>
                </tr>
				
				<tr>
                    <td>Last Name</td>
                    <td><input type="text" class="form-control" id="lname" name ='lname' placeholder="Last Name" value="<?php echo $userDetails['data'][0]['last_name']; ?>" <?php echo $propertyforfields; ?>></td>
                </tr>
				<tr>
                    <td>Email</td>
                    <td><input type="text" class="form-control" id="email" name ='email' placeholder="Email Address" value="<?php echo $userDetails['data'][0]['email']; ?>" <?php echo $propertyforfields; ?>></td>
                </tr>
				
				<tr>
                    <td>Prefix</td>
                    <td> <input type="text" class="form-control" id="prefix" name ='prefix' placeholder="" value="<?php echo $userDetails['data'][0]['prefix']; ?>" <?php echo $propertyforfieldsoptional; ?>></td>
                </tr>
				
				<tr>
                    <td>Primary Phone Number</td>
                    <td> <input type="text" class="form-control" id="phone" name ='phone' placeholder="Phone Number" value="<?php echo $userDetails['data'][0]['phone']; ?>" <?php echo $propertyforfields; ?> > 
<?php
if($_GET['action'] == "View")
{
	if($userDetails['data'][0]['phone']){
?>
				<a href="#">	<img src="image/caller.png" style="margin-top:10px;" height="25px" width="25px" title="Click to Call" onclick="originateDirectCall('<?php echo $userDetails['data'][$i]['prefix']."".$userDetails['data'][0]['phone']; ?>')" /></a>
<?php  if($smsFlag) {?>
					<a href="#"><img src="image/send_sms.png" style="margin-top:10px;" data-toggle="modal" data-target="#send_sms" height="25px" width="25px" title="Send SMS" onclick="setTosend('<?php echo $userDetails['data'][0]['phone']; ?>')"/> </a> </td>
<?php
	} } }
?>
                </tr>
				
				<tr>
                    <td>Status</td>
                    <td>
                   
                    <select class="form-control select2" id="status" name="status" <?php echo $propertyforfields; ?>>
					<option selected="selected" value="">Select Contact Status</option>
					<?php for($i=0;$i<$contactStatusInfo['count'];$i++){
						 if($contactStatusInfo['data'][$i]['status'] == $userDetails['data'][0]['status'])
							  {
								$selected="selected=selected";
							  }
							  else
							  {
								$selected="";
							  }
						?>
					<option <?php echo $selected; ?> value="<?php echo $contactStatusInfo['data'][$i]['status'] ?>" ><?php echo $contactStatusInfo['data'][$i]['status'] ?></option>
					<?php } ?>
                    
                    </select>
                </td>
                </tr>
				
				<input type="hidden" id="to_send">
				
				</tbody>
				</table>
				</div>
				</div>
			
			 <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">

                <tbody>
				<tr>
                    <td>Secondary Phone Number</td>
                    <td> <input type="text" class="form-control" id="phone2" name ='phone2' placeholder="Phone Number" value="<?php echo $userDetails['data'][0]['phone2']; ?>" <?php echo $propertyforfieldsoptional; ?>>
<?php
if($_GET['action'] == "View")
{
	if($userDetails['data'][0]['phone2']){
?>
				<a href="#">	<img src="image/caller.png" style="margin-top:10px;" height="25px" width="25px" title="Click to Call" onclick="originateDirectCall('<?php echo $userDetails['data'][$i]['prefix']."".$userDetails['data'][0]['phone2']; ?>')" /> </a>
<?php  if($smsFlag) {?>
					<a href="#"> <img src="image/send_sms.png" style="margin-top:10px;" data-toggle="modal" data-target="#send_sms" height="25px" width="25px" title="Send SMS" onclick="setTosend('<?php echo $userDetails['data'][0]['phone2']; ?>')"/> </a> </td>
					
<?php } } } ?>
                </tr>
			
			
			<tr>
					<td>City</td>
					<td><input type="text" class="form-control" id="city" name ='city' placeholder="City" value="<?php echo $userDetails['data'][0]['city']; ?>" <?php echo $propertyforfieldsoptional; ?>></td>
				</tr>
				
				<tr>
					<td>Postal Code</td>
					<td><input type="text" class="form-control" id="postal_code" name ='postal_code' placeholder="Postal Code" value="<?php echo $userDetails['data'][0]['postal_code']; ?>" <?php echo $propertyforfieldsoptional; ?>></td>
				</tr>
				
				<tr>
					<td>Country</td>
					<td><input type="text" class="form-control" id="country" name ='country' placeholder="Country" value="<?php echo $userDetails['data'][0]['country']; ?>" <?php echo $propertyforfieldsoptional; ?>></td>
				</tr>
			
				<tr>
                    <td>Address</td>
                    <td> <textarea  id="address" name="address" class="md-textarea form-control" placeholder="Address (Optional)" rows="3" <?php echo $propertyforfieldsoptional; ?>><?php echo $userDetails['data'][0]['address']; ?></textarea></td>
                </tr>
				
				<tr>
                    <td>Notes</td>
                    <td><textarea  id="notes" name="notes" class="md-textarea form-control" placeholder="Notes If Any" rows="3" <?php echo $propertyforfieldsoptional; ?>><?php echo $userDetails['data'][0]['note']; ?></textarea></td>
                </tr>
			
			
			<tr>
                    <td>Date Modified</td>
                    <td> <input type="text" class="form-control"  placeholder="Date Modified" value="<?php echo $userDetails['data'][0]['date_modified']; ?>" disabled></td>
                </tr>
				
				
				<tr>
                    <td>Date Created</td>
                    <td> <input type="text" class="form-control"  placeholder="Date Created" value="<?php echo $userDetails['data'][0]['date_created']; ?>" disabled></td>
                </tr>
				
				</tbody>
				
				</table>
				 
				
				</div>
			
				</div>
				
			
          </div><!-- /.row -->
		</form>
		
		<?php
			if($_GET['action'] == "View")
			{
		?>
		
		<div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Call Activities</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped" title="call details">
                    <thead title="call details">
                      <tr>
						 <th>Sr. No</th>
					   <th>Subject</th>
                        <th>Source Number</th>
                        <th>Destination Number</th>
						
                       
						<th>Direction</th>
						<th>Assigned User</th>
                       
						 <th>Action</th>
                      </tr>
                    </thead>
                    <tbody id="tableRow">
					<?php 
					//print_r($userDetails);
					$j=0;
					if($normalCalls['count'] >= 1)
					{
						$j++;
						for($i=0;$i<count($normalCalls['data']);$i++)
						{
							$userDetailssss = getUserInfoFromId($normalCalls['data'][$i]['user_id']);
							if($userDetailssss['count'] == "0")
							{
								$userDetailssss = getAdminInfoFromId($normalCalls['data'][$i]['user_id']);
							}
						
						?>
						  <tr>
							<td><?php echo $j; ?></td>
							<td><?php echo $normalCalls['data'][$i]['subject']; ?></td>
							<td><?php echo $normalCalls['data'][$i]['source_number']; ?></td>
							<td><?php echo $normalCalls['data'][$i]['destination_number']; ?></td>
							
							
							<td><?php echo $normalCalls['data'][$i]['direction']; ?></td>
						
							
							<td><a href="detail_user.php?action=View&id=<?php echo $userDetailssss['data'][0]['user_id']; ?>" target="new"><?php echo $userDetailssss['data'][0]['name']; ?></a></td>
							
							  <td class="btn-group">
									<a href="detail_calls.php?action=View&id=<?php echo $normalCalls['data'][$i]['id'];?>"><button class="btn btn-info btn-xs" style="float:left;margin-right:5px;">View</button></a>
									<!--<a href="detail_calls.php?action=Edit&id=<?php echo $normalCalls['data'][$i]['id'];?>"><button class="btn btn-success btn-xs" style="float:left;">Edit</button></a>-->
								</td>
						  </tr>
						<?php
						}
					}
					?>
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div>
		  
		  
		  <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Dialer Calls</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="dialer_call_table" class="table table-bordered table-striped">
                    <thead title="call details">
                      <tr>
						 <th>Sr. No</th>
						 <th>Campaign Name</th>
					  <th>Call Disposition</th>
					   <th>Agent Disposition</th>
					   <th>Billable Seconds</th>
						<th>Start Time</th>
						
						<th>Assigned User</th>
						<th>Action</th>
                      </tr>
                    </thead>
                    <tbody id="tableRow">
					<?php 
					//print_r($userDetails);
					$k=0;
					if($dialerCalls['count'] >= 1)
					{
						for($i=0;$i<count($dialerCalls['data']);$i++)
						{
							$k++;
							$userDetailssss = getUserInfoFromId($dialerCalls['data'][$i]['user_id']);
							if($userDetailssss['count'] == "0")
							{
								$userDetailssss = getAdminInfoFromId($dialerCalls['data'][$i]['user_id']);
							}
						$campaign_info = getDialerCampaignFromId($dialerCalls['data'][$i]['campaign_id']);
						?>
						  <tr>
						  <td><?php echo $k; ?></td>
						<td><a target='new' href="dialer_campaign_info.php?action=View&id=<?php echo $campaign_info['data'][0]['id']; ?>"><?php echo $campaign_info['data'][0]['name']; ?></a></td>
						<td><?php echo $dialerCalls['data'][$i]['disposition']; ?></td>
						<td><?php echo $dialerCalls['data'][$i]['agent_disposition']; ?></td>
						<td><?php echo $dialerCalls['data'][$i]['billableseconds']; ?></td>
						<td><?php echo $dialerCalls['data'][$i]['cdr_start_time']; ?></td>
						
							<td><a href="detail_user.php?action=View&id=<?php echo $userDetailssss['data'][0]['user_id']; ?>" target="new"><?php echo $userDetailssss['data'][0]['name']; ?></a></td>
							
							  <td class="btn-group">
									<a href="dialer_call_detail.php?call_id=<?php echo $dialerCalls['data'][$i]['id'];?>&contact_id=<?php echo $contact_id;?>"><button class="btn btn-info btn-xs" style="float:left;margin-right:5px;">View</button></a>
									
								</td>
						  </tr>
						<?php
						}
					}
					?>
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div>
		  
		  
		  
		  
		  
		  <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">SMS Activity</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="sms_activity" class="table table-bordered table-striped">
                    <thead title="call details">
                      <tr>
						<th>Sr. No</th>
						<th>Number</th>
						<th>SMS</th>
						<th>Status</th>
						<th>Direction</th>
						<th>Assigned User</th>
						<th>Date</th>
						<th>Action</th>
                      </tr>
                    </thead>
                    <tbody id="tableRow">
					<?php 
					//print_r($userDetails);
					$k=0;
					if($directSMS['count'] >= 1)
					{
						for($i=0;$i<count($directSMS['data']);$i++)
						{
							$k++;
							$userDetailssss = getUserInfoFromId($directSMS['data'][$i]['user_id']);
							if($userDetailssss['count'] == "0")
							{
								$userDetailssss = getAdminInfoFromId($directSMS['data'][$i]['user_id']);
							}
						
						?>
						  <tr>
						  <td><?php echo $k; ?></td>
						<td><?php echo $directSMS['data'][$i]['number']; ?></td>
						<td><?php echo shortText(urldecode($directSMS['data'][$i]['sms'])); ?></td>
						<td><?php echo $directSMS['data'][$i]['status']; ?></td>
						<td><?php echo $directSMS['data'][$i]['direction']; ?></td>
						<td><?php echo $userDetailssss['data'][0]['name']; ?></td>
						<td><?php echo $directSMS['data'][$i]['date_time']; ?></td>
							
							  <td class="btn-group">
									<a href="sms_details.php?action=View&id=<?php echo $directSMS['data'][$i]['id']; ?>"><button class="btn btn-info btn-xs" style="float:left;margin-right:5px;">View</button></a>
									
								</td>
						  </tr>
						<?php
						}
					}
					?>
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div>
		  
		  
		  <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">SMS Campaign Activity</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="sms_activity_campaign" class="table table-bordered table-striped">
                    <thead title="call details">
                      <tr>
						<th>Sr. No</th>
						<th>Campaign Name</th>
						<th>Number</th>
						<th>SMS</th>
						<th>Status</th>
						<th>Assigned User</th>
						<th>Date</th>
						<th>Action</th>
                      </tr>
                    </thead>
                    <tbody id="tableRow">
					<?php 
					//print_r($userDetails);
					$k=0;
					if($campaignSMS['count'] >= 1)
					{
						for($i=0;$i<count($campaignSMS['data']);$i++)
						{
							$k++;
							$userDetailssss = getUserInfoFromId($campaignSMS['data'][$i]['user_id']);
							if($userDetailssss['count'] == "0")
							{
								$userDetailssss = getAdminInfoFromId($campaignSMS['data'][$i]['user_id']);
							}
							$campaignInfo = getSMSCampaignFromId($campaignSMS['data'][$i]['campaign_id']);
							$campaign_name = $campaignInfo['data'][0]['name'];
						
						?>
						  <tr>
						  <td><?php echo $k; ?></td>
						<td><?php echo $campaign_name; ?></td>
						<td><?php echo $campaignSMS['data'][$i]['number']; ?></td>
						<td><?php echo shortText(urldecode($campaignSMS['data'][$i]['sms'])); ?></td>
						<td><?php echo $campaignSMS['data'][$i]['status']; ?></td>
						<td><?php echo $userDetailssss['data'][0]['name']; ?></td>
						<td><?php echo $campaignSMS['data'][$i]['date_time']; ?></td>
						
						
							
							  <td class="btn-group">
									<a href="sms_details_campaign.php?action=View&contact_id=<?php echo $contact_id; ?>&campaign_id=<?php echo $campaignSMS['data'][$i]['campaign_id']; ?>&id=<?php echo $campaignSMS['data'][$i]['id']; ?>"><button class="btn btn-info btn-xs" style="float:left;margin-right:5px;">View</button></a>
									
								</td>
						  </tr>
						<?php
						}
					}
					?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
		  
		  
		  
		  
		  <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Meetings</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="meeting_table" class="table table-bordered table-striped">
                    <thead title="call details">
                      <tr>
						<th>Sr. No</th>
						<th>Subject</th>
						<th>Status</th>
						<th>Assigned User</th>
						<th>Start Date Time</th>
						<th>Created By</th>
						<th>Action</th>
                      </tr>
                    </thead>
                    <tbody id="tableRow">
					<?php 
					//print_r($userDetails);
					$k=0;
					if($meetingInfo['count'] >= 1)
					{
						for($i=0;$i<count($meetingInfo['data']);$i++)
						{
							$k++;
							$userDetailssss = getUserInfoFromId($meetingInfo['data'][$i]['assigned_user']);
							if($userDetailssss['count'] == "0")
							{
								$userDetailssss = getAdminInfoFromId($meetingInfo['data'][$i]['assigned_user']);
							}
							
							$created_by = getUserInfoFromId($meetingInfo['data'][$i]['created_by']);
							if($created_by['count'] == "0")
							{
								$created_by = getAdminInfoFromId($meetingInfo['data'][$i]['created_by']);
							}
							
						?>
						  <tr>
						  <td><?php echo $k; ?></td>
						<td><?php echo shortText(urldecode($meetingInfo['data'][$i]['subject'])); ?></td>
						<td><?php echo $meetingInfo['data'][$i]['status']; ?></td>
						<td><?php echo $userDetailssss['data'][0]['name']; ?></td>
						<td><?php echo $meetingInfo['data'][$i]['start_date']." ".$meetingInfo['data'][$i]['start_time']; ?></td>
						<td><?php echo $created_by['data'][0]['name']; ?></td>
						
							  <td class="btn-group">
									<a href="meeting_info.php?action=View&id=<?php echo $meetingInfo['data'][$i]['id'] ?>"><button class="btn btn-info btn-xs" style="float:left;margin-right:5px;">View</button></a>
								</td>
						  </tr>
						<?php
						}
					}
					?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
			<?php } ?>
		  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

	  
	  
	  <?php
		if(isset($_POST['submit']))
		{
			$first_name = $_POST['fname'];
			$last_name = $_POST['lname'];
			$email = $_POST['email'];
			$prefix = $_POST['prefix'];
			$phone = $_POST['phone'];
			$phone2 = $_POST['phone2'];
			$address = $_POST['address'];
			$status = $_POST['status'];
			$assigned_user = $_SESSION['tech_user_id'];
			$note = $_POST['notes'];
			
			$city = $_POST['city'];
			$postal_code = $_POST['postal_code'];
			$country = $_POST['country'];
			
			
				$res = updateContact($contact_id,$first_name,$last_name,$email,$phone,$address,$phone2,$status,$assigned_user,$note,$prefix,$city,$postal_code,$country);
				if($res['status']=="1")
				{
//					echo "<script>toastr['success']('Contact Updated Successfully')</script>";
					echo "<script>location.href='contact_details.php?action=View&id=$contact_id';</script>";
				}
				else
				{
					echo "<script>toastr['warning']('Something Went Wrong')</script>";
				}
			
		}
	  ?>
     <?php
	
	  include "footer.php";
	  include "footer_script.php";
	  ?>
    <script>
	
	function setTosend(number){
		$('#phone_tosend').html("Send SMS To : "+number+" Contact Name : "+contact_name)
		$('#to_send').val(number)
	}
	
	 $(".select2").select2();
	 $(function () {
		var table = $('#example1').DataTable( {
		"order": [[ 6, "desc" ]],
		"iDisplayLength": 5,
		 "aLengthMenu": [[5, 10, 15, -1], [5, 10, 15, "All"]],
		"autoWidth": true,
		"dom": '<"top"Blf>rt<"bottom"p><"clear">',
		 "language": {
			"emptyTable": "No Any Calls to "+contact_name
			}
	
	});	
	
		var table = $('#dialer_call_table').DataTable( {
		"order": [[ 1, "desc" ]],
		"autoWidth": true,
		"iDisplayLength": 5,
		 "aLengthMenu": [[5, 10, 15, -1], [5, 10, 15, "All"]],
		"dom": '<"top"Blf>rt<"bottom"p><"clear">',
		"language": {
			"emptyTable": "No Any Calls From Any Dialer Campaign to "+contact_name
		}
	});


	var table = $('#sms_activity').DataTable( {
		"order": [[ 1, "desc" ]],
		"autoWidth": true,
		"iDisplayLength": 5,
		 "aLengthMenu": [[5, 10, 15, -1], [5, 10, 15, "All"]],
		"dom": '<"top"Blf>rt<"bottom"p><"clear">',
		"language": {
			"emptyTable": "No Any Direct SMS to "+contact_name
		}
	});
	
	
		var table = $('#sms_activity_campaign').DataTable( {
		"order": [[ 1, "desc" ]],
		"autoWidth": true,
		"iDisplayLength": 5,
		 "aLengthMenu": [[5, 10, 15, -1], [5, 10, 15, "All"]],
		"dom": '<"top"Blf>rt<"bottom"p><"clear">',
		"language": {
			"emptyTable": "No Any SMS Camapign Text to "+contact_name
		}
	});
	
	
	var table = $('#meeting_table').DataTable( {
		"order": [[ 1, "desc" ]],
		"autoWidth": true,
		"iDisplayLength": 5,
		 "aLengthMenu": [[5, 10, 15, -1], [5, 10, 15, "All"]],
		"dom": '<"top"Blf>rt<"bottom"p><"clear">',
		"language": {
			"emptyTable": "No Any Meeting Schedule for "+contact_name
		}
	});
	
	
      });
	 
    </script>
  </body>
</html>
