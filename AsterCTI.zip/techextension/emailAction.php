<?php
include("controller/route.php");
$user_id = $_SESSION['tech_user_id'];
if(isset($_GET['action']))
{
	$email = $_GET['email'];
	$password = $_GET['password'];
	$host = $_GET['host'];
	$port = $_GET['port'];
	$secure = $_GET['secure'];
	$mail_type = $_GET['mail_type'];
	if($_GET['action'] == "create"){
	$res = createEmailConfiguration($user_id,$email,$password,$host,$port,$secure,$mail_type);
	if($res['status'] == "created"){
		echo "1";
	}else{
		echo "0";
	}
	}else if($_GET['action'] == "update"){
		$res = updateEmailConfiguration($user_id,$email,$password,$host,$port,$secure,$mail_type);
		if($res == "updated"){
			echo "1";
		}else{
			echo "0";
		}
	}
}
?>
