<!DOCTYPE html>
  <?php include "header.php" ?>
  <?php include "left_sidebar.php" ?>
  
<?php
  if(isset($_POST['search'])){
	  $datebetween = $_POST['datebetween'];
	  if($datebetween){
		$datebetweenarray = explode("-",$datebetween);
		//print_r($datebetweenarray);
		$fromDate = $datebetweenarray[0];
		$toDate = $datebetweenarray[1];
		$breakInfo = searchBreakOfUser($fromDate,$toDate,$_SESSION['tech_user_id']);
	  }
  }else{
	$breakInfo = getBreakOfUser($_SESSION['tech_user_id']);
  }
  ?>
  
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
       
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Break Report</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
		   <form method="POST" action="break_report.php">
     <div class="col-xs-12">
			<div class="col-xs-3">
		
			<label>Date-wise Search</label>
			<div class="input-group">
			  <div class="input-group-addon">
				<i class="fa fa-calendar"></i>
			  </div>
			  <input type="text"  autocomplete="off" class="form-control" name="datebetween" id="reservationtime">
			</div>
			</div>
					
		
				</div>
				<button type="submit" name="search" class="btn btn-primary center-block"><span class="fa fa-search"></span> Search </button>
				</form>
				</div>
				

				<br>
		<div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Break Report</h3>
				  <?php 
				  $breakTaken =  gmdate("i:s", $breakTaken);
				  ?>
				  &nbsp;&nbsp;&nbsp;&nbsp;
				  <p class="badge bg-blue">Total Break Spent Today</p>  <p class="badge bg-red"><?php echo $breakTaken; ?></p>
				  
				  
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
						<th>Sr No.</th>
                        <th>Status</th>
						<th>Date</th>
                      </tr>
                    </thead>
                    <tbody id="tableRow">
					<?php 
					//print_r($breakInfo);
					if($breakInfo['count'] >= 1)
					{
					$j=0;
						for($i=0;$i<count($breakInfo['data']);$i++)
						{
						$j++;
							if($breakInfo['data'][$i]['action'] == '0')
							{
								$color = "green";
								$value = "Resume";
							}else
							{
								$color = "orange";
								$value = "Paused";
							}
							
						?>
						  <tr>
						  <td><?php echo $j; ?></td>
							<td class="badge bg-<?php echo $color; ?>"><?php echo $value; ?></td>
							<td><?php echo $breakInfo['data'][$i]['date_time']; ?></td>
							
						  </tr>
						<?php
						}
					}
					?>
					  
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	
     <?php
	  include "printDataTableJS.php.php";
	  include "footer.php";
	  include "footer_script.php";
	  ?>
     <script>
     $(function () {
		var table = $('#example1').DataTable( {
		"order": [[ 2, "desc" ]],
		"autoWidth": true,
		"dom": '<"top"Blf>rt<"bottom"p><"clear">',
		buttons: [
			{
				extend: 'print',
				exportOptions: {
				columns: ':visible'
				}
			},
			{
				extend: 'pdf',
				download:'open',
				title: '',
				orientation:'landscape',
				pageSize:'LEGAL',
				exportOptions: {
				columns: ':visible'
			}
			},
			{
				extend: 'excel',
				title: '',
				exportOptions: {
				columns: ':visible'
			}
			},
			{
			extend: 'csv',
				title: '',
				exportOptions: {
				columns: ':visible'
			}
			},
			'copy',
			{
				extend: 'colvis',
				title: '',
				collectionLayout:'fixed two-column'
			}
		]
	});	
      });
	  $(function () {
        $(".select2").select2();
		$('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
      });
    </script>
	
	
	
  </body>
</html>
