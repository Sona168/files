 <!-- Left side column. contains the logo and sidebar -->
 <?php
 
 //$_SESSION['user_extension']
 ?>
 
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo $profileDetails['profile_image']; ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p><?php echo $profileDetails['name']; ?></p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
          <!-- search form -->
  
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header" style="color:white;"><?php echo $company_name; ?> Menu</li>
           
            
               <li <?php if($url=='home.php'){echo 'class="active"';}?>><a href="home.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
			   
			   
			   <li class="treeview <?php if($url=='view_contact.php' || $url=='create_contact.php' || $url=='import_contact.php' || $url=='update_contact.php' || $url=='contact_map.php' || $url=='contact_details.php'){echo "active";}?>">
              <a href="#">
                <i class="fa fa-users" style="color:#e4e066d1;"></i>
                  <span>Contacts</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li <?php if($url=='create_contact.php'){echo 'class="active"';}?>><a href="create_contact.php"><i class="fa fa-plus"></i>Create Contact</a></li>
				
				<li <?php if($url=='view_contact.php' || $url=='contact_details.php'){echo 'class="active"';}?>><a href="view_contact.php"><i class="fa fa-eye"></i> <span>View Contact</span></a></li>
				
              </ul>
            </li>
			   
			   
			 <li class="treeview <?php if($url=='view_meeting.php' || $url=='create_meeting.php' || $url=='meeting_info.php'){echo "active";}?>">
              <a href="#">
                <i class="fa fa-exchange" style="color:#3c8dbc;"></i>
                  <span>Meeting</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li <?php if($url=='create_meeting.php'){echo 'class="active"';}?>><a href="create_meeting.php"><i class="fa fa-plus"></i>Create Meeting</a></li>
				
				<li <?php if($url=='view_meeting.php'){echo 'class="active"';}?>><a href="view_meeting.php"><i class="fa fa-eye"></i> <span>View Meeting</span></a></li>
              </ul>
            </li>
			  
			  <li class="treeview <?php if($url=='view_tickets.php' || $url=='create_ticket.php' || $url=='update_ticket.php' || $url=='ticket_details.php'){echo "active";}?>">
              <a href="#">
                <i class="fa fa-ticket" style="color:#dd4b39;"></i>
                  <span>Support Ticket</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li <?php if($url=='create_ticket.php'){echo 'class="active"';}?>><a href="create_ticket.php"><i class="fa fa-plus"></i>Create Ticket</a></li>
				
				<li <?php if($url=='view_tickets.php'){echo 'class="active"';}?>><a href="view_tickets.php"><i class="fa fa-eye"></i> <span>View Ticket</span></a></li>
              </ul>
            </li>
			   
               <li <?php if($url=='call_popup.php'){echo 'class="active"';}?>><a href="call_popup.php"><i class="fa fa-window-restore" style="color:#dd4b39;"></i> <span>Call Popup</span></a></li>
               <li <?php if($url=='crm.php'){echo 'class="active"';}?>><a href="crm.php"><i class="fa fa-id-card-o" style="color:#7fb3b5;"></i> <span>User CRM</span></a></li>
			
			
			 <li class="treeview <?php if($url=='view_calls.php' || $url=='view_dialer_log.php' || $url=='dialer_call_details.php' || $url=='break_report.php'){echo "active";}?>">
              <a href="#">
                <i class="fa fa-phone" style="color:#00a65a;"></i>
                  <span>Reports</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
               <!-- <li><a href="#"><i class="fa fa-circle-o"></i> Create Call Log</a></li> -->
				<li <?php if($url=='view_calls.php'){echo 'class="active"';}?>><a href="view_calls.php"><i class="fa fa-phone"></i> <span>Manual Call Logs</span></a></li>
				<li <?php if($url=='view_dialer_log.php' || $url=='dialer_call_details.php'){echo 'class="active"';}?>><a href="view_dialer_log.php"><i class="fa fa-phone"></i> <span>Dialer Call Logs</span></a></li>
				<!--<li <?php if($url=='break_report.php'){echo 'class="active"';}?>><a href="break_report.php"><i class="fa fa-phone"></i> <span>Break Report</span></a></li>-->
				
              </ul>
            </li>
			
			
			
			<li class="treeview <?php if($url=='view_sms.php' || $url=='new_sms.php'){echo "active";}?>">
              <a href="#">
                <i class="fa fa-comment" style="color:#e6e600;"></i>
                  <span>SMS</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li <?php if($url=='new_sms.php'){echo 'class="active"';}?>><a href="new_sms.php"><i class="fa fa-envelope"></i>New SMS</a></li>
				
				<li <?php if($url=='view_sms.php'){echo 'class="active"';}?>><a href="view_sms.php"><i class="fa fa-comment"></i> <span>View SMS Logs</span></a></li>
              </ul>
            </li>
		<li><a href="https://chrome.google.com/webstore/detail/ignore-x-frame-headers-te/knonhljeipkkgjfnakhgcglccgfegank" target="_blank"><i class="fa fa-plus"></i> <span>Add Click To Call</span></a></li>
		
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>
	  
	  

	  	<div class="modal fade" id="abc" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
   
      <div class="modal-body">
        <form>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Number To Call:</label>
            <input type="text" class="form-control" id="callto" autofocus>
          </div>
        </form>
      </div>
      <div class="modal-footer">
		<button type="button" class="btn btn-primary" onclick='originateCalls()'>Dial</button>
		<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade left" id="autodialer" tabindex="-1" role="dialog" aria-labelledby="exampleModalPreviewLabel" aria-hidden="true">
<form method="GET" action="dialer.php" id="campaign_list">
  <div class="modal-dialog modal-full-height modal-left" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalPreviewLabel">Select Campaign</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="campaign_body">
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
		<button type="submit" onclick="return checkSelectedCampaign();" class="btn btn-success">Select Campaign</button>
      </div>
    </div>
  </div>
  </form>
</div>
 <div id="loaderForDialerFirstClick"></div>
<script>
function checkSelectedCampaign(){
	if($("#campaign_id").val() ==""){
		toastr["warning"]("Please Select Campaign to Start Dialer")
		return false;
	}
	else
	{
		var campaign_id = $("#campaign_id").val();
		
		$.ajax({url: "getUpdatedCallInformation.php?checkAdminAllowDialerLogin=login&user_id="+user_id+"&campaign_id="+campaign_id, success: function(statusAgent){
if(statusAgent == "1"){
	console.log("statusAgent : "+statusAgent);
	$.ajax({url: "getUpdatedCallInformation.php?checkCampaignTime=current&campaign_id="+campaign_id, success: function(timeresult){
		 var myObj = JSON.parse(timeresult);
	if(myObj.status == "1"){
			if(myObj.camp_status == "1")
			{
				$('#autodialer').modal('hide');
				$("form").attr('target', '_blank');
				$("#campaign_list").submit();
			}else{
				console.log(myObj);
				toastr["warning"]("Campaign is not Active")
			}
	}else{
		console.log(myObj);
		toastr["warning"]("Campaign Start time and Server time is not matched")
		return false;
	}
			}}); 
			
			
}else{
	toastr["warning"]("Admin have Pause you to login inside this campaign")
		return false;
}
		}}); 
		return false;
	}
}

</script>