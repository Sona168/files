<?php
include "controller/route.php";
if(isset($_GET['autodialer'])){
	$user_id = $_GET['user_id'];
	$agentStatus = findLoggedAgentInAnyCampaign($user_id);

	if($agentStatus['count'] == "0"){
		$packetToSend['status']="0";
	}else{
		$packetToSend['status']="1";
		$packetToSend['campaign_id']=$agentStatus['campaign_id'];
		$packetToSend['login_status']=$agentStatus['login_status'];
	}
	print_r(json_encode($packetToSend));
}else if(isset($_GET['getUserActiveDialerCampaign'])){
	$user_id = $_GET['user_id'];
	$campaignDetails = getUserActiveDialerCampaign($user_id);
	?>
				  <div class="col-xs-12">
					<div class="form-group">
                    
                    <select class="form-control select2" name="campaign_id" id="campaign_id" data-width="100%">
					<option selected="selected" value="">Select Campaign</option>
					<?php
					for($i=0;$i<$campaignDetails['count'];$i++){
					?>
					<option value="<?php echo $campaignDetails['campaign_id'][$i]; ?>" ><?php echo $campaignDetails['campaign_name'][$i]; ?></option>
                    <?php } ?>
                    </select>
                  </div>
				</div>
	<?php
	
	
	
	
}else if(isset($_GET['checkAdminAllowDialerLogin']))
{
	$user_id = $_GET['user_id'];
	$campaign_id = $_GET['campaign_id'];
	$status = checkAdminAllowDialerLogin($campaign_id,$user_id);
	$status = $status['login_status'];
	echo $status;
}else if(isset($_GET['logoutUserFromDialer'])){
	$user_id = $_GET['user_id'];
	$campaign_id = $_GET['campaign_id'];
	makeAgentLoginLogoutInDialer($campaign_id,$user_id,"0");
	removeLiveCallForAgent($user_id);
}else if(isset($_GET['changeAgentStatusInCampaign']))
{
	$user_id = $_GET['user_id'];
	$campaign_id = $_GET['campaign_id'];
	$status = $_GET['status'];
	$res = makeAgentLoginLogoutInDialer($campaign_id,$user_id,$status);
	echo $res;
}else if(isset($_GET['checkCampaignTime'])){
	$campaign_id = $_GET['campaign_id'];
	$res = checkDialerTimeWithCurrentTime($campaign_id);
	print_r(json_encode($res));
	//echo $res['status'];
}else if(isset($_GET['findContact'])){
	$contact_id = $_GET['contact_id'];
	$contact_info = getContact($contact_id);
	$first_name = $contact_info['data'][0]['first_name'];
	$last_name = $contact_info['data'][0]['last_name'];
	$phone = $contact_info['data'][0]['phone'];
	$email = $contact_info['data'][0]['email'];
	$address = $contact_info['data'][0]['address'];
	$status = $contact_info['data'][0]['status'];
	$contactInfo = array("first_name"=>$first_name,"last_name"=>$last_name,"phone"=>$phone,"email"=>$email,"address"=>$address,"status"=>$status);
	print_r(json_encode($contactInfo));
}else if(isset($_GET['findAgent'])){
$user_id = $_GET['user_id'];
	$user_info = getUserInfoFromId($user_id);
	$name = $user_info['data'][0]['name'];	
	//$userInfo = array("name"=>$first_name);
	//$name = $user_info['data'][0]['user_id'];
	$userInfo = array("name"=>$name);
	print_r(json_encode($userInfo));
}
else{
$asteriskid = trim($_GET['asterisk_id']);
$res = getCallInfoAfterUpdation($asteriskid);
print_r(json_encode($res));
}
?>