<!DOCTYPE html>

  <?php include "header.php" ?>
  <?php include "left_sidebar.php" ?>
  
  <?php
  if(!isset($_GET['call_id']))
  {
	echo "<script>location.href='index.php'</script>";	  
  }
	$contact_id = $_GET['contact_id'];
	if($contact_id){
	$contactInfo = getContact($contact_id);
	$crm_id  = $contactInfo['data'][0]['crm_id'];
	$modulename  = $contactInfo['data'][0]['modulename'];
	}
	$callDetails = getDialerCallLogID($_GET['call_id']);
	$campaign_info = getDialerCampaignFromId($callDetails['data'][0]['campaign_id']);
	?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Call Details
            <small>#<?php echo $callDetails['data'][0]['id']; ?></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">TE Dialer</a></li>
			<li><a href="#">Call Report</a></li>
			<li><a href="#">Contact Call Report</a></li>
            <li class="active">Call Log</li>
          </ol>
        </section>
<!--
        <div class="pad margin no-print">
          <div class="callout callout-info" style="margin-bottom: 0!important;">
            <h4><i class="fa fa-info"></i> Note:</h4>
            This page has been enhanced for printing. Click the print button at the bottom of the invoice to test.
          </div>
        </div>
-->
        <!-- Main content -->
        <section class="invoice">
          <!-- title row -->
          <div class="row">
            <div class="col-xs-12">
              <h2 class="page-header">
                <i class="fa fa-globe"></i> Dialer Campaign <?php echo $campaign_info['data'][0]['name']; ?> Call for <a href="contact_details.php?action=View&id=<?php echo $contactInfo['data'][0]['id']; ?>" target="new"><?php echo $contactInfo['data'][0]['first_name']." ".$contactInfo['data'][0]['last_name']; ?> </a>
                <small class="pull-right">Date: <?php echo $callDetails['data'][0]['cdr_start_time']; ?></small>
              </h2>
            </div><!-- /.col -->
          </div>
         

          <!-- Table row -->
          <div class="row">
		   <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">
                <tbody>
				<tr>
		            <td>Call ID</td>
                    <td><?php echo $callDetails['data'][0]['id']; ?></td>
                  </tr>

				<tr>
                    <td>Source Number</td>
                    <td><?php echo $callDetails['data'][0]['source_number']; ?></td>
                  </tr>
                  <tr>
                    <td>Destination Number</td>
                    <td><?php echo $callDetails['data'][0]['destination']; ?></td>
                  </tr>
				  <?php 
				  if($modulename && $crm_id){
				  ?>
				   <tr>
                    <td>CRM ID</td>
                    <td><?php echo $crm_id; ?></td>
                  </tr>
				  <?php } ?>
				  
				  		<?php 
if($modulename)
{
	?>
	 <tr>
                    <td><?php echo "CRM Module Name"; ?></td>
                    <td><?php echo $modulename; ?></td>
                  </tr>
	<?php
}?>
				  
                
				
				   <tr>
                        <td>Recording Link</td>
                    <td>
					
					<?php
					if(!$callDetails['data'][0]['recording'])
					{
					?>
					
						<strong>NOT YET SET</strong>
					
					<?php
					}else
					{?>
						<!--<a href="<?php echo $callDetails['data'][0]['recording']; ?>" target="new"><img src='../image/play.gif'/></a>-->
						<audio id='recordingURL' src='<?php echo $callDetails['data'][0]['recording']; ?>' controls preload="auto" autobuffer></audio>
						<?php
					}
					?>
					
					</td>
                  </tr>
				  
				   <tr>
				   <?php
					$userDetails = getUserInfoFromId($callDetails['data'][0]['user_id']);
					if($userDetails['count'] == "0")
							{
								
								$userDetails = getAdminInfoFromId($callDetails['data'][0]['user_id']);
							}
				   ?>
                    <td>Assigned User</td>
                    <td><?php echo $userDetails['data'][0]['name']; ?></td>
                  </tr>
				  
				   <tr>
                    <td>Start Date</td>
                    <td><?php echo $callDetails['data'][0]['cdr_start_time']; ?></td>
                  </tr>
				  
				   <tr>
                    <td>Answer Date</td>
                    <td><?php echo $callDetails['data'][0]['cdr_answer_time']; ?></td>
                  </tr>
				  
				   <tr>
                    <td>End Date</td>
                    <td><?php echo $callDetails['data'][0]['cdr_end_time']; ?></td>
                  </tr>
				  
				  <?php
				  $agentInfo = getUserInfoFromId($callDetails['data'][0]['user_id']);
				  ?>
				  <tr>
                    <td>Call Agent</td>
                    <td><?php echo $agentInfo['data'][0]['name']; ?></td>	
                  </tr>
				  
				  
                </tbody>
              </table>
            </div>
			</div>
			
			 <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">

                <tbody>
				<tr>
                    <td>PBX ID</td>
                    <td><?php echo $callDetails['data'][0]['unique_id']; ?></td>
                 </tr>
				<tr>
                    <td>Call Disposition</td>
                    <td><?php echo $callDetails['data'][0]['disposition']; ?></td>
                  </tr>
				  
				  
				  <tr>
                    <td>Agent Disposition</td>
                    <td><?php echo $callDetails['data'][0]['agent_disposition']; ?></td>
                  </tr>
				  
				  <tr>
                    <td>Last Data</td>
                    <td><?php echo $callDetails['data'][0]['lastdata']; ?></td>
                  </tr>
				  <tr>
                    <td>Total Seconds</td>
                    <td><?php echo $callDetails['data'][0]['duration']; ?></td>
                  </tr>
				  <tr>
                    <td>Billable Seconds</td>
                    <td><?php echo $callDetails['data'][0]['billableseconds']; ?></td>
                  </tr>
				  
				
				
				 <tr>
                    <td>Asterisk Caller ID</td>
                    <td><?php echo $callDetails['data'][0]['callerid']; ?></td>
                  </tr>
				   <tr>
                    <td>Channel</td>
                    <td><?php echo $callDetails['data'][0]['channel']; ?></td>
                  </tr>
				   <tr>
                    <td>AMA Flag</td>
                    <td><?php echo $callDetails['data'][0]['amaflag']; ?></td>
                  </tr>
				   <tr>
					<td>Last Application</td>
					<td><?php echo $callDetails['data'][0]['lastapplication']; ?></td>
				  </tr>
				  
				  
				</tbody>
				</table>
				</div>
				</div>
			
          </div><!-- /.row -->

         

		  
        </section><!-- /.content -->
        <div class="clearfix"></div>
      </div><!-- /.content-wrapper -->
     <script>
	 function openViewCRMPage(id,module)
		{
			window.open('crm.php?action=view&id='+id+'&module='+module);
		}
	 
	 </script>
     <?php
	
	  include "footer.php";
	  //include "control_sidebar.php";
	  include "footer_script.php";
	  ?>


  </body>
</html>
