<?php
include_once "controller/route.php";

 $unreadSMS = getAllUnreadSMSDetails();
 $unreadSMSCOunt = $unreadSMS['count'];
 $smsNotificationStyle='danger';
 if($unreadSMSCOunt == 0)
 {
	 $smsNotificationStyle="success";
	 $smsNotificationback="green";
 }else
 {
	 $smsNotificationStyle="danger";
	 $smsNotificationback="red";
 }
?>
<ul class="nav navbar-nav">








  <li class="dropdown messages-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <i class="fa fa-envelope"></i>
                  <span class="label label-<?php echo $smsNotificationStyle; ?>"><?php echo $unreadSMSCOunt; ?></span>
                </a>
                <ul class="dropdown-menu">
                  <li class="header" style='background-color:<?php echo $smsNotificationback; ?>;color:white;'><?php echo $unreadSMSCOunt; ?> Unread SMS</li>
                 
                  <li class="footer"><a href="new_sms.php">Check Unread SMS</a></li>
                </ul>
              </li>





			  </ul>