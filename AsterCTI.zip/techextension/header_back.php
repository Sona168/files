<?php
include_once("controller/route.php");
if(!$_SESSION['tech_user_id'])
{
	echo "<script>location.href='login.php'</script>";
}
$url=basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);
$current_user = $_SESSION['tech_user_id'];
$responseData = getProfile($current_user);
$profileDetails = $responseData['data'];
$asteriskData = getAllAsteriskInfo();
$asteriskDataCount = count($asteriskData['data']);
$crmData = getAllCRMInfo();
$crmDataCount = $crmData['count'];
$company_name = getCompanyName();
$three_company_name = substr($company_name, 0, 3);
if($url == "dialer.php"){
	$visibility = 'display:none;';
	$showvisibility = 'display:inline-block;';
}else{
	$visibility = 'display:inline-block;';
	$showvisibility = 'display:none;';
}

$techextensionModules = getAllLicenseModuleInfo();
$smsFlag=true;
if($techextensionModules['data'][$i]['name'] == "SMS")
{
	if($techextensionModules['data'][$i]['status'] != "1")
	{
		$smsFlag=false;
	}
}
$ticketPriority=array("Low","Normal","High","Urgent");
?>

<script>
var user_id = <?php echo json_encode($_SESSION['tech_user_id']) ?>;
</script>
<html>
  <head>
  <style>
#loaderForDialerFirstClick {
    display: none;
    position: fixed;
    width: 100%;
    height: 100%;
    background-color: #000;
    z-index: 999;
	opacity: 0.6;
    top: 0;
    left: 0;
}
  
</style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $company_name; ?> | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <?php include "header_css.php"; ?>
	 <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
	<link rel="icon" href="image/favicon.ico" type="image/x-icon">
  </head>
  <body class="hold-transition skin-red sidebar-mini">
    <div class="wrapper">

      <header class="main-header">
        <!-- Logo -->
        <a href="home.php" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b><?php echo $three_company_name; ?></b></span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b><?php echo $company_name; ?></b></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
		  
		  
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
        
              <li class="dropdown user user-menu" style='<?php echo $visibility; ?>'>
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="<?php echo $profileDetails['profile_image']; ?>" class="user-image" alt="User Image">
                  <span class="hidden-xs"><?php echo $profileDetails['name']; ?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="<?php echo $profileDetails['profile_image']; ?>" class="img-circle" alt="User Image">
                    <p>
                      <?php echo $profileDetails['name']; ?> - <?php echo $profileDetails['designation']; ?>
                      
                    </p>
                  </li>
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="profile.php" class="btn btn-default btn-flat">Profile</a>
                    </div>
                    <div class="pull-right">
                      <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
			<li>
			<button class="btn btn-danger" style='margin-top:12px;margin-right:5px;<?php echo $showvisibility; ?>' onclick="logoutUserFromDialer(<?php echo $_SESSION['DIALER_CAMPAIGNID'] ?>)">Logout</button>
			</li>
			    <li>
           <!-- <a href="#" data-toggle="control-sidebar" data-open="controller"><i class="fa fa-gears"></i></a>-->
          </li>
            </ul>
			
			
          </div>
		  
		   
		<div class="navbar-custom-menu">
		
		<button type="button" class="btn btn-warning" style='margin-top:12px;margin-right:5px;<?php echo $visibility; ?>' data-toggle="modal" data-target="#abc" title='Manual Dialer'><span class="ion ion-ios-telephone"></span> Manual Dialer</button>
		
		</div>
		<div class="navbar-custom-menu" id='' onclick=''></div>
		 <button type="button" class="btn btn-success" style='margin-top:12px;<?php echo $visibility; ?>' data-toggle="modal" onclick="checkUserCampaignStatus();" title='Auto Dialer'><span class="ion ion-ios-telephone"></span> Auto Dialer</button>
		  <div class="navbar-custom-menu" id='loginhistory' style='<?php echo $visibility; ?>' onclick='removeInterval()'></div>
        </nav>
		
		
		
		<link rel="stylesheet" type="text/css" href="toastr/toastr.css">
		<script type="text/javascript" src="toastr/toastr.min.js"></script>
      </header>
	     <script>
		 
		 
		 
	$.ajax({url: "getUnreadSMS.php", success: function(result){ document.getElementById("loginhistory").innerHTML = result; }}); 
	function getlogindetails() { $.ajax({url: "getUnreadSMS.php", success: function(result){ document.getElementById("loginhistory").innerHTML = result; }}); }
	var interval = setInterval( getlogindetails , 5000)

function removeInterval()
{
	clearInterval(interval);
}



$(window).focus(function(e) {
	initConnectServer();
});



function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}


window.setInterval(function(){
$.ajax({url: "update_profile.php?action=updatelogin", success: function(result){}});
}, 4000);
</script>
<?php
if(!$_SESSION['ActualIP'])
{
	$asteriskInfo = getAsteriskById($_SESSION['asteriskip']);
	$AsteriskIP =$asteriskInfo['data'][0]['ip'];
	$_SESSION['ActualIP'] = $AsteriskIP ;
}
	  if($_SESSION['user_extension'])
	  {
	  ?>
		<script>
		var user_extension = <?php echo json_encode($_SESSION['user_extension']) ?>;
		var asteriskip = <?php echo json_encode($_SESSION['ActualIP']) ?>;
		var admin_channel = <?php echo json_encode($_SESSION['user_channel']) ?>;
		
		
		var path = window.location.pathname;
		var page = path.split("/").pop();
		var admin_value = "n";
		
		// Start For Originate Call Dialer //
		var user_context = <?php echo json_encode($profileDetails['context']); ?>;
		var user_channel = <?php echo json_encode($profileDetails['channel']); ?>;
		var user_prefix = <?php echo json_encode($profileDetails['prefix']); ?>;
		// End For Originate Call Dialer //
		
		</script>
			<script type="text/javascript" src="dist/js/jWebSocket.js"></script>
			<script type="text/javascript" src="dist/js/techextension.js"></script>
		
	  <?php 
	  }else
	  {
	  ?>
	  <script>
	  toastr["warning"]("Important : Please Enter your Extension in Profile First")
	  </script>

	  <?php  } ?>



<div class="modal fade" id="send_sms" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
   
      <div class="modal-body">
	  
	   <div class="form-group">
            <label for="recipient-name" class="col-form-label" id="phone_tosend"></label>
        </div>
	  
        <form>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Enter SMS:</label>
			<textarea class="form-control" id="sms" rows="5" cols="50" autofocus></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
		<button type="button" class="btn btn-primary" onclick='sendSMS()'>Send SMS</button>
		<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<script>
function checkUserCampaignStatus(){
	 $("#loaderForDialerFirstClick").show();
	$.ajax({url: "getUpdatedCallInformation.php?autodialer=login&user_id="+user_id, success: function(result){
		var data = JSON.parse(result);
		console.log(data.status);
	 if(data.status == "0"){
		 $.ajax({url: "getUpdatedCallInformation.php?getUserActiveDialerCampaign=yes&user_id="+user_id, success: function(newresule){
			 //console.log(newresule);
			 $("#autodialer").modal('show');
		$("#autodialer").find('.modal-body').html(newresule);
	}});
	}else if(data.status == "1"){
		campaign_id=data.campaign_id;
		login_status=data.login_status;
		console.log(data);
		if(login_status == "0"){
			toastr["warning"]("You have Pause By Admin to login in this account.")
		}else{
		toastr["warning"]("You are already logged in Campaign")
		URLTOOEPN="dialer.php?campaign_id="+campaign_id;
		var win = window.open(URLTOOEPN, '_blank');
		win.focus();
		}
	}
	$("#loaderForDialerFirstClick").hide();
	}
	});
	// 
}

function originateCalls()
{
	var callto = $('#callto').val();
	console.log($('#callto'));
	
	if(!callto){
		var callto = $('#callto').text()
		if(!callto){
			toastr["warning"]("Please Enter Digits to make call")
		}else{
			toastr["success"]("Dialing Number : "+callto);
			console.log("call from GUI Dialer : "+callto)
			originateCall(callto,user_context,user_channel,user_extension,user_prefix);
		}
	}else{
		console.log("call from Main Dialer : "+callto)
		toastr["success"]("Dialing Number : "+callto);
		originateCall(callto,user_context,user_channel,user_extension,user_prefix);
	}
}


function originateDirectCall(callto){
	toastr["success"]("Dialing Number : "+callto);
	originateCall(callto,user_context,user_channel,user_extension,user_prefix);
}

function sendSMS(){
	
	var tosend = $('#to_send').val();
	var text = $('#sms').val();
	
	if(typeof(contact_id) != "undefined" && contact_id !== null) {  
		$('#phone_tosend').html("Send SMS To : "+tosend+" Contact Name : "+contact_name)
	}else{
		contact_id = "";
		$('#phone_tosend').html("Send SMS To : "+tosend)
	}
	
	console.log("Contact id :"+ contact_id+" user id : "+user_id+" Phone To send : "+tosend+" SMS : "+text);
	
	$.ajax({
		type: "GET",
		url: 'te-admin/send_sms.php',
		data: 'tech_mobile='+tosend+"&sms="+text+'&user_id='+user_id+'&contact_id='+contact_id,
		success: function(data){
			console.log(data);
			toastr["info"](data);
			$('#send_sms').modal('toggle');
		}
		});
}
</script>
<style>
.opacity {
filter:alpha(opacity=20); 
-moz-opacity:0.2; 
opacity: 0.2; 
}
</style>