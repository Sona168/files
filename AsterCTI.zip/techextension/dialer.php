<!DOCTYPE html>
<?php include "header_dialer.php" ?>

<?php include "left_sidebar_dialer.php" ?>
<?php include "control_sidebar.php" ?>
      <!-- =============================================== -->

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper" style="border-style:solid;">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Agent Screen
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Auto Dialer</a></li>
            <li class="active"><?php echo $campaign_name; ?></li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">

<?php if($campaign_type == "POWER"){ ?>
			
<button type="button" class="btn btn-success" id="next_call" onclick="nextCall();" style="margin-right:5px;margin-top:5px;" title='Dial Next'><span class="glyphicon glyphicon-forward"></span> NEXT CALL</button>
			 
		<?php } ?>


<button type="button" class="btn btn-danger" style="margin-right:5px;margin-top:5px;" id="hangup_button" onclick="hangupCall()" title='Disconnect Call' disabled><span class="glyphicon glyphicon-stop"></span> Hangup Call</button>



<button type="button" class="btn" style="margin-right:5px;margin-top:5px;" id="mute_button" onclick="muteCall('1')" title='Mute Call' ><span class="fa fa-microphone-slash"></span> MUTE</button>
<button type="button" style="display:none;" style="margin-right:5px;margin-top:5px;" class="btn btn-secondary" id="unmute_button" onclick="muteCall('0')" title='Unmute Call' ><span class="fa fa-microphone"></span> UNMUTE</button>

<!--
<button type="button" class="btn btn-secondary" style="margin-right:5px;margin-top:5px;" id="park_button" onclick="parkCall('1')" title='PARK Call'><span class="glyphicon glyphicon-record"></span> PARK</button>
<button type="button" style="display:none;" style="margin-right:5px;margin-top:5px;" class="btn btn-secondary" id="unpark_button" onclick="parkCall('0')" title='UnPark Call' ><span class="fa fa-microphone"></span> UNPARK</button>
-->

          <!-- Default box -->
        <div class="holds-the-iframe"><iframe id="full-screen-me" sandbox="allow-forms allow-scripts allow-same-origin allow-popups" src=""  height="" width="100%" frameborder="0" wmode="transparent"></iframe>
	</div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script>

function changeIframe(){
	if (typeof contact_id !== 'undefined') {
	 $.ajax({url: "getUpdatedCallInformation.php?findContact=yes&contact_id="+contact_id, success: function(contactInfo){
			console.log(contactInfo);
			var contactInfoObject = JSON.parse(contactInfo);
			first_name = contactInfoObject.first_name;
			last_name = contactInfoObject.last_name;
			email = contactInfoObject.email;
			phone = contactInfoObject.phone;
			address = contactInfoObject.address;
			status = contactInfoObject.status;
			urltoadd = "?first_name="+first_name+"&last_name="+last_name+"&phone="+phone+"&email="+email+"&address="+address+"&status="+status;
			window.open(webformurl+urltoadd, '_blank');
		}});
	}else{
		toastr["warning"]("No any calls going on..")
	}

}




$(window).load(function() {
			autoResizeDiv();
		});
        function autoResizeDiv()
        {
			document.getElementById('full-screen-me').height =($(document).height()-100);
        }
        window.onresize = autoResizeDiv;
</script>

<style>
.holds-the-iframe {
  ##background:url(image/loader.gif) center center no-repeat;
 }
</style>

      <?php
	  include "footer.php";
	  include "control_sidebar.php";
	  include "footer_script.php";
	  ?>
  </body>
</html>
