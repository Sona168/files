<!DOCTYPE html>

  <?php include "header.php" ?>
  <?php include "left_sidebar.php" ?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  </head>
  <?php
  if(!isset($_GET['id']))
  {
	echo "<script>location.href='view_dialer_log.php'</script>";	  
  }else{
	  $call_id = $_GET['id'];
  }
  ?>
  
	<?php
		$callDetails = getDialerCallLogID($call_id);
		$campaignInfo = getDialerCampaignFromId($callDetails['data'][0]['campaign_id']);
		$campaign_name = $campaignInfo['data'][0]['name'];
		
		if($callDetails['data'][0]['contact_id']){
		$contactInfo = getContact($callDetails['data'][0]['contact_id']);
		$contact_name = $contactInfo['data'][0]['first_name']." ".$contactInfo['data'][0]['last_name'];
		}else{
			$contact_name = "Manual Call";
		}
	?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Call Details
            <small>#<?php echo $callDetails['data'][0]['id']; ?></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Calls</a></li>
            <li class="active">Detail</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="invoice">
          <!-- title row -->
          <div class="row">
            <div class="col-xs-12">
              <h2 class="page-header">
                <i class="fa fa-globe"></i> Call to <?php echo strtoupper($callDetails['data'][0]['destination']); ?> in Campaign <?php echo $campaign_name; ?>
                <small class="pull-right">Date: <?php echo $callDetails['data'][0]['cdr_start_time']; ?></small>
              </h2>
            </div><!-- /.col -->
          </div>
    

          <!-- Table row -->
          <div class="row">
		   <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">
                
				
				<!--<thead>
                  <tr>
                    <th>Qty</th>
                    <th>Product</th>
                    <th>Serial #</th>
                    <th>Description</th>
                    <th>Subtotal</th>
                  </tr>
                </thead>
				-->
				
				
                <tbody>
                
				<tr>
					<td>Call ID</td>
					<td><?php echo $callDetails['data'][0]['id']; ?></td>
				</tr>
				
				<tr>
                    <td>Campaign Name</td>
                    <td id="<?php echo $callDetails['data'][0]['contact_id']; ?>"><?php echo $campaign_name; ?></td>
                  </tr>
                  <tr>
				
				<tr>
                    <td>Source Number</td>
                    <td><?php echo $callDetails['data'][0]['source_number']; ?></td>
                  </tr>
                  <tr>
				  
				  <tr>
                    <td>Contact Name</td>
                    <td id="<?php echo $callDetails['data'][0]['contact_id']; ?>"><?php echo $contact_name; ?></td>
                  </tr>
                  <tr>
				  
				  
                    <td>Destination Number</td>
                    <td><?php echo $callDetails['data'][0]['destination']; ?></td>
                  </tr>
			
			
			<?php 
if($callDetails['data'][0]['parent'])
{
	?>
	 <tr>
                    <td><?php echo $callDetails['data'][0]['parent']; ?></td>
                    <td onclick="openViewCRMPage('<?php echo $callDetails['data'][0]['parent_id']; ?>','<?php echo $callDetails['data'][0]['parent']; ?>')" style="cursor: pointer;"><a><?php echo $callDetails['data'][0]['parent_name']; ?></a></td>
                  </tr>
	<?php
}?>
				  
				  
                  <tr>
                    <td>Agent Disposition</td>
                    <td><?php echo $callDetails['data'][0]['agent_disposition']; ?></td>
                  </tr>
				   <tr>
                    <td>Recording Link</td>
                    <td>
					<audio id='recordingURL' src='<?php echo $callDetails['data'][0]['recording']; ?>' controls preload="auto" autobuffer></audio>
					</td>
                  </tr>
				  
				  <tr>
                    <td>Call Disposition</td>
                    <td><?php echo $callDetails['data'][0]['disposition']; ?></td>
                  </tr>
				 
				  <tr>
                    <td>Total Seconds</td>
                    <td><?php echo $callDetails['data'][0]['duration']; ?></td>
                  </tr>
				  <tr>
                    <td>Billable Seconds</td>
                    <td><?php echo $callDetails['data'][0]['billableseconds']; ?></td>
                  </tr>
				  
				  
                </tbody>
              </table>
            </div><!-- /.col -->
         </div>
 <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">

                <tbody>
				<tr>
                    <td>PBX ID</td>
                    <td><?php echo $callDetails['data'][0]['unique_id']; ?></td>
                </tr>
				
			
				 
				 <tr>
                    <td>Asterisk Caller ID</td>
                    <td><?php echo $callDetails['data'][0]['callerid']; ?></td>
                  </tr>
				   <tr>
                    <td>Channel</td>
                    <td><?php echo $callDetails['data'][0]['channel']; ?></td>
                  </tr>
				   <tr>
                    <td>AMA Flag</td>
                    <td><?php echo $callDetails['data'][0]['amaflag']; ?></td>
                  </tr>
				  
				   <tr>
                    <td>Last Data</td>
                    <td><?php echo $callDetails['data'][0]['lastdata']; ?></td>
                  </tr>
				   <tr>
					<td>Last Application</td>
					<td><?php echo $callDetails['data'][0]['lastapplication']; ?></td>
				  </tr>
				  <!--
				   <tr>
                    <td>Assigned User</td>
                    <td><?php echo $userInfo['data'][0]['name']; ?></td>
                  </tr>
				  -->
				   <tr>
                    <td>Start Date</td>
                    <td><?php echo $callDetails['data'][0]['cdr_start_time']; ?></td>
                  </tr>
				  
				  <tr>
                    <td>Answer Date</td>
                    <td><?php echo $callDetails['data'][0]['cdr_answer_time']; ?></td>
                  </tr>
				  
				   <tr>
                    <td>End Date</td>
                    <td><?php echo $callDetails['data'][0]['cdr_end_time']; ?></td>
                  </tr>
				</tbody>
				</table>
				</div>
				</div>
</div>
          <div class="row">
            <!-- accepted payments column -->
           
<!--
		   <div class="col-xs-6">
              <p class="lead">Notes:</p>
             
              <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                <?php echo $callDetails['data'][0]['note']; ?>
              </p>
			  
            </div>
-->			
			

		<!--  <div class="col-xs-6">
              <p class="lead">Amount Due 2/22/2014</p>
              <div class="table-responsive">
                <table class="table">
                  <tr>
                    <th style="width:50%">Subtotal:</th>
                    <td>$250.30</td>
                  </tr>
                  <tr>
                    <th>Tax (9.3%)</th>
                    <td>$10.34</td>
                  </tr>
                  <tr>
                    <th>Shipping:</th>
                    <td>$5.80</td>
                  </tr>
                  <tr>
                    <th>Total:</th>
                    <td>$265.24</td>
                  </tr>
                </table>
              </div>
            </div>-->
          </div>

          <!-- this row will not appear when printing -->
          
		  <!--<div class="row no-print">
            <div class="col-xs-12">
              <a href="invoice-print.html" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
              <button class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Submit Payment</button>
              <button class="btn btn-primary pull-right" style="margin-right: 5px;"><i class="fa fa-download"></i> Generate PDF</button>
            </div>
          </div>
		  -->
		  
		  
        </section><!-- /.content -->
        <div class="clearfix"></div>
      </div><!-- /.content-wrapper -->
	      <script>
	 function openViewCRMPage(id,module)
		{
			window.open('crm.php?action=view&id='+id+'&module='+module);
		}
	 </script>
     
     <?php
	
	  include "footer.php";
	  include "footer_script.php";
	  include "control_sidebar.php";
	 // include "footer_script.php";
	  ?>
  </body>
</html>
