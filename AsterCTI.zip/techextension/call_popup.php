<!DOCTYPE html>

  <?php include "header.php" ?>
  <?php include "left_sidebar.php" ?>

	<?php
		if(!isset($_GET['uid']))
		{
			$reloadvalue=0;
			$callDetails = getCallDetailsForPopup(trim($_SESSION['user_extension']));
		}else
		{
			$reloadvalue=1;
			$asteriskId = $_GET['uid'];
			//$callDetails = getCallDetailsForPopup(trim($_SESSION['user_extension']));
			$user_id = getUserInfoFromExtension($_SESSION['user_extension']);
			$user_id= $user_id['data'][0]['user_id'];
			//$asteriskId = $callDetails['asteriskID'];
			$callDetails = getCallDetailsFromUniqueAndUseId($asteriskId,$user_id);
		}
		$flag=0;
		if($callDetails['status'] =="")
		{
			//echo "No Last Call Yet";
			$flag=1;
		}
		$call_id =$callDetails['data'][0]['id'];
	?>
<script>var call_id = <?php echo json_encode($call_id); ?>;</script>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
	  
	  <input type='hidden' id="<?php echo $_SESSION['user_extension']."asteriskid"; ?>" value="<?php echo $callDetails['asteriskID']; ?>">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Call Popup
            <small>Call ID: <?php echo $callDetails['data'][0]['id']; ?></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Calls</a></li>
            <li class="active">Detail</li>
          </ol>
        </section>
<!--
        <div class="pad margin no-print">
          <div class="callout callout-info" style="margin-bottom: 0!important;">
            <h4><i class="fa fa-info"></i> Note:</h4>
            This page has been enhanced for printing. Click the print button at the bottom of the invoice to test.
          </div>
        </div>
-->
        <!-- Main content -->
		
		<style>
.flux {
font-family: neon;

font-size: 1vw;
line-height: 9vw;
text-shadow: 0 0 3vw #2356FF;
}
.flux {
animation: flux 2s linear infinite;
-moz-animation: flux 2s linear infinite;
-webkit-animation: flux 2s linear infinite;
-o-animation: flux 2s linear infinite;
}

@keyframes flux {
0%,
100% {

color: #dd4b39;
}
50% {

color: #00a65a;
}
}

</style>
		
		
	<?php 
		if($flag == 0)
		{
			$phonenumberForContact = "";
		if($callDetails['data'][0]['direction'] == 'inbound')
		{
			$phonenumberForContact = trim($callDetails['data'][0]['source_number']);
		}else
		{
			$phonenumberForContact = trim($callDetails['data'][0]['destination_number']);
		}
		if($callDetails['data'][0]['direction'] == 'inbound')
		{
			$contactInfo = getContactFromNumber($callDetails['data'][0]['source_number']);
		}else
		{
			$contactInfo = getContactFromNumber($callDetails['data'][0]['destination_number']);
		}	
	?>
	<script>
		var asterctiContactId = <?php echo json_encode($contactInfo['data'][0]['id']); ?>;
	</script>
<section class="invoice">
<div class="row" >
		 
<div class="col-xs-3">
	<strong>AsterCTI : </strong>
	<h2 class="page-header" style="border: 3px solid;">
		&nbsp;&nbsp;
		<?php
		//$contactInfo['count'] == "0"
		if(true){
		?>
			<a target="_blank"  data-toggle="tooltip" href="create_contact.php?phone=<?php echo $phonenumberForContact; ?>"><button class="btn btn-success btn-xs"  title='Create Contact In AsterCTI'>Create Contact</button></a>
		<?php $caseDetails = searchCasesContact($contactInfo['data'][0]['id']); }else{
			$caseDetails = searchCasesContact($contactInfo['data'][0]['id']);
		} ?>
		<button class="btn btn-info btn-xs" data-toggle="tooltip"  title='Create Case In AsterCTI with AsterCTI Contact Module' onclick="openAsterCTICase()">Create Case</button>
	</h2>
</div>
		 
<div class="col-xs-7">
			<strong>Configured CRM : </strong>
              <h2 class="page-header" style="border: 3px solid;">
<a href="#"><img src='image/transfer.png' style='margin-right:12px;' data-toggle='tooltip' title='Transfer Call' onclick="transferCall('<?php echo $_SESSION['user_extension']; ?>')"> </a>
<a href="#"><img src='image/minus.png' style='margin-right:12px;'  data-toggle='tooltip' title='Hangup Calls' onclick="hangupCall('<?php echo $_SESSION['user_extension']; ?>')"> </a>

<?php  if($smsFlag) {
	
	?>
<a href="#"><img src='image/send_sms.png' style='margin-right:12px;'  data-toggle="modal" data-target="#send_sms" title='Send SMS' onclick="setTosend()"> </a>
<?php } ?>
<button class="btn btn-info btn-xs" data-toggle="tooltip"  title='Create Lead' onclick="openCreateCRMPage('create','Leads')">Create Lead</button> 
<button class="btn btn-warning btn-xs" data-toggle="tooltip"  title='Create Contact' onclick="openCreateCRMPage('create','Contacts')">Create Contact</button> 
<button class="btn btn-danger btn-xs" data-toggle="tooltip"  title='Create Accounts' onclick="openCreateCRMPage('create','Accounts')">Create Accounts</button>
<button class="btn btn-success btn-xs" data-toggle="tooltip"  title='Create Tasks' onclick="openCreateCRMPage('create','Tasks')">Create Tasks</button>
<button class="btn btn-primary btn-xs" data-toggle="tooltip"  title='Create Cases' onclick="openCreateCRMPage('create','Cases')">Create Cases</button>
              </h2>
	</div>


</div>
		
		
 
		
		
          <!-- title row -->
          <div class="row">
            <div class="col-xs-12">
              <h2 class="page-header">
                <i class="fa fa-globe"></i> <?php echo strtoupper($callDetails['data'][0]['subject']);
				
				//if($contactInfo['count'] > 0){echo " Contact Name : ";?> <!--<a target="_new" href="update_contact.php?action=View&id=<?php echo $contactInfo['data'][0]['id']; ?>"><?php echo $contactInfo['data'][0]['first_name']." ".$contactInfo['data'][0]['last_name']; ?></a> --><?php //} ?> 
                <small class="pull-right">Start Date: <?php echo $callDetails['data'][0]['date_start']; ?></small>
              </h2>
            </div><!-- /.col -->
          </div>
          
		  
		 
		  

          <!-- Table row -->
          <div class="row">
		   <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped" style="font-size:13px">
                
				<?php
				if($callDetails['data'][0]['direction'] == 'inbound')
				{
					//$contactInfo = getContactFromNumber($callDetails['data'][0]['source_number']);
				?>
				<input type='hidden' value='<?php echo $callDetails['data'][0]['source_number']; ?>' id='to_send' name='to_send'>
				<?php
				}else
				{
					//$contactInfo = getContactFromNumber($callDetails['data'][0]['destination_number']);
				?>
				<input type='hidden' value='<?php echo $callDetails['data'][0]['destination_number']; ?>' id='to_send' name='to_send'>
				<?php
				}
				?>
				
				
                <tbody>
                
				 <tr>
                    <td><strong>AsterCTI Contact</strong></td>
                    <td><a target="_new" href="contact_details.php?action=View&id=<?php echo $contactInfo['data'][0]['id']; ?>"><?php echo $contactInfo['data'][0]['first_name']." ".$contactInfo['data'][0]['last_name']; ?></a></td>
                  </tr>
				
				<tr>
					<td>PBX ID</td>
					<td><?php echo $callDetails['data'][0]['unique_id']; ?></td>
				</tr>
				<tr>
                    <td>Source Number</td>
                    <td><?php echo $callDetails['data'][0]['source_number']; ?></td>
                  </tr>
                  <tr>
                    <td>Destination Number</td>
                    <td><?php echo $callDetails['data'][0]['destination_number']; ?></td>
                  </tr>
				  
				   <?php
				  $userInfo = getUserInfoFromId($callDetails['data'][0]['user_id']);
				 // echo $userInfo['data'][0]['crm_url'];
				 if(!$callDetails['data'][0]['parent'])
				 {}else{
					?>
					<tr>
                    <td id="module_name"><?php echo $callDetails['data'][0]['parent']; ?></td>
                   <td style='cursor: pointer;' id="name" onclick="openViewCRMPage('<?php echo $callDetails['data'][0]['parent_id']; ?>','<?php echo $callDetails['data'][0]['parent']; ?>')"><?php echo $callDetails['data'][0]['parent_name']; ?></td>
                  </tr>
					<?php
					
				 }
				  ?>
				   
				     <tr>
                    <td>Call Duration (Seconds)</td>
					
                    <td id='call_second'><?php echo $callDetails['data'][0]['call_second']; ?></td>
                  </tr>
				   
				   <tr>
                    <td>End Date</td>
                    <td id='date_end'><?php echo $callDetails['data'][0]['date_end']; ?></td>
                  </tr>
				   
				  <tr>
                    <td>Notes</td>
                    <td> <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                <textarea class="form-control" name='note' id='note' ><?php echo $callDetails['data'][0]['note']; ?></textarea>
              </p>
			  <button class="btn btn-info btn-xs" onclick="savenote(<?php echo $asteriskId; ?>)";>Save</button></td>
                  </tr>

                 
                </tbody>
              </table>
            </div>
			</div>
			
			 <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped" style="font-size:13px">

				<tbody>
				 <tr>
                    <td>Status</td>
                    <td class='flux' style='color:green' id='status'><?php echo $callDetails['status']; ?></td>
                  </tr>
				  <tr>
                    <td>Direction</td>
                    <td><?php echo $callDetails['data'][0]['direction']; ?></td>
                  </tr>
			
				   <tr>
                    <td>Recording Link</td>
                      <td id='recording'>
					
					<!--<a href="<?php echo $callDetails['data'][0]['recording']; ?>" target="new"><?php echo $callDetails['data'][0]['recording']; ?></a>-->
					
					
					
					<?php
					if(!$callDetails['data'][0]['recording'])
					{
					?>
					<span id='aduiofile'>
					<div class="col-md-6">
						
							<div class="overlay">
								<i class="fa fa-refresh fa-spin"></i>
							</div>
						
					</div>
					</span>
					<?php
					}else
					{
					?>
					<span id='aduiofile'>
					<audio id='recordingURL' src='<?php echo $callDetails['data'][0]['recording']; ?>' controls preload="auto" autobuffer></audio>
					</span>
					<?php } ?>
					</td>
                  </tr>
			
				  
				 
				  
				  <!-- <tr>
                    <td>Assigned User</td>
                   <td><?php echo $userInfo['data'][0]['name']; ?></td>
                  </tr>
				  -->
				  
				   
				</tbody>
			</table>
			  <div class="card">
              <div class="card-header">
                <strong class="card-title"><font color="green">Support Cases </font>(Latest 5, Status : Open on Priority)</strong>
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
			  <?php 
			   if($caseDetails['count'] > 0){
			  ?>
			  
                <table class="table table-sm">
                  <thead>
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>Subject</th>
                      <th style="width: 80px">Status</th>
                      <th style="width: 60px">Priority</th>
                    </tr>
                  </thead>
                  <tbody>
				  <?php
				 
				  $j=0;
				  for($i=0;$i<$caseDetails['count'];$i++){
				  $j++;
				  ?>
                    <tr>
                      <td><?php echo $j; ?>.</td>
                      <td><a target="_new" href="ticket_details.php?action=View&id=<?php echo $caseDetails['data'][$i]['ticket_no']; ?>"><?php echo shortText($caseDetails['data'][$i]['title']); ?></a></td>
                     <td><?php echo $caseDetails['data'][$i]['status']; ?></td>
                      <td><?php echo $caseDetails['data'][$i]['priority']; ?></td>
                    </tr>
                   <?php }}else{ ?>
						 
							No Associated Cases
						
				   <?php } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
			
			
			
			 </div>
			</div>
			
			
			<!-- /.col -->
          </div><!-- /.row -->

          <script>
			
	function setTosend(){
		number = $('#to_send').val();
		$('#phone_tosend').html("Send SMS To : "+number)
		
	}
	function openAsterCTICase(){
		console.log(asterctiContactId);
		window.open('create_ticket.php?record='+asterctiContactId, '_blank'); 
	}
			
		function openCreateCRMPage(action,moduleName)
		{
			phoneNumber = document.getElementById('to_send').value.trim();
			window.open('crm.php?action='+action+"&module="+moduleName+"&number="+phoneNumber);
		}
		function openViewCRMPage(id,module)
		{
			window.open('crm.php?action=view&id='+id+'&module='+module);
		}
		
		
		var asterisk_id = <?php echo json_encode($asteriskId); ?>;
		
		function savenote(asteriskid){
			var comment = $.trim($("#note").val());
			$.ajax({url: "saveNote.php?asteriskid="+call_id+"&note="+comment, success: function(result){
				toastr["success"]("Success : Note Successfully Saved")
				delete_cookie('note');
			}});
		}
		 var refreshTokenId = setInterval(function(){updateInfo(asterisk_id)}, 2000);
		 function updateInfo(asterisk_id)
		 {
			$.ajax({url: "getUpdatedCallInformation.php?asterisk_id="+asterisk_id, success: function(result){
			var obj = JSON.parse(result);
			$("#module_name").html(obj.module_name);
			$("#name").html(obj.parent_name);
			$("#status").html(obj.status);
			//$("#recording").html(obj.recording);
			//$("#date_answer").html(obj.answertime);
			console.log(obj);
			$("#date_answer").html(obj.answertime);
			$("#call_second").html(obj.call_second);
			$("#date_end").html(obj.date_end);
			if(obj.searching == "1" && obj.status == "Disconnected")
			{
				$('#aduiofile').html("<audio id='recordingURL' src="+obj.recording+" controls preload='auto' autobuffer></audio>");
				$("#date_end").html(obj.date_end);
				
				clearInterval(refreshTokenId);
			}
			}}); 
		 }

		  </script>

          

        </section><!-- /.content -->
		
		<?php }else
		{
			?>
			<section class="invoice">
			No Last Call Yet
			</section>
			<?php
			
		}?>
        <div class="clearfix"></div>
      </div><!-- /.content-wrapper -->
     <script>
	  var note = getCookie("note");
	  //console.log(note);
	  if(note)
	  {
		$('#note').val(note);
	  }
	  </script>
     <?php
	
	  include "footer.php";
	  include "footer_script.php";
	  //include "control_sidebar.php";
	 // include "footer_script.php";
	  ?>
  </body>
</html>
