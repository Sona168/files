<!DOCTYPE html>
<?php
include_once("controller/route.php");
$configuration = getEmailConfiguration();
?>
<html>
  <head>
    <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechExtension | Forgot Password</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="stylesheet" href="dist/login/bootstrap.min.css">
	<link rel="stylesheet" href="dist/login/fontawesome-all.min.css">
	<link rel="stylesheet" href="dist/login/style.css">
	<link rel="stylesheet" href="dist/login/user_theme.css">
	<link rel="stylesheet" type="text/css" href="toastr/toastr.css">
	<link rel="icon" href="image/favicon.ico" type="image/x-icon">
  </head>
  <body>
    <div class="form-body">
        <div class="row">
            <div class="form-holder">
                <div class="form-content">
                    <div class="form-items">
                        <div class="website-logo-inside">
                            <a href="index.html">
                                <div class="logo">
                                    <img class="logo-size" src="dist/login/logo-light.svg" alt="">
                                </div>
                            </a>
                        </div>
                        <h3>Password Reset</h3>
                        <p>To reset your password, enter the email address you use to sign in to iofrm</p>
                        <form>
                           
							
							<?php
							if($configuration['status'] == '0')
							{
								?>
								 <input class="form-control" type="text" name="username" placeholder="E-mail Address" disabled>
                            <div class="form-button full-width">
                                <button id="submit" type="submit" class="ibtn btn-forget" disabled>Send Password</button>
                            </div>
								<?php
								
							}else
							{
								?>
								  <input class="form-control" type="text" name="username" id='email' placeholder="E-mail Address" required>
                            <div class="form-button full-width">
                                <button id="submit" type="submit" class="ibtn btn-forget" onclick="sendForgotRequest();">Send Password</button>
                            </div>
								<?php
							}
							?>
							
                        </form>
                    </div>
                    <div class="form-sent">
                        <div class="website-logo-inside">
                            <a href="index.html">
                                <div class="logo">
                                    <img class="logo-size" src="images/logo-light.svg" alt="">
                                </div>
                            </a>
                        </div>
                        <div class="tick-holder">
                            <div class="tick-icon"></div>
                        </div>
                        <h3>Password link sent</h3>
                        <p>Please check your inbox <span id='emailadd'></span></a></p>
                        <div class="info-holder">
                            <span>Unsure if that email address was correct?</span> <a href="#">Please Contact Administrator</a>.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="dist/login/popper.min.js"></script>
	<script src="dist/login/main.js"></script>
	<script type="text/javascript" src="toastr/toastr.min.js"></script>
 <script>
	  function sendForgotRequest()
	  {
		var email = document.getElementById('email').value;
		if(!email)
		{
		setTimeout(function(){
			$(".form-sent").removeClass("show-it");
			$(".form-sent").addClass("hide-it");
			$(".form-items").removeClass("hide-it");
			$(".form-items").addClass("show-it");
		}, 200);
		toastr['warning']('Pleae Enter Valid Email Address')
		}else{
		$.ajax({
		type: "GET",
		url: 'mail/send_mail_forgot_user.php?forgot_mail_for='+email,
		success: function(data){
			if(data == "1")
			{
				toastr['success']('Password Sent Successfully')
			}else if(data == "-1"){
				$(".form-sent").removeClass("show-it");
				$(".form-sent").addClass("hide-it");
				$(".form-items").removeClass("hide-it");
				$(".form-items").addClass("show-it");
				toastr['warning']('No Such Email Present For User')
			}
		}
		});
		}
	  }
	  </script>
  </body>
  </html>
 
<?php


	if($configuration['status'] == '0')
	{
		echo "<script>toastr['warning']('No Email Yet Configured. Please Contact to Admin for Password')</script>";
	}

  if(isset($_POST['login']))
	{
		$email = $_POST['username'];
		$password = $_POST['password'];
		
		$dataToSend = $email."*".$password;
		$result = CheckAdminLogin($dataToSend);
		print_r($result);
		if($result['status'] >= "1")
			{
				echo "<script>$('#email_error').hide();</script>";
				$_SESSION['tech_admin_id'] = $result['data']['user_id'];
				$_SESSION['user_extension'] = $result['data']['extension'];
				$_SESSION['user_channel'] = $result['data']['channel'];
				$_SESSION['asteriskip'] = $result['data']['asterisk_ip'];
				echo "<script>location.href='index.php';</script>";
			}else if($result['status'] == "0")
			{
				echo "<script>$('#email_error').show();</script>";
			}  
		}
?>

