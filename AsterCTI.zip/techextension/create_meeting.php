<!DOCTYPE html>

  <?php include "header.php" ?>
  <?php include "left_sidebar.php" ?>
  <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.min.css">
  <?php $contactStatusInfo = getAllContactStatus(); ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Create Meeting
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Contacts</a></li>
            <li class="active">Create Meeting</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
		<form class="form-horizontal" method='post' >
          <div class="row">
            <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
			
              <table class="table table-striped">
			
                <tbody>
				
			
				<tr>
                    <td>Subject</td>
                    <td>  <input type="text" class="form-control" id="subject" name ='subject' placeholder="Subject Of Meeting" required></td>
                </tr>
				
				<tr>
                    <td>Start Date Time</td>
                    <td>
					<div class="input-group date input-group bootstrap-timepicker">
						<div class="input-group-addon">
							<i class="fa fa-calendar"></i>
						</div>
						<input type="text" class="form-control" id="start_date" name="start_date" required>
						
						<div class="input-group-addon">
							<i class="fa fa-clock-o"></i>
						</div>
						<input id="start_time" name="start_time" type="text" class="form-control" required>
					</div>
				  </td>
                </tr>
				
				
				
				
				<tr>
                   <td>End Date Time</td>
                    <td>
					<div class="input-group date input-group bootstrap-timepicker">
						<div class="input-group-addon">
							<i class="fa fa-calendar"></i>
						</div>
						<input type="text" class="form-control" id="end_date" name="end_date" required>
						
						<div class="input-group-addon">
							<i class="fa fa-clock-o"></i>
						</div>
						<input id="end_time" name="end_time" type="text" class="form-control" required>
					</div>
				  </td>
                </tr>

				
				
				
				<tr>
                    <td>Description</td>
                    <td> <textarea  id="description" name="description" class="md-textarea form-control" placeholder="Description (Optional)" rows="3"></textarea></td>
                </tr>
				
			
				</tbody>
				</table>
				</div>
				</div>
			
			<div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">
<?php
	$allMeetingStatus = getAllMeetingStatus();
?>
      <tbody>
				<tr>
                    <td>Status</td>
                    <td>
						<select class="form-control select2" id="status" name="status" required>
						<option selected="selected" value="">Select Status</option>
						<?php
						for($i=0;$i<$allMeetingStatus['count'];$i++){
						?>
						<option value="<?php echo $allMeetingStatus['data'][$i]['status']; ?>" ><?php echo $allMeetingStatus['data'][$i]['status']; ?></option>
						<?php } ?>
						</select>
					</td>
                </tr>
			
				<tr>
                    <td>Contact Name</td>
                   
						<?php
						if(isset($_GET['contact_id'])){
							$contactDetails = getContact($_GET['contact_id']);
						?>
						  <td>
						 <input type="hidden" id="" name ='contact_id' value="<?php echo $contactDetails['data'][0]['id']; ?>">
						 <input type="text" class="form-control" id="contact_name" name ='contact_name' value="<?php echo $contactDetails['data'][0]['first_name']." ".$contactDetails['data'][0]['last_name']; ?>" disabled>
						  </td>
						<?php }else { ?>
						 <td>
					<select class="form-control select2" id="contact_id" name="contact_id" onchange="setTextField(this)" required>
						<?php if(isset($http_contact_id)){ ?>
						<option selected="selected" value="<?php echo $http_contact_id; ?>"><?php echo $name; ?></option>
						<?php }else{ ?>
						<option selected="selected" value="">Select Contact</option>
						<?php } ?>
					</select>
						<input id="contact_name" type = "hidden" name = "contact_name" value = "" />
						<script type="text/javascript">
							function setTextField(ddl) {
							document.getElementById('contact_name').value = ddl.options[ddl.selectedIndex].text;
							}
						</script>
					</td>
					
						<?php } ?>
					
                </tr>
				
				
				
				
			
				
				</tbody>
				
				</table>
				 
				
				</div>
			
				</div>
				
			
          </div><!-- /.row -->
		  
		  <div class="box-footer">
                    <button type="submit" name='submit' class="btn btn-primary center-block">Create Meeting</button>
                  </div>
				  
				  </form>
        </section>
      </div><!-- /.content-wrapper -->

	  
	  
	  <?php
		if(isset($_POST['submit']))
		{
			$subject = $_POST['subject'];
			$start_date = $_POST['start_date'];
			$start_time = $_POST['start_time'];
			$end_date = $_POST['end_date'];
			$end_time = $_POST['end_time'];
			$description = $_POST['description'];
			$status = $_POST['status'];
			$contact_id = $_POST['contact_id'];
			$contact_name = $_POST['contact_name'];
			//$user_id = $_POST['user_id'];
			
				$res = sheduleMeeting($_SESSION['tech_user_id'],$subject,$start_date,$start_time,$end_date,$end_time,$description,$status,$contact_id,$_SESSION['tech_user_id'],$contact_name);
				if($res['status']=="1")
				{
					$id = $res['id'];
					echo "<script>toastr['success']('Meeting Created Successfully')
					setTimeout(function(){ location.href='meeting_info.php?action=View&id=$id'; }, 1500);					
					</script>";
					
				}
				else if($res['status']=="0")
				{
					echo "<script>toastr['error']('Contact with Primary Phone Number Already Exist. Contact not created')</script>";
				}else{
					echo "<script>toastr['warning']('Something Went Wrong')</script>";
				}
			
		}
		
	  ?>
     <?php
	
	  include "footer.php";
	  include "footer_script.php";
	  ?>
	  
		<style>
		.select2 {
			width: 300px !important;
		}
		</style>
	  
	  <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
	  <script src="plugins/timepicker/bootstrap-timepicker.min.js"></script>
	  
	  
    <script>
	 $(".select2").select2();
	

	 
	  $("#contact_id").select2({
				language: {
				noResults: function() {
				return 'No Contact Found';
				},
				},
				escapeMarkup: function(markup) {
				return markup;
				},
                ajax: {
                    url: "te-admin/getContactSelect.php",
                    type: "post",
                    dataType: 'json',
                    delay: 0,
                    data: function (params) {
						var query = {
							q: params.term,
							agent_id: user_id,
							searchAgentsContact: 'yes'
						}
						return query;
                    },
                    processResults: function (response) {
                        return {
                            results: response
                        };
                    },
                    cache: true
                }
            });
	  $('#start_date').datepicker({
      autoclose: true,
	   format: 'dd-mm-yyyy'
    })
	 $('#end_date').datepicker({
      autoclose: true,
	   format: 'dd-mm-yyyy'
    })
	
	
	 $('#start_time').timepicker({
			timeFormat: 'HH:mm:ss',
			interval: 5,
			showMeridian: false,
			showInputs: false
	});
	$('#end_time').timepicker({
			timeFormat: 'HH:mm:ss',
			interval: 5,
			showMeridian: false,
			showInputs: false
	});

	
    </script>
  </body>
</html>
