<!DOCTYPE html>
  <?php include "header.php" ?>
  	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo $company_name; ?> | Create Ticket</title>
		<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	</head>
  <?php include "left_sidebar.php";
  ?>
      <div class="content-wrapper">
<?php if($phonePresent == false){
	?>
	<div class="callout callout-danger">
        <h4>Impotant!</h4>
        Please Update your <strong>Phone Number</strong> In Profile <br>
		Please <a href="profile.php">Click Here</a> to Go to Profile
      </div>
	<?php
	}else if($companyPresent == false){
	?>
	<div class="callout callout-danger">
        <h4>Impotant!</h4>
        Please Update your <strong>Company Name</strong> In Profile <br>
		Please <a href="profile.php">Click Here</a> to Go to Profile
      </div>
	<?php
	}
	?>
	  
	  <?php  
	//$getemailconf=getEmailConfiguration('1');
	if($getemailconf['count'] == "0"){
  ?>
	  <div class="callout callout-warning">
        <h4>Reminder!</h4>
        Email updates will not sent to Agents as Admin have not configured SMTP setting.
        <br>Please Ask Admin to Configure SMTP
      </div>
	  <?php }else if($getemailconf['data']['result'] != "1" ){ ?>
	  <div class="callout callout-warning">
        <h4>Alert!</h4> 
        Admin have wrongly Configuration Email Settings, Email Notification will not work
      </div>
	  <?php } ?>
	  <script>
	  var isEmailConfiguration = <?php echo json_encode($getemailconf['count']) ?>;
	  var isEmailTested = <?php echo json_encode($getemailconf['data']['result']) ?>;
	  </script>
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Create Ticket
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Support</a></li>
            <li class="active">Create Ticket</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
		<form class="form-horizontal" id="ticket_form" method='post' >
          <div class="row">
            <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">
                <tbody>
				<tr>
                    <td>Title</td>
                    <td>  <input type="text" class="form-control" id="title" name ='title' placeholder="Title" required></td>
                </tr>
				<tr>
                    <td>Ticket Description</td>
                    <td> <textarea  id="description" name="description" class="md-textarea form-control" placeholder="Description" rows="3" required></textarea></td>
                </tr>
				<!--<tr>
                    <td>Ticket Resolution</td>
                    <td> <textarea  id="solution" name="solution" class="md-textarea form-control" placeholder="Resolution" rows="3" required></textarea></td>
                </tr>-->
				</tbody>
				</table>
				</div>
				</div>
<div class="col-md-6">
	<div class="col-xs-12 table-responsive">
		<table class="table table-striped">
<?php
$ticketStatus = getTicketStatus();
?>
                <tbody>
				<tr>
                    <td>Status</td>
                    <td>
						<select class="form-control select2" id="status" name="status" required>
						<option selected="selected" value="">Select Status</option>
						<?php
						for($i=0;$i<$ticketStatus['count'];$i++){
						?>
						<option value="<?php echo $ticketStatus['data'][$i]['status']; ?>" ><?php echo $ticketStatus['data'][$i]['status']; ?></option>
						<?php } ?>
						</select>
					</td>
                </tr>
				<tr>
                    <td>Priority</td>
                    <td>
						<select class="form-control select2" id="priority" name="priority" required>
						<option selected="selected" value="">Select Priority</option>
						<?php
						for($i=0;$i<count($ticketPriority);$i++){
						?>
						<option value="<?php echo $ticketPriority[$i]; ?>" ><?php echo $ticketPriority[$i]; ?></option>
						<?php } ?>
						</select>
					</td>
                </tr>
			
				</tbody>
			</table>
		</div>
	</div>
          </div><!-- /.row -->
		  <div class="box-footer">
                    <button type="submit" id="create_ticket" name='submit' class="btn btn-primary center-block">Create Ticket</button>
                  </div>
				  </form>
        </section>
      </div>
	  <?php
		if(isset($_POST['submit']))
		{
		echo "<script> $('#create_ticket').prop('disabled', true);</script>";
			$title = $_POST['title'];
			//$solution = $_POST['solution'];
			$solution = "";
			$description = $_POST['description'];
			$status = $_POST['status'];
			$priority = $_POST['priority'];
			
			$type="customer";
			//echo $subject." ".$start_date." ".$start_time." ".$end_date." ".$end_time." ".$description." ".$status." ".$customer_id." ".$user_id;
				$res = createTicket($customer_id,$title,$solution,$priority,$description,$status,$customer_id,'1',$type);
				if($res['status']=="1")
				{
					$ticket_id = $res['ticket_id'];
					$urltocall = "ticket_id=".$ticket_id."&type=customer&user_id=".$customer_id."&ticket=yes";
					echo "<script>
						toastr['success']('Ticket Created Successfully');
						if(isEmailConfiguration ==1 && isEmailTested ==1){
						console.log(mailURL+'/ticket_email_management.php?$urltocall');
						$.ajax({url: mailURL+'/ticket_email_management.php?$urltocall', success: function(result){
						console.log(result);
						toastr['success']('Ticket Mail Sent');	
						}});
						}else{
							toastr['warning']('Email not Configured Properly, Email Will Not Sent');	
						}
					</script>";
						echo "<script> $('#create_ticket').prop('disabled', false);</script>";
				}
				else if($res['status']=="0")
				{
					echo "<script>toastr['error']('Contact with Primary Phone Number Already Exist. Contact not created')</script>";
				}else{
					echo "<script>toastr['warning']('Something Went Wrong')</script>";
				}
		}
	  include "../te-admin/footer.php";
	  include "../te-admin/footer_script.php";
	  ?>
		<style>
		.select2 {
			width: 300px !important;
		}
		</style>
    <script>
	 $(".select2").select2();
    </script>
  </body>
</html>