<?php
include_once("../controller/route.php");
if(!isset($_SESSION['customer_id']))
{
	echo "<script>location.href='login.php'</script>";
}
$url=basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);

$customer_id= $_SESSION['customer_id'];
$responseData = getContact($customer_id);
$profileDetails = $responseData['data'][0];
$company_name = getCompanyName();
$three_company_name = substr($company_name, 0, 3);
$ticketPriority=array("Low","Normal","High","Urgent");
$phonePresent = true;
$companyPresent = true;

if(!$profileDetails['phone']){
	$phonePresent = false;
}
if(!$profileDetails['company']){
	$companyPresent = false;
}


if($url == "create_ticket.php" || $url == "ticket_details.php")
{
	$getemailconf=getEmailConfiguration('1');
	if(isset($getemailconf['data']['mail_type']))
	{
		if($getemailconf['data']['mail_type'] == "PHPMailer")
		{
			$mailURL = "../mail";
		}else{
			$mailURL = "../mail/PEARMAIL";
		}
		?>
		<script>
			var mailURL = <?php echo json_encode($mailURL); ?>;
		</script>
	   <?php
	}
}


?>
	  <script>
	  // var user_extension = <?php echo json_encode($_SESSION['user_extension']) ?>;
	   </script>
	
<html>
<?php include "../te-admin/header_css.php"; ?>
<script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
  <body class="hold-transition skin-green sidebar-mini">
    <div class="wrapper">
	 
      <header class="main-header">
        <!-- Logo -->
        <a href="index.php" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b><?php echo $three_company_name; ?></b></span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b><?php echo $company_name; ?></b></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
		 
	 
          <div class="navbar-custom-menu" >
            <ul class="nav navbar-nav">
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="../image/avtar.png" class="user-image" alt="User Image">
                  <span class="hidden-xs"><?php echo $profileDetails['first_name']." ".$profileDetails['last_name']; ?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="../image/avtar.png" class="img-circle" alt="User Image">
                    <p>
                      <strong><?php echo $profileDetails['first_name']; ?> <?php echo $profileDetails['last_name']; ?></strong>
                      <!--<small>Member since Nov. 2012</small>-->
                    </p>
                  </li>
                  <!-- Menu Body -->
                 
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="profile.php" class="btn btn-default btn-flat">Profile</a>
                    </div>
                    <div class="pull-right">
                      <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
              <!-- Control Sidebar Toggle Button -->
           <!--
		   <li>
                <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
           </li>
			-->  
			  
            </ul>
          </div>
			
        </nav>

<link rel="stylesheet" type="text/css" href="../dist/css/csshack.css">
		<script type="text/javascript" src="../toastr/toastr.min.js"></script>
		<link rel="stylesheet" type="text/css" href="../toastr/toastr.css">
		
      </header>
<style>
.opacity {
filter:alpha(opacity=20); 
-moz-opacity:0.2; 
opacity: 0.2; 
}
</style>
