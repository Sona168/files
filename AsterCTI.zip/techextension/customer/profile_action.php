<?php
include "../controller/route.php";
if(isset($_GET['action'])){
$action = trim($_GET['action']);
	if($action == "basic")
	{
		$company_name = $_GET['company_name'];
		$phone = $_GET['phone'];
		$status = updateCustomerProfile($_SESSION['customer_id'],$company_name,$phone,$password);
		//print_r($status);
		if($status['status'] = 1)
		{
			echo "success";
		}else
		{
			echo "failed";
		}
	}
	if($action == "password")
	{
		$new_password = $_GET['new_password'];
		$status = updateCustomerProfile($_SESSION['customer_id'],'','',$new_password);
		if($status['status'] = 1)
		{
			echo "success";
		}else
		{
			echo "failed";
		}
	}
}
?>