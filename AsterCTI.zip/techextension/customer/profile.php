<!DOCTYPE html>
  <?php 
  include "header.php";
  include "left_sidebar.php"; ?>
<link rel="stylesheet" href="../plugins/iCheck/all.css">
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
	  
<?php if($phonePresent == false){
	?>
	<div class="callout callout-danger">
        <h4>Impotant!</h4>
        Please Update your <strong>Phone Number</strong> In Profile <br>
		Please <a href="profile.php">Click Here</a> to Go to Profile
      </div>
	<?php
	}else if($companyPresent == false){
	?>
	<div class="callout callout-danger">
        <h4>Impotant!</h4>
        Please Update your <strong>Company Name</strong> In Profile <br>
		Please <a href="profile.php">Click Here</a> to Go to Profile
      </div>
	<?php
	}
	?>
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            User Profile
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active">User profile</li>
          </ol>
        </section>
		
		
			
		
        <!-- Main content -->
        <section class="content">

          <div class="row">
            <div class="col-md-3">

              <!-- Profile Image -->
              <div class="box box-primary">
                <div class="box-body box-profile">
                
				  
	
			<div id="btnfile" style='cursor: pointer'><img class="profile-user-img img-responsive img-circle" src="../image/avtar.png" alt="User profile picture" /></div>
		
				  
				  
				  
                  <h3 class="profile-username text-center"><span id="p_name"><?php echo $profileDetails['name']; ?></span></h3>
                  <p class="text-muted text-center" id="p_designation"><?php echo $profileDetails['designation']; ?></p>

                  <ul class="list-group list-group-unbordered">
				   <li class="list-group-item">
                      <b>Name</b> <a class="pull-right" id="p_email"><?php echo $profileDetails['first_name']." ".$profileDetails['last_name']; ?></a>
                    </li>
                    <li class="list-group-item">
                      <b>Email</b> <a class="pull-right" id="p_email"><?php echo $profileDetails['email']; ?></a>
                    </li>
                    <li class="list-group-item">
                      <b>Phone Number</b> <a class="pull-right" id="p_phone"><?php echo $profileDetails['phone']; ?></a>
                    </li>
					  <li class="list-group-item">
                      <b>Company Name</b> <a class="pull-right" id="p_company"><?php echo $profileDetails['company']; ?></a>
                    </li>
                  </ul>

                  <!-- <a href="#" class="btn btn-primary btn-block"><b>Follow</b></a> -->
                </div><!-- /.box-body -->
              </div><!-- /.box -->

			  
			  
           
            </div>
		   
		    <div class="col-md-9">
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  
                  <li class='active'><a href="#settings" data-toggle="tab">Profile and Password</a></li>
				 
                </ul>
                <div class="tab-content">
                
                  <div class="active tab-pane" id="settings">
                    <form class="form-horizontal" method="POST" action="profile.php">
                    
                      <div class="form-group">
                        <label for="company_name" class="col-sm-2 control-label">Company Name</label>
                        <div class="col-sm-5">
                          <input type="text" class="form-control" id="company_name" value="<?php echo $profileDetails['company']; ?>" placeholder="Company Name" required>
                        </div>
                      </div>
					  
					  
					  <div class="form-group">
                        <label for="phone" class="col-sm-2 control-label">Phone Number</label>
                        <div class="col-sm-5">
                          <input type="text" class="form-control" id="phone" value="<?php echo $profileDetails['phone']; ?>" placeholder="Phone Number" required>
                        </div>
                      </div>
					  
					    
					<div class="form-group">
						<label  class="col-sm-2 control-label" >  </label>
						<div class="col-sm-5" id="error_message" style="display:none;color:red;font-size:14px;"> *Please Fill All Details </div>
					</div>
					  
                      <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-5">
                          <input type="button" id="basic" class="btn btn-info" value="Update Info">
                        </div>
                      </div>
                    </form>
					
					<br><br><br>
			<div class="tab-pane" id="password">
                   <form class="form-horizontal">
                      <div class="form-group">
                        <label for="new_password" class="col-sm-2 control-label">New Password</label>
                        <div class="col-sm-5">
                          <input type="password" class="form-control" id="new_password" placeholder="Enter New Password" required>
                        </div>
                      </div>
                      
					  
					  <div class="form-group">
						<label  class="col-sm-2 control-label" >  </label>
						<div class="col-sm-5" id="error_message_pass" style="display:none;color:red;font-size:14px;"> *Please Fill All Details </div>
					</div>
					  
                      <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-5">
                          <input type="button" id="password_btn" class="btn btn-danger" value="Change Password">
                        </div>
                      </div>
                    </form>
					</div>
                  </div><!-- /.tab-pane -->
                </div><!-- /.tab-content -->
              </div><!-- /.nav-tabs-custom -->
            </div>
          </div><!-- /.row -->

        </section><!-- /.content -->
      </div>
	<?php
	  include "../te-admin/footer.php";
	  //include "../te-admin/printDataTableJS.php";
	  include "../te-admin/footer_script.php";
	  ?>
	  <script>
	  
	  $("#basic").click(function(){
				var company_name = $('#company_name').val();
				var phone = $('#phone').val();
			
				if(!company_name || !phone)
				{
				 $('#error_message').show();
					return;
				}
				$('#error_message').hide();
				var dataToSend = "company_name="+company_name+"&phone="+phone;
				 $('#p_company').html(company_name);
				 $('#p_phone').html(phone);
				 
				 	 $.ajax({url: "profile_action.php?action=basic&"+dataToSend, success: function(result){
						//console.log(result);
						if(result =='success')
						{
							toastr["success"]("Success : Profile Updated Successfully")
						}else
						{
							toastr["error"]("Failed : Profile Not Updated")
						}
					}}); 

			});
			
		$("#password_btn").click(function(){
				var new_password = $('#new_password').val();
			
				if(!new_password)
				{
				 $( "#new_password" ).focus();
				 $('#error_message_pass').show();
					return false;
				}
				$('#error_message_pass').hide();
				var dataToSend = "new_password="+new_password;
				 	 $.ajax({url: "profile_action.php?action=password&"+dataToSend, success: function(result){
						//console.log(result);
						 if(result =='success')
						{
							toastr["success"]("Success : Password Changed Successfully")
						}else
						{
							toastr["error"]("Failed : Password Not Changed Successfully")
						}
					}}); 

			});
		
	
	
		</script>
		
		
  </body>
</html>
