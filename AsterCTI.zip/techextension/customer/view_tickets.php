<!DOCTYPE html>
  <?php 
  include "header.php";
  include "left_sidebar.php";
    if(isset($_POST['search'])){
	  $datebetween = $_POST['datebetween'];
	  $status = $_POST['status'];
	  //$agent_id = $current_user;
	  $agent_id="";
	  if($datebetween){
		$datebetweenarray = explode("-",$datebetween);
		$fromDate = $datebetweenarray[0];
		$toDate = $datebetweenarray[1];
	  }else{
		  $fromDate="";
		  $toDate="";
		  $datebetween="ALL TIME";
	  }
	  $ticketDetails = searchTicket($fromDate,$toDate,$customer_id,$status,$agent_id);
  }else{
	$ticketDetails = searchTicket("","",$customer_id,"","");
  }
	if(isset($_GET['action']))
	{
		if($_GET['action'] == "update")
		{
			echo "<script>toastr['success']('Tickets Updated Successfully')</script>";
		}
		if($_GET['action'] == "Delete")
		{
		if(isset($_GET['id'])){
			$ticket_id = $_GET['id'];
			deleteTicket($ticket_id);
			echo "<script>location.href='view_tickets.php?action=remove'</script>";  
			}else{
				echo "something wrong";
			}
		}
		if($_GET['action'] == "remove")
		{
			echo "<script>toastr['success']('Ticket Deleted Successfully')</script>";
		}
	}
	$ticketStatus = getTicketStatus();
  ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
	<?php if($phonePresent == false){
	?>
	<div class="callout callout-danger">
        <h4>Impotant!</h4>
        Please Update your <strong>Phone Number</strong> In Profile <br>
		Please <a href="profile.php">Click Here</a> to Go to Profile
      </div>
	<?php
	}else if($companyPresent == false){
	?>
	<div class="callout callout-danger">
        <h4>Impotant!</h4>
        Please Update your <strong>Company Name</strong> In Profile <br>
		Please <a href="profile.php">Click Here</a> to Go to Profile
      </div>
	<?php
	}
	?>
	  
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Search Filter
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">View Tickets</li>
          </ol>
        </section>
        <section class="content">
         <div class="row">
		 <form method="POST" action="view_tickets.php">
		  <div class="col-xs-12">
			<div class="col-xs-3">
			<label>Date Between:</label>
			<div class="input-group">
			  <div class="input-group-addon">
				<i class="fa fa-calendar"></i>
			  </div>
			  <input type="text" autocomplete="off" name="datebetween" class="form-control" id="reservationtime">
			</div>
			</div>
			  
				 <div class="col-xs-3">
               <div class="form-group">
                    <label>Status</label>
                     <select class="form-control select2" id="status" name="status">
					<option selected="selected" value="">Select Status</option>
					<?php for($i=0;$i<$ticketStatus['count'];$i++){
						if($status == $ticketStatus['data'][$i]['status']){
								$selected = "selected";
							}else{
								$selected = "";
							}
						?>
					<option <?php echo $selected; ?> value="<?php echo $ticketStatus['data'][$i]['status']; ?>" ><?php echo $ticketStatus['data'][$i]['status']; ?></option>
					<?php } ?>
                    </select>
                  </div>
				</div>
				</div>
					<button type="submit" name="search" class="btn btn-primary center-block"><span class="fa fa-search"></span> Search </button>
				</form>
				</div>				
			<div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Tickets List</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
            <form id="myform" method="post">	  
            <p>
			<?php
			if($ticketDetails['count'] > 0)
			{
			?>
			
			<?php } ?>
                  <table id="mytable" class="table table-bordered table-striped table-hover">
                    <thead>
                      <tr>
                        <th></th>
						<th>Title</th>
                        <th>Status</th>
						<th>Priority</th>
						<th>Assigned Agent</th>
						<th>Date Created</th>
						<th>Action</th>
                      </tr>
                    </thead>
                    <tbody id="tableRow">
					<?php 
					if($ticketDetails['count'] >= 1)
					{
						$j=0;
						for($i=0;$i<$ticketDetails['count'];$i++)
						{
							$j++;
							
							$userInfo = getUserInfoFromId($ticketDetails['data'][$i]['assigned_to']);
							if($userInfo['count'] == "0"){
								$assigned_user="Administrator";
							}else{
								$assigned_user = $userInfo['data'][0]['name'];
							}
							if($ticketDetails['data'][$i]['status'] == "Open"){
								$color = "green";
							}else if($ticketDetails['data'][$i]['status'] == "In Progress"){
								$color = "orange";
							}else if($ticketDetails['data'][$i]['status'] == "Wait For Response"){
								$color = "blue";
							}else if($ticketDetails['data'][$i]['status'] == "Closed"){
								$color = "red";
							}
							
						?>
					  <tr>
					  <td><?php echo $ticketDetails['data'][$i]['ticket_no']; ?></td>
						<td><?php echo shortText($ticketDetails['data'][$i]['title']); ?></td>
						<td class="badge bg-<?php echo $color; ?>"><?php echo $ticketDetails['data'][$i]['status']; ?></td>
						<td><?php echo $ticketDetails['data'][$i]['priority']; ?></td>
						<td><?php echo $assigned_user; ?></td>
						<td><?php echo $ticketDetails['data'][$i]['date_created']; ?></td>
						<td class="btn-group">						
						<a href="ticket_details.php?action=View&id=<?php echo $ticketDetails['data'][$i]['ticket_no'];?>"><input type='button' class="btn btn-info btn-xs" value='View & Edit'></button></a>					
						</td>
					  </tr>
						<?php
						}
					}
					?>
                    </tfoot>
                  </table>
				   </form>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
     <?php
	  include "../te-admin/footer.php";
	  include "../te-admin/printDataTableJS.php";
	  include "../te-admin/footer_script.php";
	  ?>
     <script>
	  $(document).ready(function(){
        var mytable = $("#mytable").DataTable({
           // ajax: 'data.json',
            columnDefs: [
                {
                    targets: 0,
                    checkboxes: {
                        seletRow: true
                    }
                }
            ],
            select:{
                style: 'multi'
            },
			 "language": {
      "emptyTable": "No Tickets Available to Show"
    },
            order: [[5, 'desc']],
			/* "dom": '<"top"Blf>rt<"bottom"p><"clear">',
		buttons: [
			{
				extend: 'print',
				exportOptions: {
				columns: ':visible'
				}
			},
			{
				extend: 'pdf',
				download:'open',
				title: '',
				orientation:'landscape',
				pageSize:'LEGAL',
				exportOptions: {
				columns: ':visible'
			}
			},
			{
				extend: 'excel',
				title: '',
				exportOptions: {
				columns: ':visible'
			}
			},
			{
			extend: 'csv',
				title: '',
				exportOptions: {
				columns: ':visible'
			}
			},
			'copy',
			{
				extend: 'colvis',
				title: '',
				collectionLayout:'fixed two-column'
			}
		] */
        })
        $("#myform").on('submit', function(e){
            var form = this
            var rowsel = mytable.column(0).checkboxes.selected();
            $.each(rowsel, function(index, rowId){
                $(form).append(
                    $('<input>').attr('type','hidden').attr('name','id[]').val(rowId)
                )
            })
			
			/* if(rowsel.join(","))
			{
			$.ajax({url: "te-admin/contact.php?action=removeTicket&ticket_id="+rowsel.join(","), success: function(result){
				console.log(result);
				location.reload();
					}}); 
			}else{
				toastr['warning']('Select Tickets First To Remove');
			} */
			
         //  $("#view-rows").text(rowsel.join(","))
           // $("#view-form").text($(form).serialize())
            $('input[name="id\[\]"]', form).remove()
            e.preventDefault()
        })
    })
	  $(function () {
        $(".select2").select2();
		 
		$('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
      });
    </script>
  </body>
</html>