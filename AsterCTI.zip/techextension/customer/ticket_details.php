<!DOCTYPE html>
  <?php include "header.php" ?>
  <?php include "left_sidebar.php" ?>
  <?php
  if(isset($_GET['id'])){
	$ticket_id = $_GET['id'];
	$ticketInfo = getTicket($ticket_id);
	if($ticketInfo['data'][0]['type'] == "customer"){
		$attributes = "readonly";
	}
  }else{
  exit;
  echo "";
  }
  if(!$ticketInfo['data'][0]['ticket_no']){
  exit;
  }
  ?>
  <script>
		var contact_id = <?php echo json_encode($ticketInfo['data'][0]['contact_id']) ?>;
		var assigned_user = <?php echo json_encode($ticketInfo['data'][0]['assigned_to']) ?>;
		var ticket_id = <?php echo json_encode($ticket_id) ?>;
		</script>
  <?php $contactStatusInfo = getAllContactStatus(); ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
		
	<?php
	//$getemailconf=getEmailConfiguration('1');
	if($getemailconf['count'] == "0"){
	?>
	  <div class="callout callout-warning">
        <h4>Reminder!</h4>
        Email updates will not sent to Contacts as you have not configured your SMTP setting.
        <a href="email_configuration.php">Click to visit Email Configuration</a> Page
      </div>
	  <?php }else if($getemailconf['data']['result'] != "1" ){ ?>
	  <div class="callout callout-warning">
        <h4>Alert!</h4>
		You have to click on <b>Test Mail button </b> after Configuration of Email Settings OR 
        Your Email Configuration is wrongly Entered, Please recheck Configuration
        <a href="email_configuration.php">Click to visit Email Configuration</a> Page
      </div>
	  <?php } ?>
	  <script>
	  var isEmailConfiguration = <?php echo json_encode($getemailconf['count']) ?>;
	  var isEmailTested = <?php echo json_encode($getemailconf['data']['result']) ?>;
	  </script>
        <section class="content-header">
          <h1>
            Ticket
            <small>Number : <?php echo $ticketInfo['data'][0]['ticket_no']; ?></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Tickets</a></li>
            <li class="active">Ticket Details</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
		<form class="form-horizontal" method='post' >
          <div class="row">
            <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
			
              <table class="table table-striped">
			
                <tbody>
				
				<tr>
                    <td>Title</td>
                    <td>  <input type="text" class="form-control" id="title" name ='title' value="<?php echo $ticketInfo['data'][0]['title']; ?>" placeholder="Title" readonly required>
					<input type="hidden" class="form-control" name ='user_id' value="<?php echo $ticketInfo['data'][0]['assigned_to']; ?>">
					
					</td>
                </tr>
				
				<tr>
                    <td>Ticket Description</td>
                    <td> <textarea  id="description" name="description" class="md-textarea form-control" placeholder="Description" rows="3" readonly required><?php echo $ticketInfo['data'][0]['description']; ?></textarea></td>
                </tr>
				
				<tr>
                    <td>Ticket Resolution</td>
                    <td> <textarea  id="solution" name="solution" class="md-textarea form-control" placeholder="Resolution" rows="3" readonly required><?php echo $ticketInfo['data'][0]['solution']; ?></textarea></td>
                </tr>
				
				</tbody>
				</table>
				</div>
				</div>
			
			<div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">
<?php
$ticketStatus = getTicketStatus();
?>
                <tbody>
				<tr>
                    <td>Status</td>
                    <td>
					
					<?php
					$readonlyattribute="";
					if($ticketInfo['data'][0]['status'] == "Closed"){
						$readonlyattribute = "disabled";
					}
					?>
						<select class="form-control select2" id="status" name="status" <?php echo $readonlyattribute; ?> required>
						<option selected="selected" value="">Select Status</option>
						<?php
						for($i=0;$i<$ticketStatus['count'];$i++){
						if($ticketStatus['data'][$i]['status'] == $ticketInfo['data'][0]['status'])
							  {
								$selected="selected=selected";
							  }
							  else
							  {
								$selected="";
							  }
						?>
						<option <?php echo $selected; ?> value="<?php echo $ticketStatus['data'][$i]['status']; ?>" ><?php echo $ticketStatus['data'][$i]['status']; ?></option>
						<?php } ?>
						</select>
					</td>
                </tr>
				
				
				<tr>
                    <td>Priority</td>
                    <td>
						<select class="form-control select2" id="priority" name="priority" required>
						<option selected="selected" value="">Select Priority</option>
						<?php
						for($i=0;$i<count($ticketPriority);$i++){
						if($ticketPriority[$i] == $ticketInfo['data'][0]['priority'])
							  {
								$selected="selected=selected";
							  }
							  else
							  {
								$selected="";
							  }
						?>
						<option <?php echo $selected; ?> value="<?php echo $ticketPriority[$i]; ?>" ><?php echo $ticketPriority[$i]; ?></option>
						<?php } ?>
						</select>
					</td>
                </tr>
			<?php if($ticketInfo['data'][0]['assigned_to'] < 30){
				$agent_info = getAdminProfile($ticketInfo['data'][0]['assigned_to']);
				$agent_name = $agent_info['data']['name'];
			}else{
				$agent_info = getUserInfoFromId($ticketInfo['data'][0]['assigned_to']);
				$agent_name = $agent_info['data'][0]['name'];
			}
			?>
				<tr>
                    <td>Assigned Agent</td>
                    <td>
					<?php echo $agent_name; ?>
                </tr>
				
			
				</tbody>
			</table>
		</div>
	</div>
          </div><!-- /.row -->
		  <div class="box-footer">
                    <button type="submit" id="update_ticket" name='submit' <?php echo $readonlyattribute; ?> class="btn btn-primary center-block">Update Ticket</button>
                  </div>
				  </form>
				  
	<div class="row">
				  
				  <div class="col-md-12">
              <!-- DIRECT CHAT -->
              <div class="box box-warning direct-chat direct-chat-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Post Your Comments
				  <small>Note : Email Will be sent to Support Team once you put any comments</small>
				  </h3>

                  
                </div>
				<div class="box-footer">
                  <form action="#" method="post">
                    <div class="input-group">
                      <input type="text" id="message" placeholder="Enter Your Comment" class="form-control">
                      <span class="input-group-btn">
                            <button type="button" id="post" class="btn btn-warning btn-flat">Post</button>
                          </span>
                    </div>
                  </form>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                  <!-- Conversations are loaded here -->
				  
                  <div class="direct-chat-messages" id="comment_section">
                 
                  </div>
                 
                </div>
                <!-- /.box-body -->
                
                <!-- /.box-footer-->
              </div>
              <!--/.direct-chat -->
            </div>
				  
				  </div>
        </section>
      </div>
	  <?php
		if(isset($_POST['submit']))
		{
		echo "<script> $('#create_ticket').prop('disabled', true);</script>";
			$title = $_POST['title'];
			$solution = $_POST['solution'];
			$description = $_POST['description'];
			$status = $_POST['status'];
			$contact_id = $_POST['contact_id'];
			$priority = $_POST['priority'];
			$user_id = $_POST['user_id'];
			$type="admin";
			//echo $title." ".$solution." ".$description." ".$status." ".$contact_id." ".$priority." ".$user_id;

				$res = updateTicket($current_user,$ticket_id,$title,$solution,$priority,$description,$status,$customer_id,$user_id,$type);
				if($res['status']=="1")
				{
					$urltocall = "ticket_id=".$ticket_id."&type=customer&user_id=".$customer_id."&status=yes";
				echo "<script>
					toastr['success']('Ticket Updated Successfully');
					if(isEmailConfiguration ==1 && isEmailTested ==1){
					$.ajax({url: mailURL+'/ticket_email_management.php?$urltocall', success: function(result){
					console.log(result);
					toastr['success']('Ticket Updated Mail Notification Sent');
					}});
					}else{
						toastr['warning']('Email not Configured Properly.');	
					}
				</script>";
					echo "<script> $('#create_ticket').prop('disabled', false);</script>";
				}
				else if($res['status']=="0")
				{
					echo "<script>toastr['error']('Contact with Primary Phone Number Already Exist. Contact not created')</script>";
				}else{
					echo "<script>toastr['warning']('Something Went Wrong')</script>";
				}
			
		}
	  include "../te-admin/footer.php";
	  include "../te-admin/footer_script.php";
	  ?>
	  
		<style>
		.select2 {
			width: 300px !important;
		}
		</style>
<script>
$("#post").click(function(){
	$("#comment_section").addClass("opacity");
	message = $("#message").val();
	if(!message){
		toastr['warning']('Comment Cannot be Blank');
		return;
	}
	message = encodeURIComponent(message);
	type="customer";
	postComment(ticket_id,message,type,contact_id);
	$("#message").val('');
	if(isEmailConfiguration ==1 && isEmailTested ==1){
		urltocall = "ticket_id="+ticket_id+"&type=customer&user_id="+contact_id+"&comment=yes";
		$.ajax({url: mailURL+'/ticket_email_management.php?'+urltocall, success: function(result){
		console.log(result);
		toastr['success']('Email Sent For your Comments');
		}});
	}else{
		toastr['warning']('Email not Configured Properly.');	
	}
});

function postComment(ticket_id,message,type,type_id){
$.ajax({url: "../te-admin/ticketAction.php?action=addComment&ticket_id="+ticket_id+"&message="+message+"&type="+type+"&type_id="+type_id, success: function(result){
		$( "#comment_section" ).html(result);
		$("#comment_section").removeClass("opacity");
	}});
}
	

			
	 $(".select2").select2();

$( document ).ready(function() {
type="customer";
message="";
postComment(ticket_id,message,type,contact_id);
});


	
    </script>
  </body>
</html>
