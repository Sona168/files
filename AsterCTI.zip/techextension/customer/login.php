<!DOCTYPE html>
<?php
include_once("../controller/route.php");
//print_r($_SESSION);
if($_SESSION['customer_id'])
{
	echo "<script>location.href='index.php';</script>";
}
$admin_available=checkAnyAdminPresent();
if(!$admin_available)
{
	echo "<script>location.href='../te-admin/registration.php'</script>";
}
if(isset($_GET['ticket_id'])){
$ticket_id = $_GET['ticket_id'];
	$_SESSION['direct_ticket'] = "ticket_details.php?ticket_id=$ticket_id";
}
//session_unset();
//session_destroy();
$company_name = getCompanyName();
$three_company_name = substr($company_name, 0, 3);
$ASKPASSWORD = false;
if(isset($_GET['action'])){
	if($_GET['action'] == "checkpassword"){
		if(isset($_SESSION['customer_id_not_validate'])){
			$ASKPASSWORD = true;
		}else{
			$ASKPASSWORD = false;
		}
	}	
}
?>
<style>
#register {
    line-height: 12px;
  position: absolute;
  top: 8px;
  right: 16px;
  font-size: 18px;
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
  display: inline-block;
  padding: 15px 25px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4CAF50;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
 }
 
#register:hover {background-color: #3e8e41}
#register:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
</style>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $company_name; ?> | LOGIN TICKET MANAGEMENT</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="../dist/login/bootstrap.min.css">
    <link rel="stylesheet" href="../dist/login/fontawesome-all.min.css">
    <link rel="stylesheet" href="../dist/Ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.css">
	<link rel="stylesheet" type="text/css" href="../toastr/toastr.css">
  </head> 
 <body class="hold-transition lockscreen">
 
  <?php  
	$getemailconf=getEmailConfiguration('1');
	if($getemailconf['count'] == "0"){
  ?>
	  <div class="callout callout-danger">
        <h4>Reminder!</h4>
        Administrator of this System have not Configured Email.<br>
		If you have not set Password yet for login then you cant retrieve it on your Mail.<br>
		Please ask Administrator to Configure Email Settings first.
      </div>
	  <?php }else if($getemailconf['data']['result'] != "1" ){ ?>
	  <div class="callout callout-warning">
        <h4>Alert!</h4>
		Administrator have Configured Email Settings Wrongly.</br>
		If you have not set Password yet for login then you cant retrieve it on your Mail.<br>
		Please ask Administrator to Configure Email Settings Properly.
      </div>
	  <?php } ?>
  <?php
	if(isset($_GET['whattodo'])){ 
		$wrapper_css = "register";
	}else{
		$wrapper_css = "lockscreen";
	}
	?>
    <!-- Automatic element centering -->
    <div class="<?php echo $wrapper_css; ?>-wrapper">
	<?php
	if(isset($_GET['whattodo'])){ ?>
	<a id="register" name="register" href="login.php">Back to Login</a>
	<?php
	$label = "REGISTRATION";
	}else{
		$label = "TICKET MANAGEMENT";
	?>
	<a id="register" name="register" href="?whattodo=register">Register As Customer</a>
	<?php
	}
	?>
	<a href="login.php"><b><?php echo $company_name; ?></b></a>
      <div class="lockscreen-logo">
        <a href="login.php"><b><?php echo $label; ?></b></a>
      </div>
		<?php
if(!isset($_GET['whattodo'])){
	if($_GET['whattodo'] != "register"){
		if($ASKPASSWORD == false){ ?>
	<div class="lockscreen-name">Customer Login</div>
      <div class="lockscreen-item">
        <div class="lockscreen-image">
          <img src="../dist/img/avatar3.png">
        </div>
        <form class="lockscreen-credentials" method='POST'>
          <div class="input-group">
            <input type="email" name="email" class="form-control" placeholder="Enter Email Address" required>
            <div class="input-group-btn">
              <button name="login" class="btn"><i class="fa fa-arrow-right text-muted"></i></button>
            </div>
          </div>
        </form>
	</div>
      <div class="help-block text-center">
        Enter Your Emaill Address Associated with us to Login
      </div>
<?php }else{ ?>
 <div class="lockscreen-name">Hello, <?php echo $_SESSION['customer_name']; ?></div>
      <div class="lockscreen-item">
        <div class="lockscreen-image">
          <img src="../dist/img/avatar3.png">
        </div>
<form class="lockscreen-credentials" method='POST'>
          <div class="input-group">
            <input type="password" name="password" class="form-control" placeholder="Enter Password" required>
            <div class="input-group-btn">
              <button name="password_login" class="btn"><i class="fa fa-arrow-right text-muted"></i></button>
            </div>
          </div>
        </form>
	</div>
      <div class="text-center" id='password_message'>
	  <?php if($_SESSION['passowrd_not_set'] == false){ ?>
       Please Enter Password to Login in Account
	   <?php }else{ ?>
	   Please Check your Mail Box for Password to Login
	   <?php } ?> 
      </div><br>
	  <div class="text-center" id="forgot_message">
		 <?php if($_SESSION['passowrd_not_set'] == false){	
		 ?>
		 <script>
var customer_id = <?php echo json_encode($_SESSION['customer_id_not_validate']) ?>;
</script>
        Forgot Password? <span onclick="forgotPassword()" style="cursor:pointer;"><b>Click Here</b></span> to get In Your Mail Box Directly.
	   <?php }else{ ?>
	   If you Dont Receive Mail Please Contact Company Directly
	   <?php } ?> 
      </div>
<?php } } }else{
session_unset();
session_destroy();
 ?>
 <div class="" style="padding-bottom: 2px;"><strong>Register As Customer</strong></div>
        <form class="" method='POST'>
			<input type="text" name="first_name" class="form-control" style="margin-bottom: 5px;" placeholder="First Name" required>
			<input type="text" name="last_name" class="form-control" style="margin-bottom: 5px;" placeholder="Last Name" required>
			<input type="email" name="email" class="form-control" style="margin-bottom: 5px;" placeholder="Valid Email Address" required>
			<input type="text" name="phone" class="form-control" style="margin-bottom: 5px;" placeholder="Phone Number" required>
			<input type="text" name="company_name" class="form-control" style="margin-bottom: 5px;" placeholder="Company Name" required>
            <input type="password" name="password" class="form-control" style="margin-bottom: 5px;" placeholder="Password to Login" required>
            <button name="register" class="form-control" style="cursor: pointer;"><i class="fa fa-arrow-right text-muted">Register</i></button>
        </form>
<?php } ?>
    </div><!-- /.center -->
    <!-- jQuery 2.1.4 -->
    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../toastr/toastr.min.js"></script>
	<STYLE>
	.footer_custom { 
	   position: fixed;
	  left: 0;
	  bottom: 0;
	  width: 100%;
	  background-color: #fff;
	  color: black;
	  text-align: center;
	}
	</STYLE>
  <footer class="footer_custom">
        <div class="">
          <!-- <b>Version</b> 2.3.0 -->
        </div>
        <strong>Copyright &copy; 2016-2019 <a href="http://techextension.com" target="new">TechExtension</a>. All rights reserved.</strong>
   </footer>
   </body> 
</html>
<?php
if(isset($_POST['register'])){
	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$company_name = $_POST['company_name'];
	$password = $_POST['password'];
	$address="";$phone2="";$note="";$status="New";$prefix="";$city="";$postal_code="";$country="";
	$responce = createCustomer('1',$first_name,$last_name,$email,$phone,$address,$phone2,$note,$status,$prefix,$city,$postal_code,$country,$password,$company_name);
		if($responce['status'] == "0"){
			echo "<script>toastr['error']('Email or Phone Already associated with our system, Please check that');</script>";
		}else{
		session_start();
		$_SESSION['customer_id'] = $responce['id'];
			echo "<script>toastr['success']('Your Account is created Successfully.');</script>";
			echo "<script>
		setTimeout(function(){ location.href='index.php?msg=success'; }, 1500);
		</script>";
		}
	}
if(isset($_POST['password_login'])){
	$email = $_SESSION['customer_email'];
	$password = $_POST['password'];
	$contact_info = checkCustomerLogin($email,$password);
	if($contact_info['data']['id']){
		session_unset();
		session_destroy();
		session_start();
		$_SESSION['customer_id'] = $contact_info['data']['id'];
		//$_SESSION['customer_name'] = $contact_info['data']['first_name']." ".$contact_info['data']['last_name'];
		echo "<script>
		setTimeout(function(){ location.href='index.php?msg=success'; }, 1000);
		</script>";
	}else{
		echo "<script>toastr['error']('Please Enter Correct Password to login');</script>";
	}
}
	if(isset($_POST['login'])){
		$email  = $_POST['email'];
		if($email){
		$contact_info = getContactFromEmail($email);
		if($contact_info['count'] == '0'){
		session_unset();
		session_destroy();
			echo "<script>toastr['error']('You  Dont have account with us.');</script>";
		}else{
		if($contact_info['data'][0]['secret']){
			$_SESSION['customer_id_not_validate'] = $contact_info['data'][0]['id'];
			$_SESSION['customer_email'] = $contact_info['data'][0]['email'];
			$_SESSION['customer_name'] = $contact_info['data'][0]['first_name']." ".$contact_info['data'][0]['last_name'];
			$_SESSION['passowrd_not_set'] = false;
			echo "<script>location.href='login.php?action=checkpassword';</script>";
		}else{
			setContactPassword($contact_info['data'][0]['id'],"");
			$customer_id = $contact_info['data'][0]['id'];
			$_SESSION['customer_id_not_validate'] = $contact_info['data'][0]['id'];
			$_SESSION['customer_email'] = $contact_info['data'][0]['email'];
			$_SESSION['customer_name'] = $contact_info['data'][0]['first_name']." ".$contact_info['data'][0]['last_name'];
			$_SESSION['passowrd_not_set'] = true;
			echo "<script>
			toastr['success']('Please Wait, New Password Creating for you.');
			$.ajax({url: '../mail/customer_password_management.php?customer_id=$customer_id&action=New Password', success: function(result){
						toastr['success']('Password Sent On you Email');
						setTimeout(function(){ location.href='login.php?action=checkpassword'; }, 2100);
						}});
			</script>";
			echo "<script></script>";
		}
		}
		}else{
			toastr['error']('Enter Valid Email Please');
		}
	}
?>
<script>
function forgotPassword(){
toastr['success']('Please Wait We are sending your password on your Email');
$.ajax({url: '../mail/customer_password_management.php?customer_id='+customer_id+'&action=Forgot Password', success: function(result){
						toastr['success']('Password Sent On you Email Successfully');
						}});
}
</script>