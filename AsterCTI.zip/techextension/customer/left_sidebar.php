      <aside class="main-sidebar" style="overflow-x: hidden;">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="../image/avtar.png" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p><a href="profile.php"><?php echo $profileDetails['first_name']." ".$profileDetails['last_name']; ?></a></p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
          <!-- search form -->
        <!--

		<form action="#" method="get" class="sidebar-form">
            <div class="input-group">
              <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
          </form>
		  -->
		  
		  
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
		  
          <ul class="sidebar-menu">
        
				<li class="treeview <?php if($url=='index.php'){echo "active";}?>">
				<li <?php if($url=='index.php'){echo 'class="active"';}?>><a href="index.php"><i class="fa fa-dashboard" style="color:#fff;"></i> <span>Ticket Dashboard</span></a></li>
			</li>
			
			
			
			
			<!--
			<li class="treeview <?php if($url=='view_meeting.php' || $url=='create_meeting.php' || $url=='meeting_info.php'){echo "active";}?>">
              <a href="#">
                <i class="fa fa-exchange" style="color:#3c8dbc;"></i>
                  <span>Meeting</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li <?php if($url=='create_meeting.php'){echo 'class="active"';}?>><a href="create_meeting.php"><i class="fa fa-plus"></i>Create Meeting</a></li>
				
				<li <?php if($url=='view_meeting.php'){echo 'class="active"';}?>><a href="view_meeting.php"><i class="fa fa-eye"></i> <span>View Meeting</span></a></li>
              </ul>
            </li>
			-->
			
			<li class="treeview <?php if($url=='view_tickets.php' || $url=='create_ticket.php' || $url=='update_ticket.php' || $url=='ticket_details.php'){echo "active";}?>">
              <a href="#">
                <i class="fa fa-ticket" style="color:#dd4b39;"></i>
                  <span>Support Ticket</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li <?php if($url=='create_ticket.php'){echo 'class="active"';}?>><a href="create_ticket.php"><i class="fa fa-plus"></i>Create Ticket</a></li>
				
				<li <?php if($url=='view_tickets.php'){echo 'class="active"';}?>><a href="view_tickets.php"><i class="fa fa-eye"></i> <span>View Ticket</span></a></li>
              </ul>
            </li>
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>