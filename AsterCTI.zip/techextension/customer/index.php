<?php include "header.php" ?>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo $company_name; ?> | Ticketing Dashboard</title>
		<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	</head>
	<?php include "left_sidebar.php";
	$from="";$to="";$status="";$priority="";$type="customer";$type_id=$customer_id;
	$ticketInfo = getTicketingCounts($type,$type_id);
	?>
	<div class="content-wrapper" id="main_body">
	
	<?php if($phonePresent == false){
	?>
	<div class="callout callout-danger">
        <h4>Impotant!</h4>
        Please Update your <strong>Phone Number</strong> In Profile <br>
		Please <a href="profile.php">Click Here</a> to Go to Profile
      </div>
	<?php
	}else if($companyPresent == false){
	?>
	<div class="callout callout-danger">
        <h4>Impotant!</h4>
        Please Update your <strong>Company Name</strong> In Profile <br>
		Please <a href="profile.php">Click Here</a> to Go to Profile
      </div>
	<?php
	}
	?>
        <section class="content-header">
          <h1>
            Dashboard
            <small>Ticketing</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>
        <section class="content">
			<div class="box-body">
          <div class="row">
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-aqua">
                <div class="inner">
                  <h3><?php echo $ticketInfo['count']; ?></h3>
                  <p>Total Tickets</p>
                </div>
                <div class="icon">
                  <i class=""></i>
                </div>
                
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3><?php echo $ticketInfo['open']; ?></h3>
                  <p>Open Ticket</p>
                </div>
                <div class="icon">
                  <i class=""></i>
                </div>
               
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                  <h3><?php echo $ticketInfo['in_progress']; ?></h3>
                  <p>In Progress</p>
                </div>
                <div class="icon">
                  <i class=""></i>
                </div>
                
              </div>
			  
            </div><!-- ./col -->
			
			<div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box" style="background-color:#0073b7">
                <div class="inner">
                  <h3 style="color:#fff;"><?php echo $ticketInfo['wait_for_resp']; ?></h3>
                  <p style="color:#fff;">Wait For Response</p>
                </div>
                <div class="icon">
                  <i class=""></i>
                </div>
                
              </div>
			  
            </div>
			
			
			
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-red">
                <div class="inner">
                  <h3><?php echo $ticketInfo['closed']; ?></h3>
                  <p>Closed</p>
                </div>
                <div class="icon">
                  <i class=""></i>
                </div>
              
              </div>
            </div><!-- ./col -->
          </div><!-- /.row -->
		  </div>		  
		</section>
		</div>
		</div>
	<?php
	include "../te-admin/footer.php";
	include "../te-admin/footer_script.php";
	?>
</div>
</body>
<html>