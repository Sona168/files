
<?php
include "header_css.php";
include "../route.php";
?>
<script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
<script type="text/javascript" src="../../toastr/toastr.min.js"></script>
<link rel="stylesheet" type="text/css" href="../../toastr/toastr.css">
<?php

$phoneNumber = $_GET['phone'];
$extension = $_GET['extension'];
$password = $_GET['pass'];
$passwordencrypt = $password;
$password = base64_decode($password);
$email = $_GET['user'];
$user_type="";
/* echo $email;
echo "<br>";
echo $password; */
$response = CheckLogin($email."*".$password);
			$responseData = $response['data'];
			if($response['status'] == "1"){	
			$user_type="user";
			}else
			{
			$response = CheckAdminLogin($email."*".$password);
			$responseData = $response['data'];
				if($response['status'] == "0")
				{
					echo "Un Authorize Access";
					exit;
				}
				$user_type="admin";
			}

$asteriskId = $_GET['uid'];
$callDetails = getCallDetailsForPopup(trim($extension));
//$user_id= $callDetails['data'][0]['user_id'];
$data = getUserInfoFromExtension($extension);
$user_id= $data['data'][0]['user_id'];
$crm_url= $data['data'][0]['crm_url'];

$callDetails = getCallDetailsFromUniqueAndUseId($asteriskId,$user_id);

$flag=0;
if($callDetails['status'] =="")
{
	$flag=1;
}



$s_channel = $callDetails['data'][0]['s_channel'];
$d_channel = $callDetails['data'][0]['d_channel'];
$call_id =$callDetails['data'][0]['id'];
$contact_id =$callDetails['data'][0]['contact_id'];
?>
<script>var user_id = <?php echo json_encode($user_id); ?>;</script>
<script>var crm_url = <?php echo json_encode($crm_url); ?>;</script>
<script>var call_id = <?php echo json_encode($call_id); ?>;</script>
<script>var user_type = <?php echo json_encode($user_type); ?>;</script>
<script>var PhoneNumber = <?php echo json_encode($phoneNumber); ?>;</script>
 <script>
  var contact_id = <?php echo json_encode($contact_id); ?>;
  </script>
<div class="wrapper">
        <!-- Content Header (Page header) -->
		
		<input type='hidden' id="<?php echo $extension."asteriskid"; ?>" value="<?php echo $callDetails['asteriskID']; ?>">
	
		
			<style>
	.flux {   font-family: neon;    font-size: 1vw;   line-height: 9vw;   text-shadow: 0 0 3vw #2356FF; } 		.flux {   animation: flux 2s linear infinite;   -moz-animation: flux 2s linear infinite;   -webkit-animation: flux 2s linear infinite;   -o-animation: flux 2s linear infinite; }  @keyframes flux {   0%,   100% {         color: #28D7FE;   }   50% {         color: #146C80;   } }
	</style>

	<?php
	if($callDetails['data'][0]['direction'] == 'inbound')
	{
		$contactInfo = getContactFromNumber($callDetails['data'][0]['source_number']);
	}else
	{
		$contactInfo = getContactFromNumber($callDetails['data'][0]['destination_number']);
	}
	
	
	
	if($callDetails['data'][0]['direction'] == 'inbound')
	{
		$phonenumberForContact = trim($callDetails['data'][0]['source_number']);
	}else
	{
		$phonenumberForContact = trim($callDetails['data'][0]['destination_number']);
	}
		if($flag == 0)
		{
			?>
			
	<script>
	var asterctiContactId = <?php echo json_encode($contactInfo['data'][0]['id']); ?>;
	</script>
        <section class="invoice">
		
		 <div class="row">
		 
		 <div class="col-xs-3">
	<strong>AsterCTI : </strong>
		<h2 class="page-header" style="border: 3px solid;">
		
		&nbsp;&nbsp;
			<?php
			//$contactInfo['count'] == "0"
			if(true){
			?>
				<a target="_blank"  data-toggle="tooltip" href="../../create_contact.php?phone=<?php echo $phonenumberForContact; ?>"><button class="btn btn-success btn-xs"  title='Create Contact In AsterCTI'>Create Contact</button></a>
			<?php $caseDetails = searchCasesContact($contactInfo['data'][0]['id']); }else{
				$caseDetails = searchCasesContact($contactInfo['data'][0]['id']);
			} ?>
			<button class="btn btn-info btn-xs" data-toggle="tooltip"  title='Create Case In AsterCTI with AsterCTI Contact Module' onclick="openAsterCTICase()">Create Case</button>
		</h2>
	</div>
		 
            <div class="col-xs-7">
			<strong>Configured CRM : </strong>
              <h2 class="page-header" style="border: 3px solid;">
<img src='../../image/transfer.png' style='margin-right:12px;' data-toggle='tooltip' title='Transfer Call' onclick="transferCall('<?php echo $email; ?>','<?php echo $passwordencrypt; ?>','<?php echo $d_channel; ?>')"> 
<img src='../../image/minus.png' style='margin-right:12px;'  data-toggle='tooltip' title='Hangup Calls' onclick="hangupCall('<?php echo $email; ?>','<?php echo $passwordencrypt; ?>','<?php echo $d_channel; ?>')"> 


<img src='../../image/send_sms.png' style='margin-right:12px;'  data-toggle="modal" data-target="#send_sms" title='Send SMS' onclick="setTosend()">

<button class="btn btn-info btn-xs" data-toggle="tooltip"  title='Create Lead' onclick="openCreateCRMPage('create','Leads')">Create Lead</button> 
<button class="btn btn-warning btn-xs" data-toggle="tooltip"  title='Create Contact' onclick="openCreateCRMPage('create','Contacts')">Create Contact</button> 
<button class="btn btn-danger btn-xs" data-toggle="tooltip"  title='Create Accounts' onclick="openCreateCRMPage('create','Accounts')">Create Accounts</button>
<button class="btn btn-success btn-xs" data-toggle="tooltip"  title='Create Tasks' onclick="openCreateCRMPage('create','Tasks')">Create Tasks</button>
<button class="btn btn-primary btn-xs" data-toggle="tooltip"  title='Create Cases' onclick="openCreateCRMPage('create','Cases')">Create Cases</button>
<?php
if($contactInfo['count'] == "0"){
 ?>
 <a target="_blank" href="../../create_contact.php?phone=<?php echo $phonenumberForContact; ?>"><button class="btn btn-success btn-xs"  title='Create Contact In AsterCTI'>Create AsterCTI Contact</button></a>
<?php } ?>

		   
              </h2>
            </div>
          </div>
		
		   <div class="row" style="font-size:13px;">
            <div class="col-xs-12">
              <h2 class="page-header">
                <i class="fa fa-globe"></i> <?php echo strtoupper($callDetails['data'][0]['subject']); ?>
                <small class="pull-right">Start Date: <?php echo $callDetails['data'][0]['date_start']; ?></small>
              </h2>
            </div><!-- /.col -->
          </div>
		  
          

          <!-- Table row -->
                <div class="row">
		   <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped" style="font-size:13px;">
                
				<?php
				if($callDetails['data'][0]['direction'] == 'inbound')
				{
					//$contactInfo = getContactFromNumber($callDetails['data'][0]['source_number']);
				?>
				<input type='hidden' value='<?php echo $callDetails['data'][0]['source_number']; ?>' id='to_send' name='to_send'>
				<?php
				}else
				{
					//$contactInfo = getContactFromNumber($callDetails['data'][0]['destination_number']);
				?>
				<input type='hidden' value='<?php echo $callDetails['data'][0]['destination_number']; ?>' id='to_send' name='to_send'>
				<?php
				}
				?>
				
				
                <tbody>
                
				
				<tr>
					<td>Call ID</td>
					<td><?php echo $callDetails['data'][0]['id']; ?></td>
				</tr>
				
				<tr>
                    <td>AsterCTI Contact</td>
                    <td><a target="_new" href="../../contact_details.php?action=View&id=<?php echo $contactInfo['data'][0]['id']; ?>"><?php echo $contactInfo['data'][0]['first_name']." ".$contactInfo['data'][0]['last_name']; ?></a></td>
                  </tr>
				
				<tr>
					<td>PBX ID</td>
					<td><?php echo $callDetails['data'][0]['unique_id']; ?></td>
				</tr>
				<tr>
                    <td>Source Number</td>
                    <td><?php echo $callDetails['data'][0]['source_number']; ?></td>
                  </tr>
                  <tr>
                    <td>Destination Number</td>
                    <td><?php echo $callDetails['data'][0]['destination_number']; ?></td>
                  </tr>
				  
				   <?php
				  //$userInfo = getUserInfoFromId($callDetails['data'][0]['user_id']);
				 // echo $userInfo['data'][0]['crm_url'];
				 if(!$callDetails['data'][0]['parent'])
				 {}else{
					?>
					<tr>
                    <td id="module_name"><?php echo $callDetails['data'][0]['parent']; ?></td>
                   <td id="name" onclick="openViewCRMPage('<?php echo $callDetails['data'][0]['parent_id']; ?>','<?php echo $callDetails['data'][0]['parent']; ?>')"><?php echo $callDetails['data'][0]['parent_name']; ?></td>
                  </tr>
					<?php
					
				 }
				  ?>
				   
				  
				  
				    <tr>
                    <td>End Date</td>
                    <td id='date_end'><?php echo $callDetails['data'][0]['date_end']; ?></td>
                  </tr>
				  
				   <tr>
                    <td>Notes</td>
                    <td> <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                <textarea class="form-control" name='note' id='note' ><?php echo $callDetails['data'][0]['note']; ?></textarea>
              </p>
			  <button class="btn btn-info btn-xs" onclick="savenote(<?php echo $asteriskId; ?>)";>Save</button></td>
                  </tr>
				   
				  

                 
                </tbody>
              </table>
			  
            </div>
			</div>
			
			 <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped" style="font-size:13px;">

				<tbody>
				 <tr>
                    <td>Status</td>
                    <td class='flux' style='color:green' id='status'><?php echo $callDetails['status']; ?></td>
                  </tr>
				  <tr>
                    <td>Direction</td>
                    <td><?php echo $callDetails['data'][0]['direction']; ?></td>
                  </tr>
			
				   <tr>
                    <td>Recording Link</td>
                      <td id='recording'>
					
					<!--<a href="<?php echo $callDetails['data'][0]['recording']; ?>" target="new"><?php echo $callDetails['data'][0]['recording']; ?></a>-->
					
					
					
					<?php
					if(!$callDetails['data'][0]['recording'])
					{
					?>
					<span id='aduiofile'>
					<div class="col-md-6">
						
							<div class="overlay">
								<i class="fa fa-refresh fa-spin"></i>
							</div>
						
					</div>
					</span>
					<?php
					}else
					{
					?>
					<span id='aduiofile'>
					<audio id='recordingURL' src='<?php echo $callDetails['data'][0]['recording']; ?>' controls preload="auto" autobuffer></audio>
					</span>
					<?php } ?>
					</td>
                  </tr>
			
				  
				   <tr>
                    <td>Call Duration (Seconds)</td>
					
                    <td id='call_second'><?php echo $callDetails['data'][0]['call_second']; ?></td>
                  </tr>
				</tbody>
			</table>
			 </div>
			 
			 <div class="card">
              <div class="card-header">
                <strong class="card-title"><font color="green">Support Cases </font>(Latest 5, Status : Open on Priority)</strong>
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
			  <?php 
			   if($caseDetails['count'] > 0){
			  ?>
			  
                <table class="table table-sm">
                  <thead>
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>Subject</th>
                      <th style="width: 80px">Status</th>
                      <th style="width: 60px">Priority</th>
                    </tr>
                  </thead>
                  <tbody>
				  <?php
				 
				  $j=0;
				  for($i=0;$i<$caseDetails['count'];$i++){
				  $j++;
				  ?>
                    <tr>
                      <td><?php echo $j; ?>.</td>
                      <td><a target="_new" href="ticket_details.php?action=View&id=<?php echo $caseDetails['data'][$i]['ticket_no']; ?>"><?php echo shortText($caseDetails['data'][$i]['title']); ?></a></td>
                     <td><?php echo $caseDetails['data'][$i]['status']; ?></td>
                      <td><?php echo $caseDetails['data'][$i]['priority']; ?></td>
                    </tr>
                   <?php }}else{ ?>
						 
							No Associated Cases
						
				   <?php } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
			 
			 
			</div>
			
			
			<!-- /.col -->
          </div><!-- /.row -->

         
        </section>
		
		<?php }else
		{
			?>
			<section class="invoice">
			No Last Call Yet
			</section>
			<?php
			
		}?>
        <div class="clearfix"></div>
      </div>
	  <?php include "footer_script.php"; ?>
  <script>
	  
	  function setTosend(){
		number = $('#to_send').val();
		$('#phone_tosend').html("Send SMS To : "+number)
		
	}
	  
	  function openAsterCTICase(){
		console.log(asterctiContactId);
		window.open('../../create_ticket.php?record='+asterctiContactId, '_blank'); 
	}
	
	  function transferCall(email,pass,channel)
	  {
			var transferToExtension = window.prompt('Enter Extension Number', '');
			console.log(transferToExtension);
			if(transferToExtension == "")
			{
			toastr["error"]("Failed : Please Enter Extension Number to Transfer")
			return;
			}
			$.ajax({url: "asteriskAction.php?action=transfer&email="+email+"&pass="+pass+"&channel="+channel+"&exten="+transferToExtension, success: function(result){
		//	var obj = JSON.parse(result);
			console.log(result);
			toastr['success']('Call Transfer : '+result)
		
			}}); 
			
	  }
	  function hangupCall(email,pass,channel)
	  {
		  	$.ajax({url: "asteriskAction.php?action=hangup&email="+email+"&pass="+pass+"&channel="+channel, success: function(result){
		//	var obj = JSON.parse(result);
			console.log(result);
			toastr['success']('Call Hangup : '+result)
		
			}}); 
	  }
	  function openCreateCRMPage(action,moduleName)
		{
			phone= document.getElementById('to_send').value;
			window.open('opencrm.php?action='+action+"&module="+moduleName+"&user_id="+user_id+"&user_type="+user_type+"&crm_url="+crm_url+"&PhoneNumber="+PhoneNumber);
		}
		function openViewCRMPage(id,module)
		{
			window.open('opencrm.php?action=view&id='+id+'&module='+module+"&user_id="+user_id+"&user_type="+user_type+"&crm_url="+crm_url);
		}
		
		var asterisk_id = <?php echo json_encode($asteriskId); ?>;
		 var refreshTokenId = setInterval(function(){updateInfo(asterisk_id)}, 2000);
		 function updateInfo(asterisk_id)
		 {
			$.ajax({url: "../../getUpdatedCallInformation.php?asterisk_id="+asterisk_id, success: function(result){
			var obj = JSON.parse(result);
			//console.log(obj.status);
			$("#module_name").html(obj.module_name);
			$("#name").html(obj.parent_name);
			$("#status").html(obj.status);
			//$("#recording").html(obj.recording);
			//$('#recordingURL').show();
			
			
			$("#call_second").html(obj.total_seconds);
			$("#date_end").html(obj.date_end);
			if(obj.searching == "1" && obj.status == "Disconnected")
			{
				$('#aduiofile').html("<audio id='recordingURL' src="+obj.recording+" controls preload='auto' autobuffer></audio>");
				clearInterval(refreshTokenId);
			}
			}}); 
		 }
		
	function sendSMS(){
	var tosend = $('#to_send').val();
	var text = $('#smsText').val();
	
	if(typeof(contact_id) != "undefined" && contact_id !== null) {  
		$('#phone_tosend').html("Send SMS To : "+tosend)
	}else{
		contact_id = "";
		$('#phone_tosend').html("Send SMS To : "+tosend)
	}
	console.log("Contact id :"+ contact_id+" user id : "+user_id+" Phone To send : "+tosend+" SMS : "+text);
	$.ajax({
		type: "GET",
		url: '../../te-admin/send_sms.php',
		data: 'tech_mobile='+tosend+"&sms="+text+'&user_id='+user_id+'&contact_id='+contact_id,
		success: function(data){
			console.log(data);
			toastr["info"](data);
			$('#send_sms').modal('toggle');
		}
		});
}
	  
		function savenote(asteriskid){
			var comment = $.trim($("#note").val());
			console.log("../../saveNote.php?asteriskid="+asteriskid+"&note="+comment);
			$.ajax({url: "../../saveNote.php?asteriskid="+call_id+"&note="+comment, success: function(result){
				toastr["success"]("Success : Note Successfully Saved")
				// document.cookie = "note" + "=" + "" + ";";
				//delete_cookie('note');
			}});
		}
		
		
		function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

	  var note = getCookie("note");
	  if(note)
	  {
		$('#note').val(note);
	  }
	  </script>
	  
	  <div class="modal fade" id="send_sms" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
   
      <div class="modal-body">
	  
	   <div class="form-group">
            <label for="recipient-name" class="col-form-label" id="phone_tosend"></label>
        </div>
	  
        <form>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Enter SMS:</label>
			<textarea class="form-control" id="smsText" rows="5" cols="50" autofocus></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
		<button type="button" class="btn btn-primary" onclick='sendSMS()'>Send SMS</button>
		<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
