<?php
if(isset($_GET['action']))
{
	require '../route.php';
	$email = $_GET['email'];
		$password = $_GET['pass'];
		
		$password = base64_decode($password);
		$response = CheckLogin($email."*".$password);
		$responseData = $response['data'];
		if($response['status'] == "0")
		{
			
			$response = CheckAdminLogin($email."*".$password);
			$responseData = $response['data'];
				if($response['status'] == "0")
				{
					echo "UserName and Password Wrong..Please Reset Your Password Or Contact To Admin.";
					exit;
				}
		}
		
		
		$userExtnsion = trim($responseData['extension']);
		$userChannel = trim($responseData['channel']);
		$asterisk_ip_id = trim($responseData['asterisk_ip']);
		$context = trim($responseData['context']);
		if($asterisk_ip_id)
		{
			$asteriskDetails = getAsteriskById($asterisk_ip_id);
			$asteriskDetailsData =$asteriskDetails['data'][0];
			$PBXIP = $asteriskDetailsData['ip'];
			$ami_username = trim($asteriskDetailsData['ami_username']);
			$ami_password = trim($asteriskDetailsData['ami_password']);
			$port = $asteriskDetailsData['port'];
			if(!$port)
			{
				$port = "5038";
			}
		}else{
			echo "Please configure asterisk settings in TechExtension Portal";
			exit;
		}
	if($_GET['action'] == "hangup")
	{
		$channel = $_GET['channel'];
			$timeout = 10;
			$socket = fsockopen($PBXIP,$port, $errno, $errstr, $timeout);
			fputs($socket, "Action: Login\r\n");
			fputs($socket, "UserName: $ami_username\r\n");
			fputs($socket, "Secret: $ami_password\r\n\r\n");
			$wrets=fgets($socket,128);
			fputs($socket, "Action: Hangup\r\n" );
			fputs($socket, "Channel: $channel\r\n" );
			$wrets=fgets($socket,128);
			echo $wrets;
				sleep(1);
			fputs($socket, "Action: Logoff\r\n\r\n"); 
			
			fclose($socket); 
			$socket = "FALSE";
			
			
	}else if($_GET['action'] == "transfer")
	{
		$channel = $_GET['channel'];
		$exten = $_GET['exten'];
		$timeout = 10;
			$socket = fsockopen($PBXIP,$port, $errno, $errstr, $timeout);
			fputs($socket, "Action: Login\r\n");
			fputs($socket, "UserName: $ami_username\r\n");
			fputs($socket, "Secret: $ami_password\r\n\r\n");
			$wrets=fgets($socket,128);
			  fputs($socket, "Action: Redirect\r\n" );
			fputs($socket, "Channel: $channel\r\n" );
			fputs($socket, "Exten: $exten\r\n" );
			fputs($socket, "Context: $context\r\n" );
			fputs($socket, "Priority: 1\r\n" );
			$wrets=fgets($socket,128);
			
			echo $context." ".$channel." ".$exten;
			echo $wrets;
			sleep(1);
			fputs($socket, "Action: Logoff\r\n\r\n"); 
			
			//$wrets .= fread($socket, 8192); 
			
			fclose($socket); 
			$socket = "FALSE";
		
	}
}else
{
	echo "Un Authorize Access.";
}
?>