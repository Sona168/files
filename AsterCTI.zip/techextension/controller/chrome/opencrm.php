<?php
require '../route.php';


$appendURL='';
if(isset($_GET['action']))
{
	$user_id =  $_GET['user_id'];
	$user_type =  $_GET['user_type'];
	if($user_type =="user")
	{
	$user_info = getUserInfoFromId($user_id);
	}else{
		$user_info = getAdminInfoFromId($user_id);
	}
	$crm_url = $user_info['data'][0]['crm_url'];
	
	if($_GET['action'] == "create")
	{
		$moduleName = $_GET['module'];
		$PhoneNumber = $_GET['PhoneNumber'];
		
		$appendURL = getUserCreateCRMURL($user_id,$moduleName,$user_type,$PhoneNumber);
	}
	
	if($_GET['action'] == "view")
	{
		$moduleName = $_GET['module'];
		if(isset($_GET['id']))
		{
			$id = $_GET['id'];
		}else
		{
			$id="";
		}
		$appendURL = getUserCRMViewURL($user_id,$id,$moduleName,$user_type);
	}
}
$urlToOpen =  $crm_url.$appendURL;
?>
<script>var urlToOpen = <?php echo json_encode($urlToOpen); ?>;</script>
<script>location.href=urlToOpen</script>
