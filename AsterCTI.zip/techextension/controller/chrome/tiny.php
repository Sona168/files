<?php
header("Access-Control-Allow-Origin: *");
include "../route.php";
if(isset($_GET['callid']))
{
	$callid = trim($_GET['callid']);
	$note = trim($_GET['note']);
	$dataToSend = $callid."*".$note;
	$res = saveNote($dataToSend);
	echo "1";
}
if(isset($_GET['extension']))
{
	if(isset($_GET['uid']))
	{
		$extension = $_GET['extension'];
		$asteriskId = $_GET['uid'];
		$PhoneNumber = $_GET['phone'];
		$data = getUserInfoFromExtension($extension);
		//print_r($data);
		$user_type =$data['type'];
		$user_id= $data['data'][0]['user_id'];
		$crm_url= $data['data'][0]['crm_url'];
		$res = getCallInfoAfterUpdation($asteriskId);
do {
	sleep(3);
    $callDetails = getCallDetailsFromUniqueAndUseId($asteriskId,$user_id);
	$call_id =$callDetails['data'][0]['id'];
	$Name = $callDetails['data'][0]['parent_name'];
	$ID = $callDetails['data'][0]['parent_id'];
	$ModuleName = $callDetails['data'][0]['parent'];
	$AccountName = "";
	$AccountID = "";
	$noteDescription="";

$crmurl="";
$url = getPortalURL();
$AsterCTIUrl = $url['url'];
$create_lead=$AsterCTIUrl."/controller/chrome/opencrm.php?action=create&module=Leads&user_id=".$user_id."&user_type=".$user_type."&PhoneNumber=".$PhoneNumber;
$create_account=$AsterCTIUrl."/controller/chrome/opencrm.php?action=create&module=Accounts&user_id=".$user_id."&user_type=".$user_type."&PhoneNumber=".$PhoneNumber;
$create_contact=$AsterCTIUrl."/controller/chrome/opencrm.php?action=create&module=Contacts&user_id=".$user_id."&user_type=".$user_type."&PhoneNumber=".$PhoneNumber;
$create_task="$AsterCTIUrl./controller/chrome/opencrm.php?action=create&module=Tasks&user_id=".$user_id."&user_type=".$user_type."&PhoneNumber=".$PhoneNumber;
$create_case="$AsterCTIUrl./controller/chrome/opencrm.php?action=create&module=".$ModuleName."&user_id=".$user_id."&user_type=".$user_type."&PhoneNumber=".$PhoneNumber;
$schedule_call="0";
$schedule_meeeting="0";
$call_name_url = $AsterCTIUrl."/controller/chrome/opencrm.php?action=view&module=".$ModuleName."&user_id=".$user_id."&user_type=".$user_type."&id=".$ID;
$call_account_url ="";
$call_transfer="0";
$call_hangup="0";

echo $Name."|tech*".$ID."|tech*".$AccountName."|tech*".$AccountID;     
echo "|tech*".$noteDescription."|tech*".$PhoneNumber."|tech*".$crmurl."|tech*".$ModuleName."|tech*".$PhoneNumber;
echo "|tech*".$create_lead."|tech*".$create_account."|tech*".$create_contact."|tech*".$create_task."|tech*".$create_case."|tech*".$schedule_call."|tech*".$schedule_meeeting."|tech*".$call_name_url."|tech*".$call_account_url."|tech*".$call_transfer."|tech*".$call_hangup."|tech*".$call_id;
}while ($res['seaching'] == "1");
		
		
}else
	{
		echo "UnAuthorize Access : asteriskid is mendetory";	
	}
}else
{
	echo "UnAuthorize Access : extension is mendetory";
}
?>