<?php
	//ini_set('display_errors',1);
	//ini_set('display_startup_errors',1);
	header("Access-Control-Allow-Origin: *");
	error_reporting(0);
	require '../route.php';
	
		
	
	if(isset($_GET['action']))
	{
		
		if($_GET['action'] == "login")
		{
			$portalURL=getPortalURL();
			$portalURL= $portalURL['url'];
			$portalIP  = parse_url($portalURL,PHP_URL_HOST);
			$port = "9898";
			$email = trim($_GET['username']);
			$password = trim($_GET['password']);
			$password = base64_decode($password);
			$response = CheckLogin($email."*".$password);
			$responseData = $response['data'];
			if($response['status'] == "1"){
				$asterisk_ip_id = trim($responseData['asterisk_ip']);
				$popup_type = trim($responseData['popup_type']);
				$asteriskDetails = getAsteriskById($asterisk_ip_id);
				$asteriskDetailsData =$asteriskDetails['data'][0];
				$PBXIP = $asteriskDetailsData['ip'];
				echo "1*".trim($responseData['extension'])."*".$port."*".$portalIP."*".$PBXIP."*".$popup_type;
			}else
			{
			$response = CheckAdminLogin($email."*".$password);
			$responseData = $response['data'];
				if($response['status'] == "0")
				{
					echo "0";
				}else{
					$asterisk_ip_id = trim($responseData['asterisk_ip']);
					$asteriskDetails = getAsteriskById($asterisk_ip_id);
					$asteriskDetailsData =$asteriskDetails['data'][0];
					$PBXIP = $asteriskDetailsData['ip'];
					$popup_type = trim($responseData['popup_type']);
					echo "1*".trim($responseData['extension'])."*".$port."*".$portalIP."*".$PBXIP."*".$popup_type;
				}
			}
		}
	exit;
	}
	
	
	
	if(isset($_GET['username']) && isset($_GET['password']) && isset($_GET['phone']))
	{
		$email = trim($_GET['username']);
		$password = trim($_GET['password']);
		$password = base64_decode($password);
		$numberToCall = trim($_GET['phone']);
		$response = CheckLogin($email."*".$password);
		$responseData = $response['data'];
		if($response['status'] == "0")
		{
			echo "check in admin once";
			$response = CheckAdminLogin($email."*".$password);
			$responseData = $response['data'];
				if($response['status'] == "0")
				{
					echo "UserName and Password Wrong..Please Reset Your Password Or Contact To Admin.";
					exit;
				}
		}
		if($response['status'] != "0"){
		$userExtnsion = trim($responseData['extension']);
		$channel = trim($responseData['channel']);
		if(!$channel)
		{
			$channel = "SIP/"+$userExtnsion;
		}
		$asterisk_ip_id = trim($responseData['asterisk_ip']);
		$context = trim($responseData['context']);
		$prefix = trim($responseData['prefix']);
		
		if($asterisk_ip_id)
		{
			$asteriskDetails = getAsteriskById($asterisk_ip_id);
			$asteriskDetailsData =$asteriskDetails['data'][0];
			$PBXIP = trim($asteriskDetailsData['ip']);
			$ami_username = trim($asteriskDetailsData['ami_username']);
			$ami_password = trim($asteriskDetailsData['ami_password']);
			$port = $asteriskDetailsData['port'];
			if(!$port)
			{
				$port = "5038";
			}
			
			$num = preg_replace( "/^\+7/", "8", $numberToCall );
			$num = preg_replace( "/\D/", "", $numberToCall );
			$num = $prefix.$num;
		
        if ( ! empty( $num ) )
        {
                echo "Dialing $num\r\nFrom Extension $userExtnsion\r\n Using Asterisk IP $PBXIP\r\n";
				echo "<br>";
				echo "Channel $channel\r\Context $context\r\n On Exten $num\r\n";
                $timeout = 10;
                $socket = fsockopen($PBXIP,$port, $errno, $errstr, $timeout);
                fputs($socket, "Action: Login\r\n");
                fputs($socket, "UserName: $ami_username\r\n");
                fputs($socket, "Secret: $ami_password\r\n\r\n");
                $wrets=fgets($socket,128);
				
                fputs($socket, "Action: Originate\r\n" );
                fputs($socket, "Channel: $channel\r\n" );
                fputs($socket, "Exten: $num\r\n" );
                fputs($socket, "Context: $context\r\n" );
                fputs($socket, "Priority: 1\r\n" );
                fputs($socket, "Async: yes\r\n" );
                fputs($socket, "WaitTime: 15\r\n" );
				fputs($socket, "Variable: __SIPADDHEADER51=Call-Info: <sip:$PBXIP>\;answer-after=0\r\n" );
                fputs($socket, "Callerid: $num\r\n\r\n" );
                $wrets=fgets($socket,128);
                echo $wrets;
        }
        else
        {
                echo "Unable to determine number from (" . $numberToCall . ")\r\n";
        }
		}else{
			echo "Please configure asterisk settings in TechExtension Portal";
		}
		}else{
			echo "UserName and Password Wrong..Please Reset Your Password Or Contact To Admin.";
		}
	}else
	{
		echo "UnAuthorized Access";
	}
?>