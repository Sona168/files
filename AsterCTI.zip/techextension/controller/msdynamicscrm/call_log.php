<?php

function create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$ms_client_id,$crmurl,$crm_user_id,$date_start,$date_end,$asterisk_id,$type,$username,$password)
{
	$crmurl = trim($crmurl);
	$crmurl = rtrim($crmurl, '/');
	$username =trim($username);
	$password = trim($password);
	$client_id = trim($ms_client_id);
	$apiurl=$crmurl."/api/data/v8.2";

	$token_request_data = array (
		"username" => $username,
		"password" => $password,
		"client_id" => $client_id ,
		"resource" =>$crmurl ,
		"grant_type" =>"password" 
	);

	$token_request_body = http_build_query ($token_request_data);
	$curl = curl_init ( 'https://login.windows.net/common/oauth2/token' );
	curl_setopt ( $curl, CURLOPT_RETURNTRANSFER, true );
	curl_setopt ( $curl, CURLOPT_POST, true );
	curl_setopt ( $curl, CURLOPT_POSTFIELDS, $token_request_body );
	curl_setopt ( $curl, CURLOPT_SSL_VERIFYPEER,false);
	$response = curl_exec ( $curl );
	$res = json_decode($response);
	$accesstoken=$res->access_token;
	curl_close ($curl);	
	$authHeader = 'Authorization:Bearer '.$accesstoken;
	
	
	
	
	
/* $url = $apiurl."/systemusers?";
//print_r($url);

								$url = preg_replace('/[ ]/','%20',$url);
								//$url = "https://cfbtel.crm.dynamics.com/api/data/v8.2/contacts?\$select=contactid,yomifullname&\$top=1&\$filter=contains(telephone1,'".$PhoneNumber."')" ;

								// $url = http_build_query ( $url );
								   
								$curl = curl_init();
								curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
								curl_setopt($curl, CURLOPT_POST, false);
								curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
								curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
								curl_setopt($curl, CURLOPT_URL, $url);
								curl_setopt($curl, CURLOPT_HTTPHEADER, array($authHeader));
								$result = curl_exec($curl);
								curl_close($curl);
								$res = json_decode($result);
                                print_r($res);
								Exit;
								if(count($res->value) >= 1 )
								{
									$UserID  = $res->value[0]->ownerid;
									
								}
								
								
								if(!$UserID)
	{
		$UserID="dd42e65b-1bc0-e811-814e-e0071b6fb0e1";
		
	}
 */	
 
 
 $UserID="dd42e65b-1bc0-e811-814e-e0071b6fb0e1";
//	echo "User ID".$UserID;
	

	
	
	
	
	
	
	
if($direction == 'inbound')
{
	$Direction = 'inbound';
	$directioncode=false;
}else if($direction == 'outbound')
{
	$Direction = 'outbound';
	$directioncode=true;
}else if($direction == 'internal')
{
	$Direction = 'internal';
	$directioncode=false;
}

if($disposition == "ANSWERED")
{
	$status = "Held";
	$statecode='1';
}else{
	$status = "Not Held";
	$statecode='2';
}

if($duration==0)
{
    $CallDurationMinuteSec='0:0';
    $CallStatus='Not Held';
	$CallDurationMinuteSec=0;
}
 elseif($duration<3599) 
{
    $CallDurationMinuteSec=gmdate("i:s", $duration);
	$CallDurationMinute=gmdate("i", $duration);
    $CallStatus='Held';
}
 else 
{
	$CallDurationMinuteSec=gmdate("i:s", $duration);
	$CallDurationMinute=gmdate("i", $duration);
	$CallStatus='Held';
}
$startdatetemp=substr($date_start,0,10);
$starttimetemp=substr($date_start,-8);
$starttimetemp=str_replace("-",":",$starttimetemp);
$startDate=$startdatetemp." ".$starttimetemp;
$startDate=date("Y-m-d\TH:i:s\Z",strtotime($startDate));


$enddatetemp=substr($date_end,0,10);
$endtimetemp=substr($date_end,-8);
$endtimetemp=str_replace("-",":",$endtimetemp);
$endDate=$enddatetemp." ".$endtimetemp;
$endDate=date("Y-m-d\TH:i:s\Z",strtotime($endDate));

$calltime=date("Y-m-d\TH:i:s\Z");

if($module_name == "Contacts")
{
	$ModuleNameForCreate = "contact";
}else if($module_name == "Accounts")
{
	$ModuleNameForCreate = "account";
}else if($module_name == "Leads")
{
	$ModuleNameForCreate = "lead";
}
$token_request_data = array (
	"subject" => $subject,
	"regardingobjectid_".$ModuleNameForCreate."@odata.bind"=>"/".$ModuleNameForCreate."s(".$parent_id.")",
	"directioncode" => $directioncode,
	"prioritycode" => 1,
	"activitytypecode" => 'phonecall',
	"actualdurationminutes" => $CallDurationMinute,
	"phonenumber" => $source_number,
	"statecode" => $statecode,
	"createdon" => $calltime,
	"modifiedon" => $calltime,
	"actualstart" => $startDate,
	"actualend" => $endDate,
	"scheduledstart" => $startDate,
	//"new_callrecordinglink" => $recordLnk,
	"ownerid@odata.bind" => "/systemusers(".$UserID.")",
	"createdby@odata.bind" => "/systemusers(".$UserID.")",
	"owninguser@odata.bind" => "/systemusers(".$UserID.")",
);

	$token_request_data = json_encode($token_request_data);
	$authHeader = array(
	'Content-Type: application/json',
	'Authorization:Bearer '.$accesstoken
	);
	$curl = curl_init ($apiurl."/phonecalls");
	curl_setopt ( $curl, CURLOPT_RETURNTRANSFER, true );
	curl_setopt ( $curl, CURLOPT_POST, true );
	curl_setopt ( $curl, CURLOPT_POSTFIELDS, $token_request_data );
	curl_setopt ( $curl, CURLOPT_SSL_VERIFYPEER,false);
	curl_setopt($curl, CURLOPT_HTTPHEADER, $authHeader);
	$response = curl_exec ( $curl );
	$res = json_decode($response);
	//print_r($res);
	//print_r($response);
	return $res;
}
?>