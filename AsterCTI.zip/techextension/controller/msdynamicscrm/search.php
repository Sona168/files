<?php

function search($numberTOSearch,$ms_client_id,$crmurl,$extension,$username,$password)
{
	$crmurl = trim($crmurl);
	$crmurl = rtrim($crmurl, '/');
	$username =trim($username);
	$password = trim($password);
	$client_id = trim($ms_client_id);
	$apiurl=$crmurl."/api/data/v8.2";

	$token_request_data = array (
		"username" => $username,
		"password" => $password,
		"client_id" => $client_id ,
		"resource" =>$crmurl ,
		"grant_type" =>"password" 
	);
	  
	$token_request_body = http_build_query ($token_request_data);
	$curl = curl_init ( 'https://login.windows.net/common/oauth2/token' );
	curl_setopt ( $curl, CURLOPT_RETURNTRANSFER, true );
	curl_setopt ( $curl, CURLOPT_POST, true );
	curl_setopt ( $curl, CURLOPT_POSTFIELDS, $token_request_body );
	curl_setopt ( $curl, CURLOPT_SSL_VERIFYPEER,false);
	$response = curl_exec ( $curl );
	$res = json_decode($response);
	$accesstoken=$res->access_token;
	curl_close ($curl);	
	$authHeader = 'Authorization:Bearer '.$accesstoken;

	$PhoneNumber= preg_replace('/[^A-Za-z0-9\-]/', '',$numberTOSearch);
	$PhoneNum=$PhoneNumber;
	$PhoneNumber=substr($PhoneNum,-7);
	$PhoneNum=$PhoneNumber;
	$PhoneNumber=substr($PhoneNum,0,3)."-".substr($PhoneNum,3,7);

	$Name="No Contact Name Found";
	$AccountName="No Account Name Found";
	$ID="";
	$ModuleName="";
	$AccountID="";

	$url = $apiurl."/contacts?\$select=contactid,yomifullname,_accountid_value&\$top=1&\$filter=(contains(telephone1,'".$PhoneNumber."') or contains(telephone2,'".$PhoneNumber."') or contains(telephone3,'".$PhoneNumber."') or contains(mobilephone,'".$PhoneNumber."') or contains(telephone1,'".$PhoneNum."') or contains(telephone2,'".$PhoneNum."') or contains(telephone3,'".$PhoneNum."') or contains(mobilephone,'".$PhoneNum."'))";
	$url = preg_replace('/[ ]/','%20',$url);
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
	curl_setopt($curl, CURLOPT_POST, false);
	curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_HTTPHEADER, array($authHeader));
	$result = curl_exec($curl);
	curl_close($curl);
	$res = json_decode($result);
	if(count($res->value) >= 1 )
	{
		$ID  = $res->value[0]->contactid;
		$Name = $res->value[0]->yomifullname;
		$AccountID="";
		$AccountName="";
		$ModuleName = "Contacts";
		if($AccountName=="")
		{
			$AccountName = "No Account Found";
		}
	}
	else if(true)
	{
			//SearchingIn Accounts Module
			$url = $apiurl."/accounts?\$select=name,accountid&\$top=1&\$filter=(contains(telephone1,'".$PhoneNumber."') or contains(telephone2,'".$PhoneNumber."') or contains(telephone3,'".$PhoneNumber."') or contains(telephone1,'".$PhoneNum."') or contains(telephone2,'".$PhoneNum."') or contains(telephone3,'".$PhoneNum."'))";
			$url = preg_replace('/[ ]/','%20',$url);
			$curl = curl_init();
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
			curl_setopt($curl, CURLOPT_POST, false);
			curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curl, CURLOPT_URL, $url);
			curl_setopt($curl, CURLOPT_HTTPHEADER, array($authHeader));
			$result = curl_exec($curl);
			curl_close($curl);
			$res = json_decode($result);
			if(count($res->value) >= 1 )
			{
				$Name ="No Contact Name";
				$ID  = $res->value[0]->accountid;
				$AccountName = $res->value[0]->name;
				$ModuleName = "Accounts";
			}
		else
		{
			//Searching in Leads Module
			$url = $apiurl."/leads?\$select=fullname,leadid,companyname&\$top=1&\$filter=(contains(telephone1,'".$PhoneNumber."') or contains(telephone2,'".$PhoneNumber."') or contains(telephone3,'".$PhoneNumber."') or contains(mobilephone,'".$PhoneNumber."') or contains(telephone1,'".$PhoneNum."') or contains(telephone2,'".$PhoneNum."') or contains(telephone3,'".$PhoneNum."') or contains(mobilephone,'".$PhoneNum."'))";
			$url = preg_replace('/[ ]/','%20',$url);
			$curl = curl_init();
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
			curl_setopt($curl, CURLOPT_POST, false);
			curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curl, CURLOPT_URL, $url);
			curl_setopt($curl, CURLOPT_HTTPHEADER, array($authHeader));
			$result = curl_exec($curl);
			curl_close($curl);
			$res = json_decode($result);
			if(count($res->value) >= 1 )
			{
				$ID  = $res->value[0]->leadid;
				$Name  = $res->value[0]->fullname;
				$AccountName  = $res->value[0]->companyname;
				$ModuleName = "Leads";			
			}
		}
	}
	if(!$ID)
	{
		$ModuleName="No CRM Relation Found";
	}
	$dataToSend['name'] = $Name;
	$dataToSend['ID'] = $ID;
	$dataToSend['AccountName'] = $AccountName;
	$dataToSend['ModuleName'] = $ModuleName;
	/* $dataToSend['UserName'] = $UserName;
	$dataToSend['UserID'] = $UserID; */

	return $dataToSend;
}
?>