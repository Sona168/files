<?php

function create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$session_id,$url,$crm_user_id,$startDate,$endDate,$asterisk_id)
{
	
if($duration==0)
{
    $CallDurationMinuteSec='00:00';
}
 elseif($duration<3599) 
{
    $CallDurationMinuteSec=gmdate("H:i", $duration);
}
 else 
{
    $CallDurationMinuteSec=gmdate("H:i:s", $duration);
}
	
	$startDate=date("Y-m-d",strtotime($startDate));
	$startTime=date("H:i",strtotime($startDate));
	
	$call_info =array(
			'subject' => $subject,
			'done' => "1",
			'type' => 'call',
			'due_date' => $startDate,
			//'due_time' => date("H:i"),
			'due_time' => $startTime,
			 'note' => $recordLnk,
			'duration' => $CallDurationMinuteSec,
			'user_id' => $crm_user_id,
			'person_id' => $parent_id,
			'org_id' => '',
		);
	$responceID = create_call_log($session_id, $call_info);
	return $responceID;
	
	
	

}

function create_call_log($api_token, $activity)
{
 $url = "https://api.pipedrive.com/v1/activities?api_token=".$api_token;
 
 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $url);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 curl_setopt($ch, CURLOPT_POST, true);
 
 curl_setopt($ch, CURLOPT_POSTFIELDS, $activity);
 $output = curl_exec($ch);
 $info = curl_getinfo($ch);
 curl_close($ch);
 
 // create an array from the data that is sent back from the API
 $result = json_decode($output, 1);
 // check if an id came back
 if (!empty($result['data']['id'])) {
  $deal_id = $result['data']['id'];
  return $deal_id;
 } else {
  return false;
 }
}

?>