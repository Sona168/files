<?php

function search($source_number,$api_token,$url,$Extension)
{
	$PhoneNumber = $source_number;
$PhoneNumber= preg_replace('/[^A-Za-z0-9\-]/', '',$PhoneNumber);

	//Default Searches In Contacts Module
	$Name="";
	$AccountName="";
	$ID="";
    $ModuleName="No CRM Relation Found";
	$AccountID="";
	$resPerson = file_get_contents("https://api.pipedrive.com/v1/searchResults?term=$PhoneNumber&item_type=person&start=0&limit=1&api_token=$api_token&limit=1");
	$resPerson = json_decode($resPerson, true);
	if($resPerson['data']['0'])
	{
		//Number Found in Contacts Module
		$Name = $resPerson['data'][0]['title'];
		$ID = $resPerson['data'][0]['id'];
		$AccountName = $resPerson['data'][0]['details']['org_name'];
		$AccountID =  $resPerson['data'][0]['details']['org_id'];
		$ModuleNameOriginal = $resPerson['data'][0]['type'];
		if($AccountName=="")
		{
			$AccountName = "";
		}
		$ModuleName ="Contacts";
	}
	else if(true)
	{
		//No Contact Found	
	}

$dataToSend['name'] = $Name;
$dataToSend['ID'] = $ID;
$dataToSend['AccountName'] = $AccountName;
$dataToSend['ModuleName'] = $ModuleName;
/* $dataToSend['UserName'] = $UserName;
$dataToSend['UserID'] = $UserID; */

return $dataToSend;
}
?>