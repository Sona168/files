<?php

function create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$sessionid,$url,$Extension,$crm_user_id,$date_start,$date_end,$asterisk_id,$type)
{
	
/* 'callfrom'=> $subject,
'callto'=> $extension,
'timeofcall'          => $duration,
'status' => $disposition, */

	$vEvent = array(
	'direction'=> $direction,
	'customer'=>$parent_id,
	'customertype'=>$module_name,
	'starttime'=> $date_start,
	'endtime'=> $date_end,
	'callstatus' => $disposition,
	'totalduration'          => $duration,
	'billduration'=> $duration,
	"recordingurl"            => $recordLnk,
	'sourceuuid'      => $asterisk_id,
	'gateway'        => 'TechExtension Portal',
	'user' => $crm_user_id,
	'customernumber'      => $source_number,
	'assigned_user_id' =>$crm_user_id,
);


         $objectJson = json_encode($vEvent);
		//$service_url = $url."/webservice.php";
        $curl = curl_init($url);
        $curl_post_data = array(
        'operation' => 'create',
        'sessionName' => $sessionid,
        'element' => $objectJson,
        'elementType' => 'PBXManager'
        ); 
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $curl_post_data);
        $curl_response = json_decode(curl_exec($curl));
       // $CRM_SESSION_OPERATIONS = $curl_response->result->sessionName;
       
        if(!$curl_response->error)
		{
			$result = $curl_response->result;
			$callID = $result->id;
		}else
		{
			$callID = $result = $curl_response->error->code;
		}
		return $callID;
 }


?>