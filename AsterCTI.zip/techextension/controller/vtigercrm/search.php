<?php
ini_set('display_errors',1);
	ini_set('display_startup_errors',1);
function search($source_number,$sessionid,$endpointUrl,$Extension)
{
	$LeadId=""; $AccountID=""; $AccountName=""; $ContactId=""; $moduleName="";
$PhoneNumber = $source_number;
$PhoneNumber = preg_replace('/[^A-Za-z0-9\-]/', '', $PhoneNumber);
$PhoneNumber=substr($PhoneNumber,-10);


if(strlen($PhoneNumber) >6)
{
	$PatternToSearch1="";
$PatternToSearch2="";

$tempnumber=substr($PhoneNumber,-7);

$PatternToSearch2=substr($tempnumber,0,3)."-".substr($tempnumber,3,7);
$PatternToSearch1=$tempnumber;
$query = "select firstname,lastname,account_id,id,description from Contacts where phone like '%$PatternToSearch1' or mobile like '%$PatternToSearch1' or otherphone like '%$PatternToSearch1' or phone like '%$PatternToSearch2' or mobile like '%$PatternToSearch2' or otherphone like '%$PatternToSearch2' order by modifiedtime limit 1;";
//$query = "select * from Contacts where phone='7405605907' order by modifiedtime desc limit 1;";

$getUserDetail = call_vtiger($endpointUrl, array("operation" => "query", "sessionName" => $sessionid, 'query' => $query));
$response = $getUserDetail['result'][0];
/* echo $sessionid;
echo $endpointUrl;
return $response ;
exit; */
$firstname = $response['firstname'];
$lastname = $response['lastname'];
$Name = $firstname." ".$lastname;
$account_id = $response['account_id'];
$Description = $response['description'];
$AccountID = $account_id;
$id = $response['id'];
$ContactId = $id;
$CId = $id;
if($id)
{
	$ModuleName = "Contacts";
}

		if($AccountID)
		{
				$query = "select accountname from Accounts  where id ='$AccountID';";
				$getUserDetail = call_vtiger($endpointUrl, array("operation" => "query", "sessionName" => $sessionid, 'query' => $query));
				$response = $getUserDetail['result'][0];
				$AccountName = $response['accountname'];
		}
		else
		{
			$AccountName = "No Account Name Found";
		}
		if(!$ContactId)
		{
			$query = "SELECT firstname,lastname,id,company,description,assigned_user_id FROM Leads where phone like '%$PatternToSearch1' or mobile like '%$PatternToSearch1' or fax like '%$PatternToSearch1' or phone like '%$PatternToSearch2' or mobile like '%$PatternToSearch2' or fax like '%$PatternToSearch2'  ;"; 
			$getUserDetail = call_vtiger($endpointUrl, array("operation" => "query", "sessionName" => $sessionid, 'query' => $query));
			$response = $getUserDetail['result'][0];
			$firstname = $response['firstname'];
			$lastname = $response['lastname'];
			$Description = $response['description'];
			$Name = $firstname." ".$lastname;
			$AccountName = $response['company'];
			$id = $response['id'];
			
			$LeadId = $id;
			$CId = $LeadId;
			$ModuleName = "Leads";
			
			
		if(!$LeadId)
		{
	$query = "SELECT accountname,id,description,assigned_user_id FROM Accounts where phone like '%$PatternToSearch1' or fax like '%$PatternToSearch1' or otherphone like '%$PatternToSearch1' or phone like '%$PatternToSearch2' or fax like '%$PatternToSearch2' or otherphone like '%$PatternToSearch2' ;"; 
										
			$getUserDetail = call_vtiger($endpointUrl, array("operation" => "query", "sessionName" => $sessionid, 'query' => $query));
			$response = $getUserDetail['result'][0];
			$AccountName = $response['accountname'];
			$AccountID = $response['id'];
			$Description = $response['description'];
			if($AccountID)
			{
				$ModuleName = "Accounts";
			}
		}
			
			
		}
}else
{
	$phoneNumber = $PhoneNumber;
	 $query = "select firstname,lastname,account_id,id,description from Contacts where phone like '$phoneNumber' or mobile like '$phoneNumber' or otherphone like '$phoneNumber' order by modifiedtime limit 1;";

$getUserDetail = call_vtiger($endpointUrl, array("operation" => "query", "sessionName" => $sessionid, 'query' => $query));

$response = $getUserDetail['result'][0];
$firstname = $response['firstname'];
$lastname = $response['lastname'];
$Name = $firstname." ".$lastname;
$account_id = $response['account_id'];
$Description = $response['description'];
$AccountID = $account_id;
$id = $response['id'];
$ContactId = $id;
$CId = $id;
if($id)
{
	$ModuleName = "Contacts";
}

		if($AccountID)
		{
				$query = "select accountname from Accounts  where id ='$AccountID';";
				$getUserDetail = call_vtiger($endpointUrl, array("operation" => "query", "sessionName" => $sessionid, 'query' => $query));
				$response = $getUserDetail['result'][0];
				$AccountName = $response['accountname'];
		}
		else
		{
			$AccountName = "No Account Name Found";
		}

		if(!$ContactId)
		{
		$query = "SELECT firstname,lastname,id,company,description,assigned_user_id FROM Leads where phone like '$phoneNumber' or mobile like '$phoneNumber' or fax like '$phoneNumber'  ;"; 
			$getUserDetail = call_vtiger($endpointUrl, array("operation" => "query", "sessionName" => $sessionid, 'query' => $query));
			$response = $getUserDetail['result'][0];
			$firstname = $response['firstname'];
			$lastname = $response['lastname'];
			$Description = $response['description'];
			$Name = $firstname." ".$lastname;
			$AccountName = $response['company'];
			$id = $response['id'];
			$LeadId = $id;
			$CId = $LeadId;
			$ModuleName = "Leads";
			
			
		if(!$LeadId)
		{
			//echo "Search in Accounts.............";
	$query = "SELECT accountname,id,description,assigned_user_id FROM Accounts where phone like '$phoneNumber' or fax like '$phoneNumber' or otherphone like '$phoneNumber' ;"; 												
			$getUserDetail = call_vtiger($endpointUrl, array("operation" => "query", "sessionName" => $sessionid, 'query' => $query));
			$response = $getUserDetail['result'][0];
			$AccountName = $response['accountname'];
			$AccountID = $response['id'];
			$CId = $AccountID;
			$Description = $response['description'];
			if($AccountID)
			{
				$ModuleName = "Accounts";
			}
		}
		}
}

$NoteIdSearch="";
		if($ModuleName =="Contacts")
		{
			$NoteIdSearch = $CId;
		}
		else if ($ModuleName =="Accounts")
		{
			$NoteIdSearch = $AccountID;
		}
		else if($ModuleName == "Leads")
		{
			//echo $LeadID;
			$NoteIdSearch = $LeadId;
			
		}
		else 
		{
			
		}
		if(!$CId){
			$ModuleName="No CRM Relation";
			$NoteIdSearch="";
		}

$dataToSend['name'] = $Name;
$dataToSend['ID'] = $NoteIdSearch;
$dataToSend['AccountName'] = $AccountName;
$dataToSend['ModuleName'] = $ModuleName;
/* $dataToSend['UserName'] = $UserName;
$dataToSend['UserID'] = $UserID; */

return $dataToSend;
}


?>