<?php

function create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$session_id,$url,$crm_user_id,$startDate,$endDate,$asterisk_id)
{
	
if($direction == 'inbound')
{
	$direction = "Inbound";
}else if($direction == 'outbound')
{
	$direction = "Outbound";
}else if($direction == 'internal')
{
	$direction = "Internal";
}

if($disposition == "ANSWERED")
{
	$status = "Held";
}else{
	$status = "Not Held";
}
 $startDate=date("Y-m-d H:i:s",strtotime($startDate));
 $endDate=date("Y-m-d H:i:s",strtotime($endDate));
 $set_entry_list_parameters = array(
         'session' => $session_id,
         'module_name' => 'Calls',
         array(
			"name" => $subject,
			"description" => $note,
			"call_source_c" => $source_number,
			"call_entrysource_c" => 'TechExtension Portal',
			"call_destination_c" => $extension,
			"direction" => $direction,
			"call_duration_minute_c" => $duration,
			"status" => $status,
			"assigned_user_id" => $crm_user_id,
			"record_c" => $recordLnk,
			"date_start" => $startDate,
			"date_end" => $endDate,
			"parent_type" => $module_name,
			"parent_id" => $parent_id,
			"outlook_id" => $asterisk_id,
        ),
    );
	 $set_entry_list_result = call('set_entry', $set_entry_list_parameters, $url);
	
	if($parent_id){
	$link_field_name = strtolower($module_name);
		$set_relationship_parameters = array(
		'session' => $session_id,
		'module_name' => 'Calls',
		'module_id' => $set_entry_list_result->id,
		'link_field_name' => $link_field_name,
		'related_ids' => array(
		$parent_id,
		),
		'delete'=> 0,
		);
 $set_relationship_result = call('set_relationship', $set_relationship_parameters, $url);
//print_r($set_relationship_result);
}
return $set_entry_list_result->id;
   
}
function saveNoteInCRM($note,$session_id,$url,$asterisk_id)
{
		$get_entry_list_parameters = array(
			 'session' => $session_id,
			 'module_name' => 'Calls',
			 'query' => " calls.outlook_id like '%".$asterisk_id."'  ",
			 'order_by' => "",
			 'offset' => '0',
			 'select_fields' => array(
				  "name"
			 ),
			 'max_results' => '1',
			 'deleted' => '0',
			 'Favorites' => false,
		);
		$get_entry_list_result = call('get_entry_list', $get_entry_list_parameters, $url);
		//print_r($get_entry_list_result);exit;
		if($get_entry_list_result->result_count=='1')
		{
				$callID = $get_entry_list_result->entry_list[0]->id;
				$set_entry_parameters = array
				(
					//session id
					"session" => $session_id,

					//The name of the module from which to retrieve records.
					"module_name" => "Calls",

					//Record attributes
					"name_value_list" => array
					(
						//to update a record, you will nee to pass in a record id as commented below
						array("name" => "id", "value" => $callID),
						array("name" => "description", "value" => $note),
					),
				);

				$set_entry_result = call("set_entry", $set_entry_parameters, $url);
				
				echo "Note Saved Successfully";
		}
		else
		{
			echo "please wait till call disconnected";
		}
}


?>