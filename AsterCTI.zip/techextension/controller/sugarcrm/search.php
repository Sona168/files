<?php

function search($source_number,$session_id,$url,$Extension)
{
	$PhoneNumber = $source_number;
//Default Searches In Contacts Module
	 $get_entry_list_parameters = array(
         'session' => $session_id,
         'module_name' => 'Contacts',
         'query' => " contacts.phone_work like '%".$PhoneNumber."' or contacts.phone_mobile like '%".$PhoneNumber."'  or contacts.phone_fax like '%".$PhoneNumber."' ",
         'order_by' => "",
         'offset' => '0',
         'select_fields' => array(
              "name","account_name","id","account_id"
         ),
         'max_results' => '1',
         'deleted' => '0',
         'Favorites' => false,
    );
    $get_entry_list_result = call('get_entry_list', $get_entry_list_parameters, $url);
	  $ABC =$get_entry_list_result;
	$Name="No Contact Name Found";
	$AccountName="No Account Name Found";
	$ID="";
    $ModuleName="";
	$AccountID="";
	if($get_entry_list_result->result_count!=0)
	{
	//Number Found in Contacts Module
		$Name = $get_entry_list_result->entry_list[0]->name_value_list->name->value;
		$ID = $get_entry_list_result->entry_list[0]->id;
		$AccountName = $get_entry_list_result->entry_list[0]->name_value_list->account_name->value;
		$AccountID = $get_entry_list_result->entry_list[0]->name_value_list->account_id->value;
		$ModuleName = "Contacts";
		$link_field_name = "contacts";
		if($AccountName=="")
		{
		$AccountName = "No Account Found";
		}
	}
	else if(true)
	{
	//Searching in Accounts Module
		$get_entry_list_parameters = array(
			 'session' => $session_id,
			 'module_name' => 'Accounts',
			'query' => " accounts.phone_office like '%".$PhoneNumber."' or accounts.phone_fax like '%".$PhoneNumber."'  ",
			 'order_by' => "",
			 'offset' => '0',
			 'select_fields' => array(
				  "name"
			 ),
			 'max_results' => '1',
			 'deleted' => '0',
			 'Favorites' => false,
		);
		$get_entry_list_result = call('get_entry_list', $get_entry_list_parameters, $url);
		if($get_entry_list_result->result_count!=0)
		{
			//Number Found in Accounts Module
			$Name ="No Contact Name";
			$ID = $get_entry_list_result->entry_list[0]->id;
			$AccountName = $get_entry_list_result->entry_list[0]->name_value_list->name->value;
			$ModuleName = "Accounts";
			$link_field_name = "accounts";
		
		}
		else
		{
			//Searching Number in Leads Module
		$get_entry_list_parameters = array(
         'session' => $session_id,
         'module_name' => 'Leads',
         'query' => " leads.phone_work like '%".$PhoneNumber."' or leads.phone_mobile like '%".$PhoneNumber."' or leads.phone_home like '%".$PhoneNumber."'  or leads.phone_fax like '%".$PhoneNumber."' ",
         'order_by' => "",
         'offset' => '0',
         'select_fields' => array(
              "name","account_name","id"
         ),
         'max_results' => '1',
         'deleted' => '0',
         'Favorites' => false,
    );
    $get_entry_list_result = call('get_entry_list', $get_entry_list_parameters, $url);
	if($get_entry_list_result->result_count!=0)
		{
			//Number Found in Leads Module
			$ID = $get_entry_list_result->entry_list[0]->id;
			$Name = $get_entry_list_result->entry_list[0]->name_value_list->name->value;
			$AccountName = $get_entry_list_result->entry_list[0]->name_value_list->account_name->value;
			$ModuleName = "Leads";
			$link_field_name = "leads";
		}
			
		}
	}
		$NoteIdSearch="";
		
		if($ModuleName =="Contacts")
		{
			$NoteIdSearch = $ID;
		}
		else if ($ModuleName =="Accounts")
		{
			$NoteIdSearch = $ID;
		}
		else if($ModuleName == "Leads")
		{
			$NoteIdSearch = $ID;
		}
		else 
		{
			$ModuleName="No CRM Relation Found";
			$NoteIdSearch="";
		}
	
 /* $get_entry_list_parameters = array(
			 'session' => $session_id,
			 'module_name' => 'Users',
			 'query' => " users_cstm.phoneextension_c like '%".$Extension."'  ",
			 'order_by' => "",
			 'offset' => '0',
			 'select_fields' => array(
				  "id","name"
			 ),
			 'max_results' => '1',
			 'deleted' => '0',
			 'Favorites' => false,
		);
		$get_entry_list_result = call('get_entry_list', $get_entry_list_parameters, $url);
		$UserID= $get_entry_list_result->entry_list[0]->id;
		$UserName= $get_entry_list_result->entry_list[0]->name;
		if(!$UserID)
		{
			$UserID="1"; 
		} */

$dataToSend['name'] = $Name;
$dataToSend['ID'] = $NoteIdSearch;
$dataToSend['AccountName'] = $AccountName;
$dataToSend['ModuleName'] = $ModuleName;
/* $dataToSend['UserName'] = $UserName;
$dataToSend['UserID'] = $UserID; */

return $dataToSend;
}
?>