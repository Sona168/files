<?php

function create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$session_id,$url,$crm_user_id,$startDate,$endDate,$asterisk_id)
{
	
if($direction == 'inbound')
{
	$direction = "Inbound";
}else if($direction == 'outbound')
{
	$direction = "Outbound";
}else if($direction == 'internal')
{
	$direction = "Internal";
}

if($disposition == "ANSWERED")
{
	$status = "Held";
}else{
	$status = "Not Held";
}
 /* $startDate=date("m/d/Y H:i:s",strtotime($startDate));
 $endDate=date("m/d/Y H:i:s",strtotime($endDate)); */
 $startDate= date('Y-m-d\TH:i:sO',strtotime($startDate));
 $endDate=date('Y-m-d\TH:i:sO',strtotime($endDate));
 $url = $url . "/Calls";
//Set up the Record details
$record = array(
    "name" => $subject,
	"description" => $note,
	"call_source_c" => $source_number,
	"call_entrysource_c" => 'TechExtension Portal',
	"call_destination_c" => $extension,
	"direction" => $direction,
	"call_duration_minute_c" => $duration,
	"status" => $status,
	"assigned_user_id" => $crm_user_id,
	"record_c" => $recordLnk,
	"date_start" => $startDate,
	 "duration_minutes" => $duration,
	"date_end" => $endDate,
	"parent_type" => $module_name,
	"parent_id" => $parent_id,
	"outlook_id" => $asterisk_id,
);

$curl_request = curl_init($url);
curl_setopt($curl_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
curl_setopt($curl_request, CURLOPT_HEADER, false);
curl_setopt($curl_request, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl_request, CURLOPT_FOLLOWLOCATION, 0);
curl_setopt($curl_request, CURLOPT_HTTPHEADER, array(
    "Content-Type: application/json",
    "oauth-token: {$session_id}"
));

//convert arguments to json
$json_arguments = json_encode($record);
curl_setopt($curl_request, CURLOPT_POSTFIELDS, $json_arguments);
//execute request
$curl_response = curl_exec($curl_request);
//decode json
$createdRecord = json_decode($curl_response);

//display the created record
//print_r($createdRecord);
curl_close($curl_request);
return $createdRecord->id;
}
function saveNoteInCRM($note,$session_id,$url,$asterisk_id)
{
		$get_entry_list_parameters = array(
			 'session' => $session_id,
			 'module_name' => 'Calls',
			 'query' => " calls.outlook_id like '%".$asterisk_id."'  ",
			 'order_by' => "",
			 'offset' => '0',
			 'select_fields' => array(
				  "name"
			 ),
			 'max_results' => '1',
			 'deleted' => '0',
			 'Favorites' => false,
		);
		$get_entry_list_result = call('get_entry_list', $get_entry_list_parameters, $url);
		//print_r($get_entry_list_result);exit;
		if($get_entry_list_result->result_count=='1')
		{
				$callID = $get_entry_list_result->entry_list[0]->id;
				$set_entry_parameters = array
				(
					//session id
					"session" => $session_id,

					//The name of the module from which to retrieve records.
					"module_name" => "Calls",

					//Record attributes
					"name_value_list" => array
					(
						//to update a record, you will nee to pass in a record id as commented below
						array("name" => "id", "value" => $callID),
						array("name" => "description", "value" => $note),
					),
				);

				$set_entry_result = call("set_entry", $set_entry_parameters, $url);
				
				echo "Note Saved Successfully";
		}
		else
		{
			echo "please wait till call disconnected";
		}
}


?>