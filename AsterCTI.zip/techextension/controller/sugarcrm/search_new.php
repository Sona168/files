<?php
include_once "../route.php";
function search($source_number,$session_id,$url,$Extension)
{
$PhoneNumber = $source_number;	
$Name="No Record Name Found";
$NoteIdSearch="";
$AccountName="No Account Name Found";
$ModuleName="No CRM Relation Found";

$search_url = $url . "/search";
$search_arguments = array(
    "q" => "%".$PhoneNumber."%",
    "max_num" => 3,
    "offset" => 0,
    "fields" => "",
    "order_by" => "",
    "favorites" => false,
    "my_items" => false,
);
$search_url .= "?" . http_build_query($search_arguments);
$result = callNewSugar($search_url,$session_id);
if (empty($result->records)) {
	$dataToSend['name'] = $Name;
	$dataToSend['ID'] = $NoteIdSearch;
	$dataToSend['AccountName'] = $AccountName;
	$dataToSend['ModuleName'] = $ModuleName;
}else{
//print_r($result->records[0]);
	$Name=$result->records[0]->name;
	$NoteIdSearch=$result->records[0]->id;
	$AccountName=$result->records[0]->account_name;
	
	$ModuleName = $result->records[0]->_module;
	$dataToSend['name'] = $Name;
	$dataToSend['ID'] = $NoteIdSearch;
	$dataToSend['AccountName'] = $AccountName;
	$dataToSend['ModuleName'] = $ModuleName;
}


//print_r($dataToSend);
return $dataToSend;

}


?>