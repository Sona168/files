<?php
/* ini_set('display_errors',1);
ini_set('display_startup_errors',1);
ini_set('display_errors', 'On'); */

function create_sms_in_agile($source_number,$api_token,$url,$Extension,$email,$smsContent,$crm_user_id,$dir)
{
	$ModuleName="";
require_once('CurlLib/curlwrap_v2.php');
$PhoneNumber = $source_number;
$PhoneNumber= preg_replace('/[^A-Za-z0-9\-]/', '',$PhoneNumber);
$contact = curl_wrap("contacts/search/phonenumber/$PhoneNumber", null, "GET", "application/json	",$url,$email,$api_token);
$contact = json_decode($contact, false, 512);

if($contact->type != 'COMPANY')
	{
		$contact_id = $contact->id;
		$ID = $contact_id;
		$firstname = $contact->properties[0]->value;
		$lastname = $contact->properties[1]->value;
		if(!$firstname) 	{ 		$firstname=""; 	} 	if(!$lastname) 	{ 		$lastname=""; 	}
		$companyName = $contact->properties[2]->value;
		$ModuleName = "Contacts";
		$Name = $firstname." ".$lastname;
		if($companyName)
		{
			$companyID = $contact->contact_company_id;
		}
		else
		{
			$companyName="No Account Found";
		}
	}
	else if($contact->type == 'COMPANY')
	{
		$company = curl_wrap("contacts/search/phonenumber/$PhoneNumber", null, 'GET',  "application/json");
		$company = json_decode($company, false, 512);
		$companyID= $company->id;
		$ID = $companyID;
		$properties= $company->properties;
		$companyName = $company->properties[0]->value;
		$Name ="No Contact Name";
		$ModuleName = "Accounts";
	}
	
	if($contact->type =="")
	{
		$ModuleName = "";
	}
/* $dataToSend['name'] = $Name;
$dataToSend['ID'] = $ID;
$dataToSend['AccountName'] = $companyName;
$dataToSend['ModuleName'] = $ModuleName; */
if($dir == "in")
{
	$subject = "Incoming SMS From : ".$source_number;
}else{
	$subject = "Outgoing SMS To : ".$source_number." From Extension : ".$Extension;
}
$SMSStatus='COMPLETED';
if($ModuleName == "Contacts")
	{
		$insertedData = '{ "subject": "'.$subject.'","contacts": ["'.$ID.'"],"owner_id": "'.$crm_user_id.'","type": "SMS","priority_type": "HIGH","due": "'.time().'","taskDescription": "'.$smsContent.'","status": "'.$SMSStatus.'"}';
	}
	else if($ModuleName == "Accounts")
	{
		$insertedData = '{ "subject": "'.$subject.'","contacts": ["'.$ID.'"],"owner_id": "'.$crm_user_id.'","type": "SMS","priority_type": "HIGH","due": "'.time().'","taskDescription": "'.$smsContent.'","status": "'.$SMSStatus.'"}';
	}else{
		$insertedData = '{ "subject": "'.$subject.'","owner_id": "'.$crm_user_id.'","type": "SMS","priority_type": "HIGH","due": "'.time().'","taskDescription": "'.$smsContent.'","status": "'.$SMSStatus.'"}';
	}
	$tasksCreate = curl_wrap("tasks/", $insertedData, 'POST',  "application/json",$url,$email,$api_token);
	$tasksCreate = json_decode($tasksCreate, false, 512);
	$createdTaskId = $tasksCreate->id;
	return $createdTaskId;
}
?>