<?php
function create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$api_token,$crmurl,$Extension,$crm_user_id,$date_start,$date_end,$asterisk_id,$type,$email)
{
	 require_once('CurlLib/curlwrap_v2.php');
	$insertedData="";
if($duration==0)
{
    $CallDurationMinuteSec='0.0';
    $CallStatus='YET_TO_START';
}
 elseif($duration<3599) 
{
    $CallDurationMinuteSec=gmdate("i.s", $duration);
    $CallStatus='COMPLETED';
}
 else 
{
    $CallDurationMinuteSec=gmdate("H.i.s", $duration);
    $CallStatus='COMPLETED';
}
	
	$startDate=date("Y-m-d",strtotime($startDate));
	$startTime=date("H:i",strtotime($startDate));
	
$taskDescription ="Phone Number: ".$source_number;
$taskDescription .= "          ";
$taskDescription .="Extension: ".$extension;
$taskDescription .= "          ";
$taskDescription .="Call Duration: ".$CallDurationMinuteSec;
$taskDescription .= "          ";
$taskDescription .="Recordlink: ".$recordLnk;

	if($module_name == "")
	{
		$insertedData = '{ "subject": "'.$subject.'","owner_id": "'.$crm_user_id.'","type": "CALL","priority_type": "HIGH","due": "'.time().'","taskDescription": "'.$taskDescription.'","status": "'.$CallStatus.'"}';
	}
	else
	{
		$insertedData = '{ "subject": "'.$subject.'","contacts": ["'.$parent_id.'"],"owner_id": "'.$crm_user_id.'","type": "CALL","priority_type": "HIGH","due": "'.time().'","taskDescription": "'.$taskDescription.'","status": "'.$CallStatus.'"}';
	}
	//("contacts/search/phonenumber/$PhoneNumber", null, "GET", "application/json	",$url,$email,$api_token);
	$tasksCreate = curl_wrap("tasks/", $insertedData, 'POST',  "application/json",$crmurl,$email,$api_token);
	$tasksCreate = json_decode($tasksCreate, false, 512);
	$createdTaskId = $tasksCreate->id; 
	return $createdTaskId;
}


?>