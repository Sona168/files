<?php
/* ini_set('display_errors',1);
ini_set('display_startup_errors',1);
ini_set('display_errors', 'On'); */

function search($source_number,$api_token,$url,$Extension,$email)
{
	 require_once('CurlLib/curlwrap_v2.php');
	// echo $secret;
		$PhoneNumber = $source_number;
$PhoneNumber= preg_replace('/[^A-Za-z0-9\-]/', '',$PhoneNumber);




//Default Searches In Contacts Module
	
	$contact = curl_wrap("contacts/search/phonenumber/$PhoneNumber", null, "GET", "application/json	",$url,$email,$api_token);
//	$contact = json_decode($contact, false, 512, JSON_BIGINT_AS_STRING);
	$contact = json_decode($contact, false, 512);
if($contact->type != 'COMPANY')
	{
	$contact_id = $contact->id;
	$ID = $contact_id;					//Saved for searching note for contact 
	$firstname = $contact->properties[0]->value;
	$lastname = $contact->properties[1]->value;
	if(!$firstname) 	{ 		$firstname=""; 	} 	if(!$lastname) 	{ 		$lastname=""; 	}
	$companyName = $contact->properties[2]->value;
	//print_r($contact);
	$ModuleName = "Contacts";
	$Name = $firstname." ".$lastname;
	if($companyName)
	{
		$companyID = $contact->contact_company_id;
	}
	else
	{
		$companyName="No Account Found";
	}
		
	}
	else if($contact->type == 'COMPANY')
	{
		//Search In Company
		//echo "Search in company";
		$company = curl_wrap("contacts/search/phonenumber/$PhoneNumber", null, 'GET',  "application/json");
		$company = json_decode($company, false, 512);
		//$company = json_decode($company, false, 512, JSON_BIGINT_AS_STRING);
		
		
		$companyID= $company->id;
		$ID = $companyID;					//Saved for searching note for company 
		$properties= $company->properties;
		$companyName = $company->properties[0]->value;
		//print_r($company);
		$Name ="No Contact Name";
		
		$ModuleName = "Accounts";
	
	}

$dataToSend['name'] = $Name;
$dataToSend['ID'] = $ID;
$dataToSend['AccountName'] = $companyName;
$dataToSend['ModuleName'] = $ModuleName;
return $dataToSend;
}


?>