<?php
function create($ModuleName,$ID,$Name,$subject,$disposition,$Direction,$PhoneNumber,$Extension,$Duration,$recordLnk,$apikey,$crmurl,$userID,$date_start,$date_end,$asterisk_id,$type)
{
	include('Requests.php');
	Requests::register_autoloader();




	
	/****************************** Search In Contact Moduele *******************************************************/
	
	
echo $Name."*".$ID."*".$AccountName."*".$AccountID."*".$PhoneNumber."*".$crmurl."*".$ModuleName;

$SourceNumber="";
	$RecordingSourceNumber="";
	$RecordingDestinationNumber="";
	if($Direction=="Inbound")
	{
		$subject = "Incoming Call From  ".$PhoneNumber." To Extension ".$Extension;
		$Direction = "1";
		$SourceNumber = $PhoneNumber;
	//	$RecordingSourceNumber=$RecordingNumber;
		$DestinationNumber = $Extension;
	    $RecordingDestinationNumber= $Extension;
	
	}
	else
	{
		$subject = "Outgoing Call From  ".$Extension." To Phone ".$PhoneNumber;
		$Direction = "2";
		$SourceNumber = $Extension;
		$DestinationNumber = $PhoneNumber;
		$RecordingSourceNumber= $Extension;
		//$RecordingDestinationNumber=$RecordingNumber;
	}
echo "<br>";
	if($Duration==0)
	{
		
		$COMPLETED="COMPLETED";
		$disposition = "73a0d17f-1163-4015-bdd5-ec830791da20";
		$CallDurationMiilliseconds='0';
	}
	elseif($Duration<3599) 
	{
		$COMPLETED="COMPLETED";
		$disposition = "f240bbac-87c9-4f6e-bf70-924b57d47db7";
		$CallDurationMiilliseconds = $Duration * 1000;
	}


	//$CallDurationMiilliseconds = $CallDurationMiilliseconds - 1800000;
	$CallDurationMiilliseconds = $CallDurationMiilliseconds - 86400000;

/* 	$request = Requests::get("$crmurl/engagements/v1/engagements/1560854054758?hapikey=$apikey", array('Accept' => 'application/json'));
	$requestContactSearchArray = json_decode($request->body);
	print_r($request);
	exit; */
	
	if($ID){
	$data = '{
    "engagement": {
        "active": true,
        "ownerId":"'.$userID.'",
        "type": "CALL"
    },
    "associations": {
        "contactIds": ['.$ID.'],
        "companyIds": ['.$AccountID.'],
        "dealIds": [ ],
        "ownerIds": [ ]
    },

    "metadata" : {
    "toNumber" : "'.$DestinationNumber.'",
    "fromNumber" : "'.$SourceNumber.'",
    "status" : "'.$COMPLETED.'",
    "externalId" : "'.$UniqueId.'",
    "durationMilliseconds" : "'.$CallDurationMiilliseconds.'",
    "recordingUrl" : "'.$recordLink.'",
	"disposition" : "'.$disposition.'",
    "body" : "'.$subject.'",
	"title" : "'.$subject.'"
}
}'; 
	}else{
		$data = '{
    "engagement": {
        "active": true,
        "ownerId": "'.$userID.'",
        "type": "CALL"
    },
    "metadata" : {
    "toNumber" : "'.$DestinationNumber.'",
    "fromNumber" : "'.$SourceNumber.'",
    "status" : "'.$COMPLETED.'",
    "externalId" : "'.$UniqueId.'",
    "durationMilliseconds" : "'.$CallDurationMiilliseconds.'",
    "recordingUrl" : "'.$recordLink.'",
	"disposition" : "'.$disposition.'",
    "body" : "'.$subject.'",
	"title" : "'.$subject.'"
}
}'; 
	}
	
$request = Requests::post("https://api.hubspot.com/engagements/v1/engagements?hapikey=$apikey", array('content-type' => 'application/json'),$data);
$requesstNote = json_decode($request->body);
	return $requesstNote;
}


?>