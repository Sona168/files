<?php

function search($source_number,$apikey,$url,$Extension)
{
include('Requests.php');
Requests::register_autoloader();
$PhoneNumber = $source_number;
	
	/********************************* Searching Phone Number In Different Modules *************************************/
	
	$Name="";
	$AccountName="";
	$ID="";
    $ModuleName="";
	$AccountID="";
	
	/****************************** Search In Contact Moduele *******************************************************/
	
	$request = Requests::get("https://api.hubspot.com/contacts/v1/search/query?q=$PhoneNumber&hapikey=$apikey&count=1&property=associatedcompanyid&property=firstname&property=lastname&property=hs_all_contact_vids", array('Accept' => 'application/json'));
	$requestContactSearchArray = json_decode($request->body);

	$count = $requestContactSearchArray->total;
	if($count > 0)
	{
		//Record Found in Contact Module
		$contactResult = $requestContactSearchArray->contacts[0]->properties;
		$Name = $contactResult->firstname->value." ".$contactResult->lastname->value;
		$ID = $contactResult->hs_all_contact_vids->value;
		$AccountID = $contactResult->associatedcompanyid->value;
		//print_r($contactResult);
		$ModuleName="Contacts";
		$ModuleNameForAPI= "contact";
		if($AccountID)
		{
			$request = Requests::get("https://api.hubspot.com/companies/v2/companies/$AccountID?hapikey=$apikey", array('Accept' => 'application/json'));
			$requestAccountSearchArray = json_decode($request->body);
			$AccountName = $requestAccountSearchArray->properties->name->value;
		}
	}
	else
	{
	}
	
	if(!$Name)
	{
		$Name="No Contact Name Found";
		$ID="";
		$ModuleName="";
	}
	if(!$AccountName){
		$AccountName="No Account Name Found";
		//$ModuleName="";
		$AccountID="";
	}
	if($count > 0){
	$request = Requests::get("https://api.hubspot.com/engagements/v1/engagements/associated/$ModuleNameForAPI/$ID/paged?hapikey=$apikey&limit=1", array('Accept' => 'application/json'));
	$requestNoteSearchArray = json_decode($request->body);
	
	if(array_key_exists (0,$requestNoteSearchArray->results))
	{
		
		$Description = $requestNoteSearchArray->results[0]->metadata->body;
		$Description=str_ireplace('<p>','',$Description);
		$Description=str_ireplace('</p>','',$Description);  
	}else{
		$Description="";
	}
	}else{
		$Description="";
	}
	$Description = trim($Description);
$crmForLink = "https://app.hubspot.com/";
	/********************************* End Of Business Logic Here *************************************/

$NoteIdSearch="";
	if($ModuleName =="Contacts")
	{
		$NoteIdSearch = $ID;
		$parentModule="Contacts";
		$CId= $ID;
	}
	else if ($ModuleName =="Accounts")
	{
		$NoteIdSearch = $AccountID;
		$parentModule="Accounts";
		$CId= $AccountID;
	}
	else if($ModuleName == "Leads")
	{
		$NoteIdSearch = $ID;
		$parentModule="Leads";
		$CId= $ID;
	}
	else 
	{
		$ModuleName="No CRM Relation Found";
		$NoteIdSearch="";
	} 
$dataToSend['name'] = $Name;
$dataToSend['ID'] = $NoteIdSearch;
$dataToSend['AccountName'] = $AccountName;
$dataToSend['ModuleName'] = $ModuleName;
/* $dataToSend['UserName'] = $UserName;
$dataToSend['UserID'] = $UserID; */

return $dataToSend;
}
?>