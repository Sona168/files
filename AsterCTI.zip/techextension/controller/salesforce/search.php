<?php

function search($source_number,$mySforceConnection,$url,$Extension)
{
	$PhoneNum =$source_number;

//	$PhoneNumber= preg_replace('/[^A-Za-z0-9\-]/', '',$PhoneNumber);
//$phoneNumber = preg_replace('/[^0-9]/','',$phoneNumber);
//$phoneNumber ='%'. $formatted = implode('%', str_split($phoneNumber));
if(strlen($PhoneNum) >6)
{
	$PhoneNumber=substr($PhoneNum,-7);
}

$PhoneNumber = '%'.$formatted = implode('%', str_split(preg_replace('/[^0-9]/','',$PhoneNumber)));
if(!$PhoneNumber)
{exit;}

try{
	$query = "SELECT FirstName, LastName,Id,AccountId FROM Contact where MobilePhone like '$PhoneNumber' or  Phone like '$PhoneNumber'  limit 1"; 
	$response = $mySforceConnection->query($query); 
}catch(Exception $e) {
  echo 'Message: ' .$e->getMessage();
}
	foreach ($response as $record)
	{
		$CId  = $record->Id ;
		$ContactFirstName = $record->FirstName;
		$ContactLastName =  $record->LastName;
		$Name = $ContactFirstName." ".$ContactLastName;
		$AccountID =  $record->AccountId;
	}
if($CId)
{
$ModuleName = "Contacts";
}
		if($AccountID)
		{
			$querys = "SELECT Name FROM Account where Id ='$AccountID'"; 
			$response = $mySforceConnection->query($querys); 
			foreach ($response as $record)
			{
				$AccountName  = $record->Name ;
			}
	
		}
		else
		{
			$AccountName = "No Account Name Found";
		}
		//echo $AccountName;exit;
		if(!$CId)
		{
			//echo "Search In Leads....";
			$query = "SELECT FirstName, LastName,Id,Company FROM Lead where  MobilePhone like '$PhoneNumber' or Phone like '$PhoneNumber'   limit 1"; 
			$response = $mySforceConnection->query($query); 
			foreach ($response as $record)
			{
				$LeadID  = $record->Id ;
				//$CId = $LeadID;
				if($LeadID)
				{
					$ModuleName = "Leads";
				}
				$ContactFirstName = $record->FirstName;
				$ContactLastName =  $record->LastName;
				$Name = $ContactFirstName." ".$ContactLastName;
				$AccountName =  $record->Company;
			}
		}
		if(!$LeadID)
		{
		//echo "Search In Account....";
		$query = "SELECT Name,Id FROM Account where Phone like '$PhoneNumber'   limit 1"; 
		$response = $mySforceConnection->query($query); 
		foreach ($response as $record)
			{
				$AccountID  = $record->Id ;
				$AccountName = $record->Name;
				if($AccountID)
				{
					$ModuleName = "Accounts";
					//$AccountID = $AccountID;
				}
			}
		}
		
		
		$NoteIdSearch="";

		if($ModuleName =="Contacts")
		{
			$NoteIdSearch = $CId;
		}
		else if ($ModuleName =="Accounts")
		{
			$NoteIdSearch = $AccountID;
		}
		else if($ModuleName == "Leads")
		{
			$NoteIdSearch = $LeadID;
		}
		else 
		{
			$ModuleName="No CRM Relation Found";
			$NoteIdSearch="";
		}
		
	$dataToSend['name'] = $Name;
$dataToSend['ID'] = $NoteIdSearch;
$dataToSend['AccountName'] = $AccountName;
$dataToSend['ModuleName'] = $ModuleName;
/* $dataToSend['UserName'] = $UserName;
$dataToSend['UserID'] = $UserID; */

return $dataToSend;
}
?>