<?php

function create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$mySforceConnection,$url,$Extension,$crm_user_id,$date_start,$date_end,$asterisk_id,$type)
{
	
	if($type == "enterprise")
	{
		$sObject  =  new stdclass();
		if($parent_id)
		{
			if($module_name == "Accounts")
			{
				$sObject->WhatId =$parent_id;
			}
			else
			{
				$sObject->WhoId =$parent_id;
			}
			$sObject->Subject =$subject;
			$sObject->Status ='Completed';
			$sObject->Call_uniqueId__c =$asterisk_id;
			$sObject->OwnerId =$crm_user_id;
			$sObject->Call_Duration_Tech__c =$duration;
			$sObject->Source_Number_Tech__c =$source_number;
			$sObject->Destination_Number__c =$extension;
			$sObject->Call_Source_Tech__c ='TechExtension Portal'; 
			$sObject->Record_Link__c =$recordLnk; 
	  }
	  else
	  {
	     
			$sObject->Subject =$subject;
			$sObject->Status ='Completed';
			$sObject->Call_uniqueId__c =$asterisk_id;
			$sObject->OwnerId =$crm_user_id;
			$sObject->Call_Duration_Tech__c =$duration;
			$sObject->Source_Number_Tech__c =$source_number;
			$sObject->Destination_Number__c =$extension;
			$sObject->Call_Source_Tech__c ='TechExtension Portal'; 
			$sObject->Record_Link__c =$recordLnk;
	  }
	  
	  
	$createResponse = $mySforceConnection->create(array($sObject), 'Task');
	$callID=  $createResponse[0]->id;
	return $callID;
	}
	else
	{
		if($parent_id)
		{
			if($module_name == "Accounts")
			{
				$fields = array (
								'WhatId' => $parent_id,
								'Subject' => $subject,
								'Status' => 'Completed',
								'Call_uniqueId__c' => $asterisk_id,
								'Call_Duration_Tech__c' => $duration,
								'Source_Number_Tech__c' => $source_number,
								'Destination_Number__c' => $extension,
								'Call_Source_Tech__c' => 'TechExtension Portal',
								'Record_Link__c' => $recordLnk,
								'OwnerId' => $crm_user_id,
							);
			}
			else if($module_name == "Contacts" || $module_name == "Leads")
			{
				
				$fields = array (
								'WhoId' => $parent_id,
								'Subject' => $subject,
								'Status' => 'Completed',
								'Call_uniqueId__c' => $asterisk_id,
								'Call_Duration_Tech__c' => $duration,
								'Source_Number_Tech__c' => $source_number,
								'Destination_Number__c' => $extension,
								'Call_Source_Tech__c' => 'TechExtension Portal',
								'Record_Link__c' => $recordLnk,
								'OwnerId' => $crm_user_id,
							);
				
			}
			else
			{
				$fields = array (
				'Subject' => $subject,
				'Status' => 'Completed',
				'Call_uniqueId__c' => $asterisk_id,
				'Call_Duration_Tech__c' => $duration,
				'Source_Number_Tech__c' => $source_number,
				'Destination_Number__c' => $extension,
				'Call_Source_Tech__c' => 'TechExtension Portal',
				'Record_Link__c' => $recordLnk,
				'OwnerId' => $crm_user_id,
				);
			}
			$sObject = new SObject();
		$sObject->fields = $fields;
		$sObject->type = 'Task';
		$createResponse = $mySforceConnection->create(array($sObject));
		$callID = $createResponse[0]->id;
		return $callID;
	  }
	  
	  
}

}	
	
?>