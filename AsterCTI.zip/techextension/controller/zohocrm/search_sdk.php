<?php

function search($source_number,$accessToken,$url,$Extension,$refresh_token,$client_id,$secret,$crm_config_id)
{
include('Requests.php');

Requests::register_autoloader();
$PhoneNumber = $source_number;
//$PhoneNumber="14237655389";
$zohoApiUrl = "https://www.zohoapis.com";
$zohoAccountUrl = "https://accounts.zoho.com";
$accessToken = trim($accessToken);
 echo "Access Token : ".$accessToken;
echo "<br>";
echo "Refresh Token : ".$refresh_token;
echo "<br>";
  

$url = "https://www.zohoapis.com/crm/v2/Contacts/search?criteria=Mobile:equals:$PhoneNumber";
$authtoken = array('Authorization: Zoho-oauthtoken '.$accessToken);
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $authtoken);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
$response = curl_exec($ch);
$contactData = json_decode($response);
print_r($contactData->code);
echo "<br><br>";


 if(isset($contactData->code))
{
	$accessTokenURL = $zohoAccountUrl."/oauth/v2/token?refresh_token=$refresh_token&client_id=$client_id&client_secret=$secret&grant_type=refresh_token";
	$accessTokenrequest = Requests::post($accessTokenURL, array('Accept' => 'application/json'));
	echo "requesting new access token";
	echo "<br><br>";
	print_r($accessTokenrequest);
	echo "<br><br>";
	$jsonArray = json_decode($accessTokenrequest->body);
		if(isset($jsonArray->error))
		{
			echo $jsonArray->error;
			echo "Refresh Token : ".$refresh_token;
			Exit;
		}else{
			$accessToken = $jsonArray->access_token;
			echo "NEW ACCESS TOKEN : ".$accessToken;
			echo "<br><br>";
			echo "CRM CONF ID : ".$crm_config_id;
				echo "<br><br>";
			echo "Refresh TOKEN : ".$refresh_token;
			setZohoToken($crm_config_id,$accessToken,$refresh_token);
		}
	/* $responseFromContacts = Requests::get($zohoApiUrl."/crm/v2/Contacts/search?criteria=((Phone:equals:%$PhoneNumber%) OR (Mobile:equals:%$PhoneNumber%) OR (Home_Phone:equals:%$PhoneNumber%) OR (Other_Phone:equals:%$PhoneNumber%))", array("Authorization"=>"Zoho-oauthtoken $accessToken")); 
	$contactData = json_decode($responseFromContacts->body); */
} 





$responseFromContacts = Requests::get($zohoApiUrl."/crm/v2/Contacts/search?criteria=((Phone:equals:%$PhoneNumber%) OR (Mobile:equals:%$PhoneNumber%))", array("Authorization"=>"Zoho-oauthtoken $accessToken")); 
$contactData = json_decode($responseFromContacts->body);




if(isset($contactData->code))
{
	$accessTokenURL = $zohoAccountUrl."/oauth/v2/token?refresh_token=$refresh_token&client_id=$client_id&client_secret=$secret&grant_type=refresh_token";
	$accessTokenrequest = Requests::post($accessTokenURL, array('Accept' => 'application/json')); 
	$jsonArray = json_decode($accessTokenrequest->body);
		if(isset($jsonArray->error))
		{
			echo $jsonArray->error;
			echo "Refresh Token : ".$refresh_token;
			Exit;
		}else{
			$accessToken = $jsonArray->access_token;
			setZohoToken($crm_config_id,$accessToken,$refresh_token);
		}
	$responseFromContacts = Requests::get($zohoApiUrl."/crm/v2/Contacts/search?criteria=((Phone:equals:%$PhoneNumber%) OR (Mobile:equals:%$PhoneNumber%) OR (Home_Phone:equals:%$PhoneNumber%) OR (Other_Phone:equals:%$PhoneNumber%))", array("Authorization"=>"Zoho-oauthtoken $accessToken")); 
	$contactData = json_decode($responseFromContacts->body);
}
$ModuleName="";
if(!empty($contactData))
{
/* print_r($contactData->data[0]);
echo "<br>";
print_r($contactData->data[0]->id); */
	$ModuleName = "Contacts";
	$ID = $contactData->data[0]->id;
	$First_Name = $contactData->data[0]->First_Name;
	$Last_Name = $contactData->data[0]->Last_Name;
	$Name = $First_Name." ".$Last_Name;
	$Name = trim($Name);
	if($contactData->data[0]->Account_Name)
	{
		$AccountName = $contactData->data[0]->Account_Name->name;
		$AccountID = $contactData->data[0]->Account_Name->id;
	}else{
		$AccountName = "No Account Found";
	}
}else{
	$responseFromAccounts = Requests::get($zohoApiUrl."/crm/v2/Accounts/search?criteria=((Phone:equals:$PhoneNumber) OR (Fax:equals:$PhoneNumber))", array("Authorization"=>"Zoho-oauthtoken $accessToken")); 

	$accountData = json_decode($responseFromAccounts->body);
	if(!empty($accountData)){
		$Name ="No Contact Name";
		$ModuleName = "Accounts";
		$AccountName = $accountData->data[0]->Account_Name;
		$ID = $accountData->data[0]->id;
	}else{
		$responseFromLeads = Requests::get($zohoApiUrl."/crm/v2/Leads/search?criteria=((Phone:equals:$PhoneNumber) OR (Mobile:equals:$PhoneNumber) OR (Fax:equals:%$PhoneNumber%))", array("Authorization"=>"Zoho-oauthtoken $accessToken")); 
		$leadData = json_decode($responseFromLeads->body);
		if(!empty($leadData)){
			$ModuleName = "Leads";
			$ID = $leadData->data[0]->id;
			$First_Name = $leadData->data[0]->First_Name;
			$Last_Name = $leadData->data[0]->Last_Name;
			$Name = $First_Name." ".$Last_Name;
			$Name = trim($Name);
			$AccountName = $leadData->data[0]->Company;
		}else{
			$ModuleName="No Relation";
			$ID="";
			$Name="No Contact/Lead/Account Found";
			$AccountName="";
		}
	}
}
$dataToSend['name'] = $Name;
$dataToSend['ID'] = $ID;
$dataToSend['AccountName'] = $AccountName;
$dataToSend['ModuleName'] = $ModuleName;
return $dataToSend;
}
?>