<?php

function create($ModuleName,$parent_id,$parent_name,$subject,$note,$disposition,$Direction,$source_number,$extension,$duration,$recordLnk,$accessToken,$url,$Extension,$UserID,$date_start,$date_end,$UniqueId,$type)
{
	include('Requests.php');
	Requests::register_autoloader();
	echo $ModuleName;
	$zohoApiUrl = "https://www.zohoapis.com";
	
	$startDate=date("Y-m-d H:i:s",strtotime($date_start));
	$endDate=date("Y-m-d H:i:s",strtotime($date_end));
	if($duration==0)
{
    $CallDurationMinuteSec='0:0';
    $CallStatus='Not Held';
}
 elseif($duration<3599) 
{
    $CallDurationMinuteSec=gmdate("i:s", $duration);
    $CallStatus='Held';
   // $duration_string=$DurationInSec;

}
 else 
{
    $CallDurationMinuteSec=gmdate("i:s", $duration);
    $CallStatus='Held';
}

if($Direction == "outbound"){
	$Direction = "Outbound";
}else if($Direction == "inbound")
{
	$Direction = "Inbound";
}
$recordObject = array();
if($ModuleName == "Leads")
	{
/* 	$data = ' {
    "data": [
      {
        "Subject":'.$subject.',
        "Owner":'.$UserID.',
		"Call_Type":'.$Direction.',
		"Call_Purpose":Prospecting,
		"Who_Id":'.$parent_id.',
		"$se_module":"Leads",
		"Call_Details":"Completed",
		"Call_Start_Time":"'.gmdate("Y-m-d\TH:i:s\Z", strtotime($startDate)).'",
		"Call_Duration":"'.$CallDurationMinuteSec.'",
		"Call_Result":"'.$UniqueId.'",
		"Description":"'.$recordLink.'"
      }
    ],
“triggger”:[“workflow”,”approval”,”blueprint”]
}'; */
		
	
		
        $recordObject["Subject"]=$subject;
        $recordObject["Owner"]=$UserID;
        $recordObject["Call_Type"]=$Direction;
        $recordObject["Call_Purpose"]="Prospecting";
		$recordObject["What_Id"]=$parent_id;
		$recordObject["$se_module"]="Leads";
		$recordObject["Call_Details"]="Completed";
		$recordObject["Call_Start_Time"]=gmdate("Y-m-d\TH:i:s\Z", strtotime($startDate));
		$recordObject["Call_Duration"]=$CallDurationMinuteSec;
		$recordObject["Call_Result"]=$UniqueId;
		$recordObject["Description"]=$recordLink;
	}
	if($ModuleName == "Contacts")
	{
	
/* $data = ' {
    "data": [
      {
        "Subject":'.$subject.',
        "Owner":'.$UserID.',
		"Call_Type":'.$Direction.',
		"Call_Purpose":Prospecting,
		"Who_Id":'.$parent_id.',
		"$se_module":"Contacts",
		"Call_Details":"Completed",
		"Call_Start_Time":"'.gmdate("Y-m-d\TH:i:s\Z", strtotime($startDate)).'",
		"Call_Duration":"'.$CallDurationMinuteSec.'",
		"Call_Result":"'.$UniqueId.'",
		"Description":"'.$recordLink.'"
      }
    ],
“triggger”:[“workflow”,”approval”,”blueprint”]
}'; */

$recordObject["Subject"]=$subject;
        $recordObject["Owner"]=$UserID;
        $recordObject["Call_Type"]=$Direction;
        $recordObject["Call_Purpose"]="Prospecting";
		$recordObject["Who_Id"]=$parent_id;
		$recordObject["$se_module"]="Contacts";
		$recordObject["Call_Details"]="Completed";
		$recordObject["Call_Start_Time"]=gmdate("Y-m-d\TH:i:s\Z", strtotime($startDate));
		$recordObject["Call_Duration"]=$CallDurationMinuteSec;
		$recordObject["Call_Result"]=$UniqueId;
		$recordObject["Description"]=$recordLink;

	}
	else if($ModuleName == "Accounts")
	{
/* $data = ' {
    "data": [
      {
        "Subject":'.$subject.',
        "Owner":'.$UserID.',
		"Call_Type":'.$Direction.',
		"Call_Purpose":Prospecting,
		"Who_Id":'.$parent_id.',
		"$se_module":"Accounts",
		"Call_Details":"Completed",
		"Call_Start_Time":"'.gmdate("Y-m-d\TH:i:s\Z", strtotime($startDate)).'",
		"Call_Duration":"'.$CallDurationMinuteSec.'",
		"Call_Result":"'.$UniqueId.'",
		"Description":"'.$recordLink.'"
      }
    ],
“triggger”:[“workflow”,”approval”,”blueprint”]
}'; */


$recordObject["Subject"]=$subject;
        $recordObject["Owner"]=$UserID;
        $recordObject["Call_Type"]=$Direction;
        $recordObject["Call_Purpose"]="Prospecting";
		$recordObject["Who_Id"]=$parent_id;
		$recordObject["$se_module"]="Accounts";
		$recordObject["Call_Details"]="Completed";
		$recordObject["Call_Start_Time"]=gmdate("Y-m-d\TH:i:s\Z", strtotime($startDate));
		$recordObject["Call_Duration"]=$CallDurationMinuteSec;
		$recordObject["Call_Result"]=$UniqueId;
		$recordObject["Description"]=$recordLink;


}else{
/* $data = ' {
    "data": [
      {
        "Subject":'.$subject.',
        "Owner":'.$UserID.',
		"Call_Type":'.$Direction.',
		"Call_Purpose":Prospecting,
		"Call_Details":"Completed",
		"Call_Start_Time":"'.gmdate("Y-m-d\TH:i:s\Z", strtotime($startDate)).'",
		"Call_Duration":"'.$CallDurationMinuteSec.'",
		"Call_Result":"'.$UniqueId.'",
		"Description":"'.$recordLink.'"
      }
    ],
“triggger”:[“workflow”,”approval”,”blueprint”]
}'; */


$recordObject["Subject"]=$subject;
        $recordObject["Owner"]=$UserID;
        $recordObject["Call_Type"]=$Direction;
        $recordObject["Call_Purpose"]="Prospecting";
		$recordObject["Call_Details"]="Completed";
		$recordObject["Call_Start_Time"]=gmdate("Y-m-d\TH:i:s\Z", strtotime($startDate));
		$recordObject["Call_Duration"]=$CallDurationMinuteSec;
		$recordObject["Call_Result"]=$UniqueId;
		$recordObject["Description"]=$recordLink;


}
echo "<br><br><br>";
print_r($recordObject);
echo "<br><br><br>";






 $curl_pointer = curl_init();
        
        $curl_options = array();
        $url = $zohoApiUrl."/crm/v2/Calls";
        
        $curl_options[CURLOPT_URL] =$url;
        $curl_options[CURLOPT_RETURNTRANSFER] = true;
        $curl_options[CURLOPT_HEADER] = 1;
        $curl_options[CURLOPT_CUSTOMREQUEST] = "POST";
        $requestBody = array();
        $recordArray = array();
        

        
        
        $recordArray[] = $recordObject;
        $requestBody["data"] =$recordArray;
        $curl_options[CURLOPT_POSTFIELDS]= json_encode($requestBody);
        $headersArray = array();
        
        $headersArray[] = "Authorization". ":" . "Zoho-oauthtoken " . $accessToken;
        
        $curl_options[CURLOPT_HTTPHEADER]=$headersArray;
        
        curl_setopt_array($curl_pointer, $curl_options);
        
        $result = curl_exec($curl_pointer);
        $responseInfo = curl_getinfo($curl_pointer);
        curl_close($curl_pointer);
        list ($headers, $content) = explode("\r\n\r\n", $result, 2);
        if(strpos($headers," 100 Continue")!==false){
            list( $headers, $content) = explode( "\r\n\r\n", $content , 2);
        }
        $headerArray = (explode("\r\n", $headers, 50));
        $headerMap = array();
        foreach ($headerArray as $key) {
            if (strpos($key, ":") != false) {
                $firstHalf = substr($key, 0, strpos($key, ":"));
                $secondHalf = substr($key, strpos($key, ":") + 1);
                $headerMap[$firstHalf] = trim($secondHalf);
            }
        }
        $jsonResponse = json_decode($content, true);
        if ($jsonResponse == null && $responseInfo['http_code'] != 204) {
            list ($headers, $content) = explode("\r\n\r\n", $content, 2);
            $jsonResponse = json_decode($content, true);
        }
        //var_dump($headerMap);
       
        //var_dump($responseInfo['http_code']);


echo $jsonResponse['data'][0]['details']['id'];




/* $request = Requests::post($zohoApiUrl."/crm/v2/Calls",array("Authorization"=>"Zoho-oauthtoken $accessToken"),$data);
$jsonArrayCalls = json_decode($request->body);  */


return $jsonResponse['data'][0]['details']['id'];
}


?>