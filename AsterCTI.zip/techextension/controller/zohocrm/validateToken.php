<?php
//error_reporting(E_ERROR | E_WARNING | E_PARSE);
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
include('Requests.php');
include('../route.php');
Requests::register_autoloader();

$zohoAccountUrl = "https://accounts.zoho.com";

$accessToken="";
$refreshToken="";

if(!isset($_GET['code'])){
	echo "0";
	exit;
}
if(!isset($_GET['client_id'])){
	echo "1";
	exit;
}
if(!isset($_GET['client_secret'])){
	echo "2";
	exit;
}
$code = $_GET['code'];
$clientSecret = $_GET['client_secret'];
$clientID = $_GET['client_id'];

$accessTokenURL = $zohoAccountUrl."/oauth/v2/token?code=$code&client_id=$clientID&client_secret=$clientSecret&grant_type=authorization_code";
$accessTokenrequest = Requests::post($accessTokenURL, array('Accept' => 'application/json')); 

$jsonArray = json_decode($accessTokenrequest->body);
if(isset($jsonArray->error))
{
	echo $jsonArray->error;
	Exit;
}else{
	$name="ZOHO CRM";
	$username=$code;
	$password="";
	$secret=$clientSecret;
	$client_id=$clientID;
	$url = $_GET['url'];
	$for_all = $_GET['for_all'];
	
	if(isset($_GET['crm_config_id']))
	{
		$crm_config_id = $_GET['crm_config_id'];
		$dataToSend = $crm_config_id."***".$name."***".$url."***".$secret."***".$username."***".$password."***".$for_all."***".$client_id;
		$res = updateCRMConfiguration($dataToSend);
	}else{
	$dataToSend = $_SESSION['tech_admin_id']."max".$name."max".$url."max".$username."max".$password."max".$secret."max".$for_all."max".$client_id;
	$res = createCRMConfiguration($dataToSend);
		if(trim($res['status'])=="present")
		{
			echo "3";
			exit;
		}
	$crm_config_id=$res['id'];
	}
	
	$accessToken = $jsonArray->access_token;
	$refreshToken = $jsonArray->refresh_token;
	
	setZohoToken($crm_config_id,$accessToken,$refreshToken);
	if($accessToken)
	{
		echo "4";
	}
}
?>