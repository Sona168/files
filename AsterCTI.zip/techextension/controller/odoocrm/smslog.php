<?php
/* ini_set('display_errors',1);
ini_set('display_startup_errors',1);
ini_set('display_errors', 'On'); */

function create_sms_in_odoo($source_number,$db,$crmurl,$extension,$username,$password,$smsContent,$uid,$dir)
{
	require_once('library/ripcord.php');
	$models = ripcord::client("$url/xmlrpc/2/object");
	$phoneNumber = $source_number;
	

	
	
$Name="No Contact Name Found";
$AccountName="No Account Name Found";
$AccountID = "";
$ID = "";
$NoteIdSearch="";
$result_count_in_account='';
$result_count_in_contact='';
$ModuleName='';
//Search in Contact Module

// ************************* search under phone field ************************ //
$result_contact = $models->execute_kw($db, $uid, $password,
'res.partner', 'search_read',
array(
array(
array('is_company', '=', false),
array('customer', '=', true),
array('phone', '=', $phoneNumber), ))
,		array('fields'=>array('name','parent_id','comment'), 'limit'=>5)
);



if(empty($result_contact))
{
// ************************* search under mobile field ************************ //

$result_contact = $models->execute_kw($db, $uid, $password,
		'res.partner', 'search_read',
		array(array(array('is_company', '=', false),
		array('customer', '=', true),
		array('mobile', '=', $phoneNumber),
))
,    array('fields'=>array('name','parent_id','comment'), 'limit'=>5)
	);
	
}
else if(empty($result_contact))
{
// ************************* search under fax field ************************ //
$result_contact = $models->execute_kw($db, $uid, $password,
		'res.partner', 'search_read',
		array(array(array('is_company', '=', false),
		array('customer', '=', true),
		array('fax', '=', $phoneNumber),
))
,    array('fields'=>array('name','parent_id','comment'), 'limit'=>5)
	);
}


	/*****************************  For Contacts  *************************************/
if($result_contact)
{
	$result_count_in_contact = count($result_contact[0]);
	if($result_count_in_contact > 0)
	{
		$Name="No Contact Name Found";
		$AccountName="No Account Name Found";
		$AccountID = "";
		$ID = "";
		$ModuleName='Contacts';

		$contact_details_array = $result_contact[0];
		$noteDescription = $contact_details_array['comment'];
		//print_r($contact_details_array);
		$accountDetails = $contact_details_array['parent_id'];
		if($accountDetails)
		{
			$AccountID = $accountDetails['0'];
			$AccountName = $accountDetails['1'];
		}
		else
		{
			//echo "No account found";
		}
		$ID = $contact_details_array['id'];
		$Name = $contact_details_array['name'];
		/* echo "</br>";
		echo $AccountID." ".$AccountName." ".$ID." ".$Name; */
	}
}

	/***************************** End For Contacts  *************************************/

	
	/***************************** Search in Accounts  *************************************/
if($result_count_in_contact == 0)
{

	$result_account = $models->execute_kw($db, $uid, $password,
	'res.partner', 'search_read',
	array(array(array('is_company', '=', true),
	array('customer', '=', true),
	array('mobile', '=', $phoneNumber),
	))
	,    array('fields'=>array('name','id'), 'limit'=>5)
	);

if(empty($result_account))
{
//	echo "search in phone field for account";
//echo "<br>";
	$result_account = $models->execute_kw($db, $uid, $password,
			'res.partner', 'search_read',
			array(array(array('is_company', '=', true),
			array('customer', '=', true),
			array('phone', '=', $phoneNumber),
	))
	,    array('fields'=>array('name','id'), 'limit'=>5)
	);
}
if(empty($result_account))
{
	//echo "search in fax field for account";
	//echo "<br>";
	$result_account = $models->execute_kw($db, $uid, $password,
			'res.partner', 'search_read',
			array(array(array('is_company', '=', true),
			array('customer', '=', true),
			array('fax', '=', $phoneNumber),
	))
	,    array('fields'=>array('name','id'), 'limit'=>5)
	);
}

//print_r($result_account);
$result_count_in_account = count($result_account);
//print_r($result_count_in_account);

	if($result_count_in_account > 0)
	{
		$Name="No Contact Name Found";
		$AccountName="No Account Name Found";
		$AccountID = "";
		$ID = "";
		$ModuleName='Accounts';

		$contact_details_array = $result_account[0];
		//$noteDescription = $contact_details_array['comment'];
		
			$AccountID = $contact_details_array['id'];
			$ID = $contact_details_array['id'];
			$AccountName = $contact_details_array['name'];
		//echo "</br>";
		//echo $AccountID." ".$AccountName." ".$ID." ".$Name;
	}

}


$NoteIdSearch="";
		
		if($ModuleName =="Contacts")
		{
			$NoteIdSearch = $ID;
		}
		else if ($ModuleName =="Accounts")
		{
			$NoteIdSearch = $ID;
		}
		else if($ModuleName == "Leads")
		{
			$NoteIdSearch = $ID;
		}
		else 
		{
			$ModuleName="No CRM Relation Found";
			$NoteIdSearch="";
		}
	

/*  $dataToSend['name'] = $Name;
$dataToSend['ID'] = $NoteIdSearch;
$dataToSend['AccountName'] = $AccountName;
$dataToSend['ModuleName'] = $ModuleName; */


if($dir == "in")
{
	$subject = "Incoming SMS From : ".$source_number;
}else{
	$subject = "Outgoing SMS To : ".$source_number." From Extension : ".$Extension;
}
$SMSStatus='COMPLETED';
if($ModuleName == "Contacts")
	{
		$insertedData = '{ "subject": "'.$subject.'","contacts": ["'.$ID.'"],"owner_id": "'.$crm_user_id.'","type": "SMS","priority_type": "HIGH","due": "'.time().'","taskDescription": "'.$smsContent.'","status": "'.$SMSStatus.'"}';
	}
	else if($ModuleName == "Accounts")
	{
		$insertedData = '{ "subject": "'.$subject.'","contacts": ["'.$ID.'"],"owner_id": "'.$crm_user_id.'","type": "SMS","priority_type": "HIGH","due": "'.time().'","taskDescription": "'.$smsContent.'","status": "'.$SMSStatus.'"}';
	}else{
		$insertedData = '{ "subject": "'.$subject.'","owner_id": "'.$crm_user_id.'","type": "SMS","priority_type": "HIGH","due": "'.time().'","taskDescription": "'.$smsContent.'","status": "'.$SMSStatus.'"}';
	}
	$tasksCreate = curl_wrap("tasks/", $insertedData, 'POST',  "application/json",$url,$email,$api_token);
	$tasksCreate = json_decode($tasksCreate, false, 512);
	$createdTaskId = $tasksCreate->id;
	return $createdTaskId;
}
?>