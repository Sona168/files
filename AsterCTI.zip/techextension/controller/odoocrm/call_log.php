<?php

function create($module_name,$parent_id,$parent_name,$subject,$note,$disposition,$direction,$source_number,$extension,$duration,$recordLnk,$db,$crmurl,$crm_user_id,$date_start,$date_end,$asterisk_id,$password)
{
	require_once('library/ripcord.php');
	$models = ripcord::client("$crmurl/xmlrpc/2/object");
	
if($duration==0)
{
    $CallDurationMinuteSec='0.0';
    $CallStatus='Not_answered';
}
 elseif($duration<3599) 
{
    $CallDurationMinuteSec=gmdate("i.s", $duration);
    $CallStatus='Answered';
   // $duration_string=$DurationInSec;

}
 else 
{
    $CallDurationMinuteSec=gmdate("H.i.s", $duration);
    $CallStatus='Answered';
}

	$startdatetemp=substr($date_start,0,10);
	$starttimetemp=substr($date_start,-8);
	$starttimetemp=str_replace("-",":",$starttimetemp);
	$startDate=$startdatetemp." ".$starttimetemp;
	$startDate=date("m-d-Y H:i:s",strtotime($startDate));
	$enddatetemp=substr($date_end,0,10);
	$endtimetemp=substr($date_end,-8);
	$endtimetemp=str_replace("-",":",$endtimetemp);
	$endDate=$enddatetemp." ".$endtimetemp;
	$endDate=date("m-d-Y H:i:s",strtotime($endDate));
	
	
	if($direction == "inbound")
	{
		$direction = "Inbound";
	}else{
		$direction = "Outbound";
	}
/* 	$abbb = array('callsubject'=>$subject,'calldirection'=>$direction,'callstatus'=>$CallStatus,'sourcenumber'=>$source_number,'destination'=>$extension,'callrecord'=>$recordLnk,'callrelate'=>$crm_user_id,'calldassinged'=>$parent_id,'callstartdate'=>$startDate,'callenddate'=>$endDate,'calluid'=>$asterisk_id,'callduration'=>$duration); */
	$res = $models->execute_kw($db, $crm_user_id, $password,
			'pbxmanager.pbxmanager', 'create',
			array(
				array('callsubject'=>$subject,'calldirection'=>$direction,'callstatus'=>$CallStatus,'sourcenumber'=>$source_number,'destination'=>$extension,'callrecord'=>$recordLnk,'callrelate'=>$crm_user_id,'calldassinged'=>$parent_id,'callstartdate'=>$startDate,'callenddate'=>$endDate,'calluid'=>$asterisk_id,'callduration'=>$duration)
			)
		);
		return $res;
}

?>