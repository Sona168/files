<!DOCTYPE html>

  <?php include "header.php" ?>
  <?php include "left_sidebar.php" ?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  </head>
  <?php
  if(!$_GET['id'])
  {
	//	echo "<script>location.href='index.php'</script>";	  
  }
  ?>
  
	<?php
		$callDetails = getCallDetailsFromCallId($_GET['id']);
	?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Call Details
            <small>#<?php echo $callDetails['data'][0]['id']; ?></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Calls</a></li>
            <li class="active">Detail</li>
          </ol>
        </section>
<!--
        <div class="pad margin no-print">
          <div class="callout callout-info" style="margin-bottom: 0!important;">
            <h4><i class="fa fa-info"></i> Note:</h4>
            This page has been enhanced for printing. Click the print button at the bottom of the invoice to test.
          </div>
        </div>
-->


<?php
				if($callDetails['data'][0]['direction'] == 'inbound')
				{
					$contactInfo = getContactFromNumber($callDetails['data'][0]['source_number']);
				
				}else
				{
					$contactInfo = getContactFromNumber($callDetails['data'][0]['destination_number']);
				
				}
				?>

        <!-- Main content -->
        <section class="invoice">
          <!-- title row -->
          <div class="row">
            <div class="col-xs-12">
              <h2 class="page-header">
                <i class="fa fa-globe"></i> <?php echo strtoupper($callDetails['data'][0]['subject']);if($contactInfo['count'] > 0){echo " Contact Name : ";?><a target="_new" href="contact_details.php?action=View&id=<?php echo $contactInfo['data'][0]['id']; ?>"><?php echo $contactInfo['data'][0]['first_name']." ".$contactInfo['data'][0]['last_name']; ?></a><?php } ?>
                <small class="pull-right">Date: <?php echo $callDetails['data'][0]['date_start']; ?></small>
              </h2>
            </div><!-- /.col -->
          </div>
          <!-- info row -->
          	<!--  <div class="row invoice-info">
          <div class="col-sm-4 invoice-col">
              
              <address>
                <strong>Admin, Inc.</strong>
			
				<br>
                795 Folsom Ave, Suite 600<br>
                San Francisco, CA 94107<br>
                Phone: (804) 123-5432<br>
                Email: info@almasaeedstudio.com
				
              </address>
            </div> -->
            
			<!--
			<div class="col-sm-4 invoice-col">
              To
              <address>
                <strong>John Doe</strong><br>
                795 Folsom Ave, Suite 600<br>
                San Francisco, CA 94107<br>
                Phone: (555) 539-1037<br>
                Email: john.doe@example.com
              </address>
            </div>
            <div class="col-sm-4 invoice-col">
              <b>Invoice #007612</b><br>
              <br>
              <b>Order ID:</b> 4F3S8J<br>
              <b>Payment Due:</b> 2/22/2014<br>
              <b>Account:</b> 968-34567
            </div>
			
			
          </div>-->

          <!-- Table row -->
          <div class="row">
		   <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">
                
				
				<!--<thead>
                  <tr>
                    <th>Qty</th>
                    <th>Product</th>
                    <th>Serial #</th>
                    <th>Description</th>
                    <th>Subtotal</th>
                  </tr>
                </thead>
				-->
				
				
                <tbody>
                
				<tr>
					<td>Call ID</td>
					<td><?php echo $callDetails['data'][0]['id']; ?></td>
				</tr>
				<tr>
                    <td>Source Number</td>
                    <td><?php echo $callDetails['data'][0]['source_number']; ?></td>
                  </tr>
                  <tr>
                    <td>Destination Number</td>
                    <td><?php echo $callDetails['data'][0]['destination_number']; ?></td>
                  </tr>
				  
				  
				  <tr>
                    <td>AsterCTI Contact</td>
                    <td><a target="_new" href="contact_details.php?action=View&id=<?php echo $contactInfo['data'][0]['id']; ?>"><?php echo $contactInfo['data'][0]['first_name']." ".$contactInfo['data'][0]['last_name']; ?></a></td>
                  </tr>
			
			
			<?php 
if($callDetails['data'][0]['parent'])
{
	?>
	 <tr>
                    <td><?php echo $callDetails['data'][0]['parent']; ?></td>
                    <td onclick="openViewCRMPage('<?php echo $callDetails['data'][0]['parent_id']; ?>','<?php echo $callDetails['data'][0]['parent']; ?>')" style="cursor: pointer;"><a><?php echo $callDetails['data'][0]['parent_name']; ?></a></td>
                  </tr>
	<?php
}?>
				  
				  
                  <tr>
                    <td>Status</td>
                    <td><?php echo $callDetails['data'][0]['status']; ?></td>
                  </tr>
				  <tr>
                    <td>Direction</td>
                    <td><?php echo $callDetails['data'][0]['direction']; ?></td>
                  </tr>
				   <tr>
                    <td>Recording Link</td>
                    <td>
					
					<?php
					if(!$callDetails['data'][0]['recording'])
					{
					?>
					<div class="col-md-6">
						
							<div class="overlay">
								<i class="fa fa-refresh fa-spin"></i>
							</div>
					</div>
					<?php
					}else
					{?>
						<!--<a href="<?php echo $callDetails['data'][0]['recording']; ?>" target="new"><img src='image/play.gif'/></a>-->
						
						<audio id='recordingURL' src='<?php echo $callDetails['data'][0]['recording']; ?>' controls preload="auto" autobuffer></audio>
						<?php
					}
					?>
					
					</td>
                  </tr>
				  
				  
                </tbody>
              </table>
            </div><!-- /.col -->
         </div>
 <div class="col-md-6">
            <div class="col-xs-12 table-responsive">
              <table class="table table-striped">

                <tbody>
				<tr>
                    <td>PBX ID</td>
                    <td><?php echo $callDetails['data'][0]['unique_id']; ?></td>
                </tr>
				<tr>
                    <td>Disposition</td>
                    <td><?php echo $callDetails['data'][0]['desposition']; ?></td>
                  </tr>
				  <tr>
                    <td>Last Data</td>
                    <td><?php echo $callDetails['data'][0]['lastdata']; ?></td>
                  </tr>
				  <tr>
                    <td>Total Seconds</td>
                    <td><?php echo $callDetails['data'][0]['total_seconds']; ?></td>
                  </tr>
				  <tr>
                    <td>Billable Seconds</td>
                    <td><?php echo $callDetails['data'][0]['call_second']; ?></td>
                  </tr>
			
				  <tr>
                    <td>Account Code</td>
                    <td><?php echo $callDetails['data'][0]['account_code']; ?></td>
                  </tr>
				
				 <tr>
                    <td>Asterisk Caller ID</td>
                    <td><?php echo $callDetails['data'][0]['asterisk_clid']; ?></td>
                  </tr>
				   <tr>
                    <td>Channel</td>
                    <td><?php echo $callDetails['data'][0]['channel']; ?></td>
                  </tr>
				   <tr>
                    <td>AMA Flag</td>
                    <td><?php echo $callDetails['data'][0]['amaflag']; ?></td>
                  </tr>
				   <tr>
					<td>Last Application</td>
					<td><?php echo $callDetails['data'][0]['application_data']; ?></td>
				  </tr>
				  <!--
				   <tr>
                    <td>Assigned User</td>
                    <td><?php echo $userInfo['data'][0]['name']; ?></td>
                  </tr>
				  -->
				   <tr>
                    <td>Start Date</td>
                    <td><?php echo $callDetails['data'][0]['date_start']; ?></td>
                  </tr>
				  
				   <tr>
                    <td>End Date</td>
                    <td><?php echo $callDetails['data'][0]['date_end']; ?></td>
                  </tr>
				</tbody>
				</table>
				</div>
				</div>
</div>
          <div class="row">
            <!-- accepted payments column -->
            <div class="col-xs-6">
              <p class="lead">Notes:</p>
             
              <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                <?php echo $callDetails['data'][0]['note']; ?>
              </p>
			  
            </div><!-- /.col -->
          

		<!--  <div class="col-xs-6">
              <p class="lead">Amount Due 2/22/2014</p>
              <div class="table-responsive">
                <table class="table">
                  <tr>
                    <th style="width:50%">Subtotal:</th>
                    <td>$250.30</td>
                  </tr>
                  <tr>
                    <th>Tax (9.3%)</th>
                    <td>$10.34</td>
                  </tr>
                  <tr>
                    <th>Shipping:</th>
                    <td>$5.80</td>
                  </tr>
                  <tr>
                    <th>Total:</th>
                    <td>$265.24</td>
                  </tr>
                </table>
              </div>
            </div>-->
          </div>

          <!-- this row will not appear when printing -->
          
		  <!--<div class="row no-print">
            <div class="col-xs-12">
              <a href="invoice-print.html" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
              <button class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Submit Payment</button>
              <button class="btn btn-primary pull-right" style="margin-right: 5px;"><i class="fa fa-download"></i> Generate PDF</button>
            </div>
          </div>
		  -->
		  
		  
        </section><!-- /.content -->
        <div class="clearfix"></div>
      </div><!-- /.content-wrapper -->
	      <script>
	 function openViewCRMPage(id,module)
		{
			window.open('crm.php?action=view&id='+id+'&module='+module);
		}
	 </script>
     
     <?php
	
	  include "footer.php";
	  include "footer_script.php";
	  include "control_sidebar.php";
	 // include "footer_script.php";
	  ?>
  </body>
</html>
